package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Message;
import com.mycompany.myapp.domain.MessageReceiver;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.MessageDTO;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link MessageReceiver} and its DTO {@link MessageReceiverDTO}.
 */
@Mapper(componentModel = "spring", uses = { MessageReceiverMapper.class })
public interface MessageReceiverMapper extends EntityMapper<MessageReceiverDTO, MessageReceiver> {
    //    @Mapping(target = "message", source = "message", qualifiedByName = "messageId")
    //    @Mapping(target = "receiver", source = "receiver", qualifiedByName = "appUserId")
    //    MessageReceiverDTO toDto(MessageReceiver s);
    //
    //    @Named("messageId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    MessageDTO toDtoMessageId(Message message);
    //
    //    @Named("appUserId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    AppUserDTO toDtoAppUserId(AppUser appUser);
}
