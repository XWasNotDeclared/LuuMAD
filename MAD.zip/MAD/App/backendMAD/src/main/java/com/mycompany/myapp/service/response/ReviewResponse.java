package com.mycompany.myapp.service.response;

import lombok.Data;

@Data
public class ReviewResponse {

    private String reviewerName;
    private String comment;
}
