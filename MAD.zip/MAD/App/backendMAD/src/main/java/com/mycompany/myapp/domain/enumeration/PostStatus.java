package com.mycompany.myapp.domain.enumeration;

/**
 * The PostStatus enumeration.
 */
public enum PostStatus {
    DRAFT,
    PUBLISHED,
    CLOSED,
    DELETED,
}
