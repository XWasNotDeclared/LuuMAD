package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Employer} and its DTO {@link EmployerDTO}.
 */
//@Mapper(componentModel = "spring")
@Mapper(componentModel = "spring", uses = { AppUserMapper.class })
public interface EmployerMapper extends EntityMapper<EmployerDTO, Employer> {
    //    @Mapping(target = "appUser", source = "appUser", qualifiedByName = "appUserId")
    //    EmployerDTO toDto(Employer s);

    @Mapping(target = "appUser", source = "appUser") // full mapping
    EmployerDTO toDto(Employer employer);

    @Mapping(target = "appUser", source = "appUser")
    Employer toEntity(EmployerDTO employerDTO);

    @Named("appUserId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    AppUserDTO toDtoAppUserId(AppUser appUser);
}
