package com.mycompany.myapp.service.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.mycompany.myapp.domain.enumeration.JobType;
import com.mycompany.myapp.service.impl.CustomDateDeserializer;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostFilterDTO {

    private List<JobType> jobTypes;
    private Integer experienceStart;
    private Integer experienceEnd;
    private String location; // On-site, Remote
    private String city; // Trích từ address
    private Long salaryMin;
    private Long salaryMax;
    private String salaryCurrency;

    @JsonDeserialize(using = CustomDateDeserializer.class)
    private Instant startDate;

    @JsonDeserialize(using = CustomDateDeserializer.class)
    private Instant endDate;

    private Long categoryId;
    private String positionName;
    // getter/setter
}
