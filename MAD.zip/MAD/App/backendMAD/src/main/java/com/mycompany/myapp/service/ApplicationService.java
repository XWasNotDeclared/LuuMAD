package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.Application;
import com.mycompany.myapp.service.dto.ApplicationDTO;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.mycompany.myapp.domain.Application}.
 */
public interface ApplicationService {
    /**
     * Save a application.
     *
     * @param applicationDTO the entity to save.
     * @return the persisted entity.
     */
    ApplicationDTO save(ApplicationDTO applicationDTO);

    /**
     * Updates a application.
     *
     * @param applicationDTO the entity to update.
     * @return the persisted entity.
     */
    ApplicationDTO update(ApplicationDTO applicationDTO);

    /**
     * Partially updates a application.
     *
     * @param applicationDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<ApplicationDTO> partialUpdate(ApplicationDTO applicationDTO);

    /**
     * Get all the applications.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<ApplicationDTO> findAll(Pageable pageable);

    /**
     * Get the "id" application.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<ApplicationDTO> findOne(Long id);

    /**
     * Delete the "id" application.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    public default ApplicationDTO convertToDTO(Application application) {
        ApplicationDTO dto = new ApplicationDTO();
        dto.setId(application.getId());
        dto.setAppliedAt(application.getAppliedAt());
        dto.setCoverLetter(application.getCoverLetter());
        dto.setCvLink(application.getCvLink());
        dto.setTimeslot(application.getTimeslot());
        dto.setStatus(application.getStatus());
        dto.setIsRead(application.getIsRead());
        dto.setIsDelete(application.getIsDelete());

        if (application.getPost() != null) {
            dto.setPostId(application.getPost().getId());

            if (application.getPost().getEmployer() != null) {
                dto.setEmployerId(application.getPost().getEmployer().getId());
            }
        }

        if (application.getJobSeeker() != null) {
            dto.setJobSeekerId(application.getJobSeeker().getId());
        }

        return dto;
    }

    List<ApplicationDTO> findByEmployerIdAndIsDeleteFalse(Long employerId);
    Optional<ApplicationDTO> softDeleteById(Long id);

    Optional<ApplicationDTO> softReadById(Long id);

    Optional<ApplicationDTO> softNotReadById(Long id);

    void markAllByEmployerIdAsDeleted(Long employerId);

    void markAllByEmployerIdAsRead(Long employerId);

    boolean existsByPostIdAndJobSeekerId(Long postId, Long jobSeekerId);

    /**
     * Count unread applications by employer ID.
     *
     * @param employerId the ID of the employer.
     * @return the count of unread applications.
     */
    long countUnreadByEmployerId(Long employerId);
}
