package com.mycompany.myapp.service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDTO<T> {

    private boolean success;
    private String message;
    private T data;

    public static <T> ResponseDTO<T> success(String msg, T data) {
        return new ResponseDTO<>(true, msg, data);
    }

    public static <T> ResponseDTO<T> error(String msg) {
        return new ResponseDTO<>(false, msg, null);
    }
}
