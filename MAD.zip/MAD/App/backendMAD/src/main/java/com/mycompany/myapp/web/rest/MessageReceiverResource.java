package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.repository.MessageReceiverRepository;
import com.mycompany.myapp.service.MessageReceiverService;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.MessageReceiver}.
 */
@RestController
@RequestMapping("/api/app")
public class MessageReceiverResource {

    private final Logger log = LoggerFactory.getLogger(MessageReceiverResource.class);

    private static final String ENTITY_NAME = "messageReceiver";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final MessageReceiverService messageReceiverService;

    private final MessageReceiverRepository messageReceiverRepository;

    public MessageReceiverResource(MessageReceiverService messageReceiverService, MessageReceiverRepository messageReceiverRepository) {
        this.messageReceiverService = messageReceiverService;
        this.messageReceiverRepository = messageReceiverRepository;
    }

    /**
     * {@code POST  /message-receivers} : Create a new messageReceiver.
     *
     * @param messageReceiverDTO the messageReceiverDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new messageReceiverDTO, or with status {@code 400 (Bad Request)} if the messageReceiver has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/message-receivers")
    public ResponseEntity<MessageReceiverDTO> createMessageReceiver(@RequestBody MessageReceiverDTO messageReceiverDTO)
        throws URISyntaxException {
        log.debug("REST request to save MessageReceiver : {}", messageReceiverDTO);
        if (messageReceiverDTO.getId() != null) {
            throw new BadRequestAlertException("A new messageReceiver cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MessageReceiverDTO result = messageReceiverService.save(messageReceiverDTO);
        return ResponseEntity
            .created(new URI("/api/message-receivers/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /message-receivers/:id} : Updates an existing messageReceiver.
     *
     * @param id the id of the messageReceiverDTO to save.
     * @param messageReceiverDTO the messageReceiverDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated messageReceiverDTO,
     * or with status {@code 400 (Bad Request)} if the messageReceiverDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the messageReceiverDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/message-receivers/{id}")
    public ResponseEntity<MessageReceiverDTO> updateMessageReceiver(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody MessageReceiverDTO messageReceiverDTO
    ) throws URISyntaxException {
        log.debug("REST request to update MessageReceiver : {}, {}", id, messageReceiverDTO);
        if (messageReceiverDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, messageReceiverDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!messageReceiverRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        MessageReceiverDTO result = messageReceiverService.update(messageReceiverDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, messageReceiverDTO.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /message-receivers/:id} : Partial updates given fields of an existing messageReceiver, field will ignore if it is null
     *
     * @param id the id of the messageReceiverDTO to save.
     * @param messageReceiverDTO the messageReceiverDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated messageReceiverDTO,
     * or with status {@code 400 (Bad Request)} if the messageReceiverDTO is not valid,
     * or with status {@code 404 (Not Found)} if the messageReceiverDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the messageReceiverDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/message-receivers/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<MessageReceiverDTO> partialUpdateMessageReceiver(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody MessageReceiverDTO messageReceiverDTO
    ) throws URISyntaxException {
        log.debug("REST request to partial update MessageReceiver partially : {}, {}", id, messageReceiverDTO);
        if (messageReceiverDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, messageReceiverDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!messageReceiverRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<MessageReceiverDTO> result = messageReceiverService.partialUpdate(messageReceiverDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, messageReceiverDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /message-receivers} : get all the messageReceivers.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of messageReceivers in body.
     */
    @GetMapping("/message-receivers")
    public ResponseEntity<List<MessageReceiverDTO>> getAllMessageReceivers(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable
    ) {
        log.debug("REST request to get a page of MessageReceivers");
        Page<MessageReceiverDTO> page = messageReceiverService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /message-receivers/:id} : get the "id" messageReceiver.
     *
     * @param id the id of the messageReceiverDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the messageReceiverDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/message-receivers/{id}")
    public ResponseEntity<MessageReceiverDTO> getMessageReceiver(@PathVariable Long id) {
        log.debug("REST request to get MessageReceiver : {}", id);
        Optional<MessageReceiverDTO> messageReceiverDTO = messageReceiverService.findOne(id);
        return ResponseUtil.wrapOrNotFound(messageReceiverDTO);
    }

    /**
     * {@code DELETE  /message-receivers/:id} : delete the "id" messageReceiver.
     *
     * @param id the id of the messageReceiverDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/message-receivers/{id}")
    public ResponseEntity<Void> deleteMessageReceiver(@PathVariable Long id) {
        log.debug("REST request to delete MessageReceiver : {}", id);
        messageReceiverService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
