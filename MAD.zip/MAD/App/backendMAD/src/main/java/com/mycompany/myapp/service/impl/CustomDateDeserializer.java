package com.mycompany.myapp.service.impl;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class CustomDateDeserializer extends JsonDeserializer<Instant> {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    @Override
    public Instant deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        String dateStr = p.getText().trim();

        try {
            // First try to parse as date-time
            LocalDateTime dateTime = LocalDateTime.parse(dateStr, DATE_TIME_FORMATTER);
            return dateTime.toInstant(ZoneOffset.UTC);
        } catch (DateTimeParseException e) {
            // If that fails, try to parse as date-only
            try {
                LocalDate localDate = LocalDate.parse(dateStr, DATE_FORMATTER);
                return localDate.atStartOfDay(ZoneOffset.UTC).toInstant();
            } catch (DateTimeParseException ex) {
                throw new IOException("Date must be in format dd/MM/yyyy or dd/MM/yyyy HH:mm:ss", ex);
            }
        }
    }
}
