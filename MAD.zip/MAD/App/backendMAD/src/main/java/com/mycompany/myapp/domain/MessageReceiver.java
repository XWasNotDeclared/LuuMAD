package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.io.Serializable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * A MessageReceiver.
 */
@Entity
@Table(name = "message_receiver")
@EntityListeners(AuditingEntityListener.class)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class MessageReceiver implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "is_read")
    private Boolean isRead;

    @Column(name = "is_notified")
    private Boolean isNotified = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "sender" }, allowSetters = true)
    private Message message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "jobSeeker", "employer" }, allowSetters = true)
    private AppUser receiver;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public MessageReceiver id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsRead() {
        return this.isRead;
    }

    public MessageReceiver isRead(Boolean isRead) {
        this.setIsRead(isRead);
        return this;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Boolean getIsNotified() {
        return this.isNotified;
    }

    public MessageReceiver isNotified(Boolean setIsNotified) {
        this.setIsNotified(isNotified);
        return this;
    }

    public void setIsNotified(Boolean isNotified) {
        this.isNotified = isNotified;
    }

    public Message getMessage() {
        return this.message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public MessageReceiver message(Message message) {
        this.setMessage(message);
        return this;
    }

    public AppUser getReceiver() {
        return this.receiver;
    }

    public void setReceiver(AppUser appUser) {
        this.receiver = appUser;
    }

    public MessageReceiver receiver(AppUser appUser) {
        this.setReceiver(appUser);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MessageReceiver)) {
            return false;
        }
        return getId() != null && getId().equals(((MessageReceiver) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "MessageReceiver{" +
            "id=" + getId() +
            ", isRead='" + getIsRead() + "'" +
            "}";
    }
}
