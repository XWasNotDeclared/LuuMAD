package com.mycompany.myapp.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class ClerkService {

    @Value("${clerk.secret-key}")
    private String clerkSecretKey;

    private static final String BASE_URL = "https://api.clerk.com/v1";
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ClerkService() {
        this.restTemplate = new RestTemplate();
    }

    public String getEmailFromSessionId(String sessionId) {
        try {
            // Step 1: Lấy user_id từ session
            String sessionUrl = BASE_URL + "/sessions/" + sessionId;
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(clerkSecretKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Void> entity = new HttpEntity<>(headers);
            ResponseEntity<String> sessionResponse = restTemplate.exchange(sessionUrl, HttpMethod.GET, entity, String.class);

            if (!sessionResponse.getStatusCode().is2xxSuccessful()) {
                log.error("Failed to get session from Clerk. Status: {}", sessionResponse.getStatusCode());
                return null;
            }

            JsonNode sessionBody = objectMapper.readTree(sessionResponse.getBody());
            String userId = sessionBody.get("user_id").asText(null);
            if (userId == null) {
                log.error("user_id not found in session");
                return null;
            }

            // Step 2: Lấy thông tin user
            String userUrl = BASE_URL + "/users/" + userId;
            ResponseEntity<String> userResponse = restTemplate.exchange(userUrl, HttpMethod.GET, entity, String.class);

            if (!userResponse.getStatusCode().is2xxSuccessful()) {
                log.error("Failed to get user from Clerk. Status: {}", userResponse.getStatusCode());
                return null;
            }

            JsonNode userBody = objectMapper.readTree(userResponse.getBody());

            // Lấy primary_email_address_id
            String primaryEmailId = userBody.get("primary_email_address_id").asText(null);
            if (primaryEmailId == null) {
                log.error("primary_email_address_id is null");
                return null;
            }

            // Duyệt qua mảng email_addresses để tìm email có id trùng
            JsonNode emailAddresses = userBody.get("email_addresses");
            if (emailAddresses == null || !emailAddresses.isArray()) {
                log.error("email_addresses is missing or invalid");
                return null;
            }

            for (JsonNode emailNode : emailAddresses) {
                String id = emailNode.get("id").asText("");
                if (primaryEmailId.equals(id)) {
                    return emailNode.get("email_address").asText(null);
                }
            }

            log.error("No email found matching primary_email_address_id");
            return null;
        } catch (Exception e) {
            log.error("Error getting email from Clerk session", e);
            return null;
        }
    }
}
