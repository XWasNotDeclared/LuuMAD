package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.Application;
import com.mycompany.myapp.repository.ApplicationRepository;
import com.mycompany.myapp.service.ApplicationService;
import com.mycompany.myapp.service.dto.ApplicationDTO;
import com.mycompany.myapp.service.mapper.ApplicationMapper;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Application}.
 */
@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

    private static final Logger LOG = LoggerFactory.getLogger(ApplicationServiceImpl.class);

    private final ApplicationRepository applicationRepository;

    private final ApplicationMapper applicationMapper;

    public ApplicationServiceImpl(ApplicationRepository applicationRepository, ApplicationMapper applicationMapper) {
        this.applicationRepository = applicationRepository;
        this.applicationMapper = applicationMapper;
    }

    @Override
    public ApplicationDTO save(ApplicationDTO applicationDTO) {
        LOG.debug("Request to save Application : {}", applicationDTO);
        Application application = applicationMapper.toEntity(applicationDTO);
        application = applicationRepository.save(application);
        return applicationMapper.toDto(application);
    }

    @Override
    public ApplicationDTO update(ApplicationDTO applicationDTO) {
        LOG.debug("Request to update Application : {}", applicationDTO);
        Application application = applicationMapper.toEntity(applicationDTO);
        application = applicationRepository.save(application);
        return applicationMapper.toDto(application);
    }

    @Override
    public Optional<ApplicationDTO> partialUpdate(ApplicationDTO applicationDTO) {
        LOG.debug("Request to partially update Application : {}", applicationDTO);

        return applicationRepository
            .findById(applicationDTO.getId())
            .map(existingApplication -> {
                applicationMapper.partialUpdate(existingApplication, applicationDTO);

                return existingApplication;
            })
            .map(applicationRepository::save)
            .map(applicationMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ApplicationDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Applications");
        return applicationRepository.findAll(pageable).map(applicationMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ApplicationDTO> findOne(Long id) {
        LOG.debug("Request to get Application : {}", id);
        return applicationRepository.findById(id).map(applicationMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Application : {}", id);
        applicationRepository.deleteById(id);
    }

    @Override
    public List<ApplicationDTO> findByEmployerIdAndIsDeleteFalse(Long employerId) {
        LOG.debug("Request to get Applications by employerId: {}", employerId);
        List<Application> applications = applicationRepository.findByEmployerIdAndIsDeleteFalse(employerId);
        return applications.stream().map(applicationMapper::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public Optional<ApplicationDTO> softDeleteById(Long id) {
        LOG.debug("Request to soft delete Application : {}", id);
        return applicationRepository
            .findById(id)
            .map(application -> {
                application.setIsDelete(true);
                return applicationRepository.save(application);
            })
            .map(applicationMapper::toDto);
    }

    //    @Override
    //    @Transactional
    //    public Optional<ApplicationDTO> softReadById(Long id) {
    //        LOG.debug("Request to soft read Application : {}", id);
    //        return applicationRepository
    //            .findById(id)
    //            .map(application -> {
    //                application.setIsRead(true);
    //                return applicationRepository.save(application);
    //            })
    //            .map(applicationMapper::toDto);
    //    }
    //
    //    @Override
    //    @Transactional
    //    public Optional<ApplicationDTO> softNotReadById(Long id) {
    //        LOG.debug("Request to soft read Application : {}", id);
    //        return applicationRepository
    //            .findById(id)
    //            .map(application -> {
    //                application.setIsRead(false);
    //                return applicationRepository.save(application);
    //            })
    //            .map(applicationMapper::toDto);
    //        }

    @Override
    @Transactional
    public Optional<ApplicationDTO> softReadById(Long id) {
        LOG.debug("Request to soft read Application : {}", id);
        Optional<Application> application = applicationRepository.findById(id);

        if (application.isPresent()) {
            Application app = application.get();
            app.setIsRead(true);
            app = applicationRepository.saveAndFlush(app); // Use saveAndFlush to commit changes immediately
            return Optional.of(applicationMapper.toDto(app));
        }

        return Optional.empty();
    }

    @Override
    @Transactional
    public Optional<ApplicationDTO> softNotReadById(Long id) {
        LOG.debug("Request to soft not read Application : {}", id);
        Optional<Application> application = applicationRepository.findById(id);

        if (application.isPresent()) {
            Application app = application.get();
            app.setIsRead(false);
            app = applicationRepository.saveAndFlush(app); // Use saveAndFlush to commit changes immediately
            return Optional.of(applicationMapper.toDto(app));
        }

        return Optional.empty();
    }

    @Override
    @Transactional
    public void markAllByEmployerIdAsDeleted(Long employerId) {
        LOG.debug("Mark all applications as deleted for employerId : {}", employerId);
        applicationRepository.markAllByEmployerIdAsDeleted(employerId);
    }

    @Override
    @Transactional
    public void markAllByEmployerIdAsRead(Long employerId) {
        LOG.debug("Mark all applications as read for employerId : {}", employerId);
        applicationRepository.markAllByEmployerIdAsRead(employerId);
    }

    @Override
    public boolean existsByPostIdAndJobSeekerId(Long postId, Long jobSeekerId) {
        return applicationRepository.existsByPostIdAndJobSeekerId(postId, jobSeekerId);
    }

    @Override
    @Transactional(readOnly = true)
    public long countUnreadByEmployerId(Long employerId) {
        applicationRepository.flush();
        LOG.debug("Request to count unread Applications for employerId : {}", employerId);
        return applicationRepository.countByEmployerIdAndIsReadFalseAndIsDeleteFalse(employerId);
    }
}
