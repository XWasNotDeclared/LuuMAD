package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.JobSeeker;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the JobSeeker entity.
 *
 * When extending this class, extend JobSeekerRepositoryWithBagRelationships too.
 * For more information refer to https://github.com/jhipster/generator-jhipster/issues/17990.
 */
@Repository
public interface JobSeekerRepository extends JobSeekerRepositoryWithBagRelationships, JpaRepository<JobSeeker, Long> {
    JobSeeker findByAppUserId(Long id);

    default Optional<JobSeeker> findOneWithEagerRelationships(Long id) {
        return this.fetchBagRelationships(this.findById(id));
    }

    default List<JobSeeker> findAllWithEagerRelationships() {
        return this.fetchBagRelationships(this.findAll());
    }

    default Page<JobSeeker> findAllWithEagerRelationships(Pageable pageable) {
        return this.fetchBagRelationships(this.findAll(pageable));
    }

    @Query(
        """
                SELECT j FROM JobSeeker j
                JOIN Application a ON a.jobSeeker.id = j.id
                WHERE a.post.id = :postId
        """
    )
    List<JobSeeker> findJobSeekerByPostId(@Param("postId") Long postId);

    @Query(
        """
            SELECT j FROM JobSeeker j
            JOIN Contract c ON c.jobSeeker.id = j.id
            WHERE c.employer.id = :employerId
        """
    )
    List<JobSeeker> findJobSeekerByEmployerId(@Param("employerId") Long employerId);

    @Query(
        """
            SELECT j FROM JobSeeker j
            WHERE j.appUser.id = :appUserId
        """
    )
    JobSeeker findJobSeekerByAppUserId(@Param("appUserId") Long appUserId);

    @Query(
        "SELECT DISTINCT js FROM JobSeeker js " +
        "LEFT JOIN FETCH js.positions p " +
        "LEFT JOIN FETCH p.category " +
        "LEFT JOIN FETCH js.experiences " +
        "LEFT JOIN FETCH js.appUser"
    )
    List<JobSeeker> findAllWithEagerRelationshipsFilter();

    @Query("SELECT js FROM JobSeeker js JOIN js.positions p WHERE p.id = :positionId")
    List<JobSeeker> findByPositionId(@Param("positionId") Long positionId);
}
