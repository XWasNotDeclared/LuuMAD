package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.AppUser;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the AppUser entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AppUserRepository extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByEmail(String email);

    Page<AppUser> findByFullNameContainingIgnoreCase(String keyword, Pageable pageable);

    Optional<AppUser> findByJobSeekerId(Long jobSeekerId);

    @Query(
        """
        SELECT au FROM AppUser au
        JOIN au.jobSeeker js
        JOIN js.positions p
        WHERE p.id = :positionId
        """
    )
    List<AppUser> findAppUsersByPositionId(@Param("positionId") Long positionId);
}
