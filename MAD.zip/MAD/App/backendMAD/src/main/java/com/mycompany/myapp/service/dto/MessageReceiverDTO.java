package com.mycompany.myapp.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.MessageReceiver} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class MessageReceiverDTO implements Serializable {

    private Long id;

    private Boolean isRead;

    private Boolean isNotified = false;

    private MessageDTO message;

    private AppUserDTO receiver;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Boolean getIsNotified() {
        return isNotified;
    }

    public void setIsNotified(Boolean isNotified) {
        this.isNotified = isNotified;
    }

    public MessageDTO getMessage() {
        return message;
    }

    public void setMessage(MessageDTO message) {
        this.message = message;
    }

    public AppUserDTO getReceiver() {
        return receiver;
    }

    public void setReceiver(AppUserDTO receiver) {
        this.receiver = receiver;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MessageReceiverDTO)) {
            return false;
        }

        MessageReceiverDTO messageReceiverDTO = (MessageReceiverDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, messageReceiverDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "MessageReceiverDTO{" +
            "id=" + getId() +
            ", isRead='" + getIsRead() + "'" +
            ", message=" + getMessage() +
            ", receiver=" + getReceiver() +
            "}";
    }
}
