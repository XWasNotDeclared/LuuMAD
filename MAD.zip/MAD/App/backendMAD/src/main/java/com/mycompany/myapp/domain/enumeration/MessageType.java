package com.mycompany.myapp.domain.enumeration;

/**
 * The MessageType enumeration.
 */
public enum MessageType {
    TEXT,
    IMAGE,
    FILE,
    VIDEO_CALL,
}
