package com.mycompany.myapp.domain.enumeration;

/**
 * The JobType enumeration.
 */
public enum JobType {
    FULL_TIME,
    PART_TIME,
    FREELANCE,
    INTERNSHIP,
}
