package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;

/**
 * A NotificationReceiver.
 */
@Entity
@Table(name = "notification_receiver")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class NotificationReceiver implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "is_read", nullable = false)
    private Boolean isRead;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "sender" }, allowSetters = true)
    private Notification notification;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "jobSeeker", "employer" }, allowSetters = true)
    private AppUser receiver;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public NotificationReceiver id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsRead() {
        return this.isRead;
    }

    public NotificationReceiver isRead(Boolean isRead) {
        this.setIsRead(isRead);
        return this;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Notification getNotification() {
        return this.notification;
    }

    public void setNotification(Notification notification) {
        this.notification = notification;
    }

    public NotificationReceiver notification(Notification notification) {
        this.setNotification(notification);
        return this;
    }

    public AppUser getReceiver() {
        return this.receiver;
    }

    public void setReceiver(AppUser appUser) {
        this.receiver = appUser;
    }

    public NotificationReceiver receiver(AppUser appUser) {
        this.setReceiver(appUser);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof NotificationReceiver)) {
            return false;
        }
        return getId() != null && getId().equals(((NotificationReceiver) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "NotificationReceiver{" +
            "id=" + getId() +
            ", isRead='" + getIsRead() + "'" +
            "}";
    }
}
