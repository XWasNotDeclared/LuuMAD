package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.repository.EmployerRepository;
import com.mycompany.myapp.service.EmployerService;
import com.mycompany.myapp.service.JwtService;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.request.EmployerInfoRequest;
import com.mycompany.myapp.service.dto.response.CompanyInforResponse;
import com.mycompany.myapp.service.response.CompanyDetailResponse;
import com.mycompany.myapp.service.response.JobSeekerResponse;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.Employer}.
 */
@RestController
@RequestMapping("/api/app/employers")
@RequiredArgsConstructor
public class EmployerResource {

    private static final Logger LOG = LoggerFactory.getLogger(EmployerResource.class);

    private static final String ENTITY_NAME = "employer";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final EmployerService employerService;

    private final EmployerRepository employerRepository;
    private final JwtService jwtService;

    @GetMapping("/my-connection")
    @Operation(summary = "get connection of job_seeker (menu: my connection - role: job_seeker)")
    public ResponseEntity<List<JobSeekerResponse>> findEmployerByJobSeekerId(HttpServletRequest request) {
        String token = getJwtFromRequest(request);
        Long jobseekerId = jwtService.getIdFromToken(token);
        return ResponseEntity.ok(employerService.findEmployerByJobSeekerId(jobseekerId));
    }

    @GetMapping("/detail")
    @Operation(summary = "get employer detail ")
    public ResponseEntity<CompanyDetailResponse> findEmployerById(@RequestParam("employerId") Long employerId) {
        return ResponseEntity.ok(employerService.findEmployerById(employerId));
    }

    private String getJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        // Kiểm tra xem header Authorization có chứa thông tin jwt không
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    @PatchMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<EmployerDTO> partialUpdateEmployer(
        @PathVariable("id") Long id,
        @ModelAttribute EmployerInfoRequest employerInfoRequest
    ) {
        EmployerDTO result = employerService.partialUpdateEmployer(id, employerInfoRequest);
        if (result == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(result);
    }

    /**
     * {@code POST  /employers} : Create a new employer.
     *
     * @param employerDTO the employerDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new employerDTO, or with status {@code 400 (Bad Request)} if the employer has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<EmployerDTO> createEmployer(@Valid @RequestBody EmployerDTO employerDTO) throws URISyntaxException {
        LOG.debug("REST request to save Employer : {}", employerDTO);
        if (employerDTO.getId() != null) {
            throw new BadRequestAlertException("A new employer cannot already have an ID", ENTITY_NAME, "idexists");
        }
        employerDTO = employerService.save(employerDTO);
        return ResponseEntity
            .created(new URI("/api/employers/" + employerDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, employerDTO.getId().toString()))
            .body(employerDTO);
    }

    /**
     * {@code PUT  /employers/:id} : Updates an existing employer.
     *
     * @param id the id of the employerDTO to save.
     * @param employerDTO the employerDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated employerDTO,
     * or with status {@code 400 (Bad Request)} if the employerDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the employerDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<EmployerDTO> updateEmployer(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody EmployerDTO employerDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update Employer : {}, {}", id, employerDTO);
        if (employerDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, employerDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!employerRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        employerDTO = employerService.update(employerDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, employerDTO.getId().toString()))
            .body(employerDTO);
    }

    /**
     * {@code PATCH  /employers/:id} : Partial updates given fields of an existing employer, field will ignore if it is null
     *
     * @param id the id of the employerDTO to save.
     * @param employerDTO the employerDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated employerDTO,
     * or with status {@code 400 (Bad Request)} if the employerDTO is not valid,
     * or with status {@code 404 (Not Found)} if the employerDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the employerDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<EmployerDTO> partialUpdateEmployer(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody EmployerDTO employerDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update Employer partially : {}, {}", id, employerDTO);
        if (employerDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, employerDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!employerRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<EmployerDTO> result = employerService.partialUpdate(employerDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, employerDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /employers} : get all the employers.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of employers in body.
     */
    @GetMapping("")
    public ResponseEntity<List<EmployerDTO>> getAllEmployers(@org.springdoc.core.annotations.ParameterObject Pageable pageable) {
        LOG.debug("REST request to get a page of Employers");
        Page<EmployerDTO> page = employerService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /employers/:id} : get the "id" employer.
     *
     * @param id the id of the employerDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the employerDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<EmployerDTO> getEmployer(@PathVariable("id") Long id) {
        LOG.debug("REST request to get Employer : {}", id);
        Optional<EmployerDTO> employerDTO = employerService.findOne(id);
        return ResponseUtil.wrapOrNotFound(employerDTO);
    }

    /**
     * {@code DELETE  /employers/:id} : delete the "id" employer.
     *
     * @param id the id of the employerDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployer(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete Employer : {}", id);
        employerService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
