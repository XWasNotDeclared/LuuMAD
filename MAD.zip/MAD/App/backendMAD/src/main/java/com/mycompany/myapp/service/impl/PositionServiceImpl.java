package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.repository.PositionRepository;
import com.mycompany.myapp.service.PositionService;
import com.mycompany.myapp.service.dto.PositionDTO;
import com.mycompany.myapp.service.mapper.PositionMapper;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Position}.
 */
@Service
@Transactional
public class PositionServiceImpl implements PositionService {

    @Override
    public List<PositionDTO> getTop3PositionsWithMostJobSeekers() {
        // Truy vấn top 3 position có nhiều jobSeekers nhất
        List<Position> positions = positionRepository.findTop3ByOrderByJobSeekersSizeDesc();
        List<Position> top3Positions = positions.size() > 3 ? positions.subList(0, 3) : positions;
        // Chuyển đổi danh sách Position thành danh sách PositionDTO
        return top3Positions.stream().map(positionMapper::toDto).collect(Collectors.toList());
        //        return List.of();
    }

    private static final Logger LOG = LoggerFactory.getLogger(PositionServiceImpl.class);

    private final PositionRepository positionRepository;

    private final PositionMapper positionMapper;

    public PositionServiceImpl(PositionRepository positionRepository, PositionMapper positionMapper) {
        this.positionRepository = positionRepository;
        this.positionMapper = positionMapper;
    }

    @Override
    public Page<PositionDTO> searchPositionsByName(String keyword, Pageable pageable) {
        Page<Position> positions = positionRepository.findByNameContainingIgnoreCase(keyword, pageable);
        return positions.map(positionMapper::toDto);
    }

    @Override
    public List<PositionDTO> getPositionsByJobSeekerId(Long jobSeekerId) {
        return positionRepository.findByJobSeekers_Id(jobSeekerId).stream().map(positionMapper::toDto).collect(Collectors.toList());
    }

    @Override
    public PositionDTO save(PositionDTO positionDTO) {
        LOG.debug("Request to save Position : {}", positionDTO);
        Position position = positionMapper.toEntity(positionDTO);
        position = positionRepository.save(position);
        return positionMapper.toDto(position);
    }

    @Override
    public PositionDTO update(PositionDTO positionDTO) {
        LOG.debug("Request to update Position : {}", positionDTO);
        Position position = positionMapper.toEntity(positionDTO);
        position = positionRepository.save(position);
        return positionMapper.toDto(position);
    }

    @Override
    public Optional<PositionDTO> partialUpdate(PositionDTO positionDTO) {
        LOG.debug("Request to partially update Position : {}", positionDTO);

        return positionRepository
            .findById(positionDTO.getId())
            .map(existingPosition -> {
                positionMapper.partialUpdate(existingPosition, positionDTO);

                return existingPosition;
            })
            .map(positionRepository::save)
            .map(positionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PositionDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Positions");
        return positionRepository.findAll(pageable).map(positionMapper::toDto);
    }

    public Page<PositionDTO> findAllWithEagerRelationships(Pageable pageable) {
        return positionRepository.findAllWithEagerRelationships(pageable).map(positionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PositionDTO> findOne(Long id) {
        LOG.debug("Request to get Position : {}", id);
        return positionRepository.findOneWithEagerRelationships(id).map(positionMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Position : {}", id);
        positionRepository.deleteById(id);
    }

    @Override
    public List<PositionDTO> findTop3PopularPositions() {
        List<Position> positions = positionRepository.findTop3ByJobSeekersCount();
        return positions
            .stream()
            .limit(3) // đảm bảo chỉ lấy 3 phần tử
            .map(positionMapper::toDto)
            .toList();
    }
}
