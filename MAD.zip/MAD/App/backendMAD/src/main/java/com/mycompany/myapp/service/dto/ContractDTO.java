package com.mycompany.myapp.service.dto;

import com.mycompany.myapp.domain.enumeration.ContractStatus;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.Contract} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class ContractDTO implements Serializable {

    private Long id;

    private String contractTerm;

    private Instant createdDate;

    private Instant endDate;

    private Integer salary;

    private Instant startDate;

    @NotNull
    private ContractStatus status;

    private JobSeekerDTO jobSeeker;

    private EmployerDTO employer;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContractTerm() {
        return contractTerm;
    }

    public void setContractTerm(String contractTerm) {
        this.contractTerm = contractTerm;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public Instant getEndDate() {
        return endDate;
    }

    public void setEndDate(Instant endDate) {
        this.endDate = endDate;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public Instant getStartDate() {
        return startDate;
    }

    public void setStartDate(Instant startDate) {
        this.startDate = startDate;
    }

    public ContractStatus getStatus() {
        return status;
    }

    public void setStatus(ContractStatus status) {
        this.status = status;
    }

    public JobSeekerDTO getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(JobSeekerDTO jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

    public EmployerDTO getEmployer() {
        return employer;
    }

    public void setEmployer(EmployerDTO employer) {
        this.employer = employer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ContractDTO)) {
            return false;
        }

        ContractDTO contractDTO = (ContractDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, contractDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "ContractDTO{" +
            "id=" + getId() +
            ", contractTerm='" + getContractTerm() + "'" +
            ", createdDate='" + getCreatedDate() + "'" +
            ", endDate='" + getEndDate() + "'" +
            ", salary=" + getSalary() +
            ", startDate='" + getStartDate() + "'" +
            ", status='" + getStatus() + "'" +
            ", jobSeeker=" + getJobSeeker() +
            ", employer=" + getEmployer() +
            "}";
    }
}
