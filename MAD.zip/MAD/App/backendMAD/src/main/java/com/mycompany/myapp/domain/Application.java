package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mycompany.myapp.domain.enumeration.ApplicationStatus;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.Instant;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * A Application.
 */
@Entity
@Table(name = "application")
@EntityListeners(AuditingEntityListener.class)
public class Application implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ApplicationStatus status;

    @Column(name = "applied_at")
    @CreatedDate
    private Instant appliedAt;

    @Lob
    @Column(name = "cover_letter")
    private String coverLetter;

    @Column(name = "cv_link")
    private String cvLink;

    @Column(name = "timeslot")
    private String timeslot;

    @Column(name = "isRead", nullable = false)
    private Boolean isRead = false;

    @Column(name = "isDelete", nullable = false)
    private Boolean isDelete = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "appUser" }, allowSetters = true)
    private JobSeeker jobSeeker;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "position", "employer" }, allowSetters = true)
    private Post post;

    @JsonIgnoreProperties(value = { "application" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private ApplicationSchedule applicationSchedule;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    // Getter, Setter

    public ApplicationSchedule getApplicationSchedule() {
        return applicationSchedule;
    }

    public void setApplicationSchedule(ApplicationSchedule applicationSchedule) {
        this.applicationSchedule = applicationSchedule;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public void setStatus(ApplicationStatus status) {
        this.status = status;
    }

    public Instant getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(Instant appliedAt) {
        this.appliedAt = appliedAt;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public String getCvLink() {
        return cvLink;
    }

    public void setCvLink(String cvLink) {
        this.cvLink = cvLink;
    }

    public String getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(String timeslot) {
        this.timeslot = timeslot;
    }

    //    public void setIsRead(Boolean isRead) {
    //        this.isRead = isRead;
    //    }
    //
    //    public Boolean getIsRead() {
    //        return isRead;
    //    }
    //
    //    public Boolean getIsDelete() {
    //        return isDelete;
    //    }
    //
    //    public void setIsDelete(Boolean delete) {
    //        isDelete = delete;
    //    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Boolean getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Boolean isDelete) {
        this.isDelete = isDelete;
    }

    public JobSeeker getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(JobSeeker jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    @Override
    public String toString() {
        return (
            "Application{" +
            "id=" +
            id +
            ", status=" +
            status +
            ", appliedAt=" +
            appliedAt +
            ", coverLetter='" +
            coverLetter +
            '\'' +
            ", cvLink='" +
            cvLink +
            '\'' +
            ", timeslot='" +
            timeslot +
            '\'' +
            ", isRead=" +
            isRead +
            ", isDelete=" +
            isDelete +
            ", jobSeeker=" +
            (jobSeeker != null ? jobSeeker.getId() : null) +
            ", post=" +
            (post != null ? post.getId() : null) +
            '}'
        );
    }
}
