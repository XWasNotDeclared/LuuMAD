package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.ApplicationSchedule;
import com.mycompany.myapp.service.dto.ApplicationScheduleDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link ApplicationSchedule} and its DTO {@link ApplicationScheduleDTO}.
 */
@Mapper(componentModel = "spring")
public interface ApplicationScheduleMapper extends EntityMapper<ApplicationScheduleDTO, ApplicationSchedule> {}
