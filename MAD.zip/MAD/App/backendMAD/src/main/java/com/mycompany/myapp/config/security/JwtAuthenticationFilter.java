package com.mycompany.myapp.config.security;

import com.mycompany.myapp.repository.AppUserRepository;
import com.mycompany.myapp.service.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final AppUserDetailsServiceImpl appUserDetailsService;

    @Bean
    public JwtService jwtService() {
        return new JwtService();
    }

    @Bean
    public AppUserDetailsServiceImpl appUserDetailsService(AppUserRepository appUserRepository) {
        return new AppUserDetailsServiceImpl(appUserRepository);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        // Bỏ qua kiểm tra JWT cho API applications
        if (request.getRequestURI().startsWith("/api/app/applications")) {
            filterChain.doFilter(request, response);
            return;
        }

        if (SecurityContextHolder.getContext().getAuthentication() == null) {
            extractToken(request)
                .flatMap(jwtService::validateToken)
                .ifPresent(jws -> {
                    String email = jws.getPayload().getSubject();
                    UserDetails userDetails = appUserDetailsService.loadUserByUsername(email);
                    var auth = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                });
        }

        filterChain.doFilter(request, response);
    }

    private Optional<String> extractToken(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        return (StringUtils.hasText(header) && header.startsWith("Bearer ")) ? Optional.of(header.substring(7)) : Optional.empty();
    }
}
