package com.mycompany.myapp.service.dto;

import java.time.Instant;

public class ApplicationCreateSimpleRequest {

    private String status;
    private Instant appliedAt;
    private String coverLetter;
    private Long jobSeekerID;
    private Long postID;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Instant getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(Instant appliedAt) {
        this.appliedAt = appliedAt;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public Long getJobSeekerID() {
        return jobSeekerID;
    }

    public void setJobSeekerID(Long jobSeekerID) {
        this.jobSeekerID = jobSeekerID;
    }

    public Long getPostID() {
        return postID;
    }

    public void setPostID(Long postID) {
        this.postID = postID;
    }
}
