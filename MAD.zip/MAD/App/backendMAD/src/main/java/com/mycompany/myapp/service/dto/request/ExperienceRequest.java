package com.mycompany.myapp.service.dto.request;

import jakarta.persistence.Lob;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ExperienceRequest {

    @NotNull
    private String companyName;

    @NotNull
    private String jobTitle;

    @Lob
    private String jobDescription;

    @NotNull
    private LocalDate startDate;

    private LocalDate endDate;

    private Boolean isCurrent;

    private Long jobSeerkerId;
}
