package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Position;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

/**
 * Utility repository to load bag relationships based on https://vladmihalcea.com/hibernate-multiplebagfetchexception/
 */
public class PositionRepositoryWithBagRelationshipsImpl implements PositionRepositoryWithBagRelationships {

    private static final String ID_PARAMETER = "id";
    private static final String POSITIONS_PARAMETER = "positions";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<Position> fetchBagRelationships(Optional<Position> position) {
        return position.map(this::fetchCategories);
    }

    @Override
    public Page<Position> fetchBagRelationships(Page<Position> positions) {
        return new PageImpl<>(fetchBagRelationships(positions.getContent()), positions.getPageable(), positions.getTotalElements());
    }

    @Override
    public List<Position> fetchBagRelationships(List<Position> positions) {
        return Optional.of(positions).map(this::fetchCategories).orElse(Collections.emptyList());
    }

    Position fetchCategories(Position result) {
        return entityManager
            .createQuery(
                "select position from Position position left join fetch position.categories where position.id = :id",
                Position.class
            )
            .setParameter(ID_PARAMETER, result.getId())
            .getSingleResult();
    }

    List<Position> fetchCategories(List<Position> positions) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, positions.size()).forEach(index -> order.put(positions.get(index).getId(), index));
        List<Position> result = entityManager
            .createQuery(
                "select position from Position position left join fetch position.categories where position in :positions",
                Position.class
            )
            .setParameter(POSITIONS_PARAMETER, positions)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }
}
