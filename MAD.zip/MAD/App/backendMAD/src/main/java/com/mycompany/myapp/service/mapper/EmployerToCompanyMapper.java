package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.service.dto.response.CompanyInforResponse;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface EmployerToCompanyMapper {
    CompanyInforResponse toCompanyInforResponse(Employer employer);
}
