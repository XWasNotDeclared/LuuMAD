/**
 * Domain objects.
 */
package com.mycompany.myapp.domain;
