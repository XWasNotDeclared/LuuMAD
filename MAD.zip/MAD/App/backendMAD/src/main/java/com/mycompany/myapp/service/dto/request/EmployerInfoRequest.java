package com.mycompany.myapp.service.dto.request;

import com.mycompany.myapp.service.dto.AppUserDTO;
import jakarta.persistence.Lob;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EmployerInfoRequest {

    private String fullName;

    private String phone;

    private String address;

    private MultipartFile avatarFile;

    private String companyName;

    private String companyCode;

    private String companyDescription;

    private String companyWebsite;

    private Integer workforceSize;

    private String businessType;

    private Integer yearEstablished;

    private String specialization;
}
