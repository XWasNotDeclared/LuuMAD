package com.mycompany.myapp.service.response;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobSeekerResponse {

    private Long id;
    private String name;
    private String position;
    private String avatarUrl;
    private String location;

    private String status;
    private String email;
    private String phone;
    private String salary;

    private String birthDate;
    private String address;
    private String education;
    private String statusWork;

    private List<ReviewResponse> reviews;
}
