package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.MessageReceiver;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the MessageReceiver entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MessageReceiverRepository extends JpaRepository<MessageReceiver, Long> {
    @Query(
        """
                SELECT ms FROM MessageReceiver ms
                JOIN ms.message
                WHERE ms.message.sender.id = :messageSenderId
        """
    )
    List<MessageReceiver> findMessageReceiverByMessage_Sender_Id(@Param("messageSenderId") Long messageSenderId);

    @Query(
        """
            SELECT mr
            FROM MessageReceiver mr
            JOIN FETCH mr.message m
            JOIN FETCH m.sender s
            JOIN FETCH mr.receiver r
            WHERE m.sentAt = (
                SELECT MAX(m2.sentAt)
                FROM MessageReceiver mr2
                JOIN mr2.message m2
                WHERE
                    (
                        (mr2.receiver.id = :myId AND m2.sender.id = CASE WHEN s.id = :myId THEN r.id ELSE s.id END)
                        OR
                        (mr2.receiver.id = CASE WHEN s.id = :myId THEN r.id ELSE s.id END AND m2.sender.id = :myId)
                    )
                    AND
                    (
                        (mr2.receiver.id = mr.receiver.id AND m2.sender.id = m.sender.id)
                        OR
                        (mr2.receiver.id = m.sender.id AND m2.sender.id = mr.receiver.id)
                    )
            )
            AND (:myId IN (s.id, r.id))
            ORDER BY m.sentAt DESC
        """
    )
    List<MessageReceiver> findLastMessagesWithEachUser(@Param("myId") Long myId);

    @EntityGraph(attributePaths = { "message", "message.sender", "receiver" })
    @Query(
        """
            SELECT mr
            FROM Message m
            JOIN MessageReceiver mr ON m.id = mr.message.id
            WHERE
                (m.sender.id = :myId AND mr.receiver.id = :otherId)
            OR  (m.sender.id = :otherId AND mr.receiver.id = :myId)
            ORDER BY m.sentAt ASC
        """
    )
    List<MessageReceiver> findChatMessagesBetweenUsers(@Param("myId") Long myId, @Param("otherId") Long otherId);

    boolean existsByReceiverIdAndIsReadFalse(Long receiverId);

    @Query("SELECT mr FROM MessageReceiver mr WHERE mr.receiver.id = :receiverId AND mr.isRead = false")
    List<MessageReceiver> findUnreadMessagesByReceiverId(@Param("receiverId") Long receiverId);

    @Query("SELECT mr FROM MessageReceiver mr WHERE mr.receiver.id = :receiverId AND mr.isNotified = false")
    List<MessageReceiver> findUnnotifiedMessagesByReceiverId(@Param("receiverId") Long receiverId);

    @Query(
        """
            SELECT mr
            FROM MessageReceiver mr
            WHERE mr.receiver.id = :receiverId
              AND mr.message.sender.id = :senderId
              AND mr.isRead = false
        """
    )
    List<MessageReceiver> findUnreadFromSenderToReceiver(@Param("senderId") Long senderId, @Param("receiverId") Long receiverId);

    List<MessageReceiver> findByMessageIdIn(List<Long> messageIds);
}
