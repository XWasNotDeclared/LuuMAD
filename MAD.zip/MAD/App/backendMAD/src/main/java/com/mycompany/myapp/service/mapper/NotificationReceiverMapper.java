package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Notification;
import com.mycompany.myapp.domain.NotificationReceiver;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.NotificationDTO;
import com.mycompany.myapp.service.dto.NotificationReceiverDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link NotificationReceiver} and its DTO {@link NotificationReceiverDTO}.
 */
@Mapper(componentModel = "spring")
public interface NotificationReceiverMapper extends EntityMapper<NotificationReceiverDTO, NotificationReceiver> {
    @Mapping(target = "notification", source = "notification", qualifiedByName = "notificationId")
    @Mapping(target = "receiver", source = "receiver", qualifiedByName = "appUserId")
    NotificationReceiverDTO toDto(NotificationReceiver s);

    @Named("notificationId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    NotificationDTO toDtoNotificationId(Notification notification);

    @Named("appUserId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    AppUserDTO toDtoAppUserId(AppUser appUser);
}
