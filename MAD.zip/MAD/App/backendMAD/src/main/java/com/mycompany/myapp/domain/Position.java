package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * A Position.
 */
@Entity
@Table(name = "position")
@EntityListeners(AuditingEntityListener.class)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class Position implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", unique = true)
    private String name;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "positions")
    @JsonIgnoreProperties(value = { "appUser", "experiences", "positions" }, allowSetters = true)
    private Set<JobSeeker> jobSeekers = new HashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    @JsonIgnoreProperties(value = { "positions" }, allowSetters = true)
    private Category category;

    public Category getCategory() {
        return this.category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Position category(Category category) {
        this.setCategory(category);
        return this;
    }

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public Position id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public Position name(String name) {
        this.setName(name);
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<JobSeeker> getJobSeekers() {
        return this.jobSeekers;
    }

    public void setJobSeekers(Set<JobSeeker> jobSeekers) {
        if (this.jobSeekers != null) {
            this.jobSeekers.forEach(i -> i.removePositions(this));
        }
        if (jobSeekers != null) {
            jobSeekers.forEach(i -> i.addPositions(this));
        }
        this.jobSeekers = jobSeekers;
    }

    public Position jobSeekers(Set<JobSeeker> jobSeekers) {
        this.setJobSeekers(jobSeekers);
        return this;
    }

    public Position addJobSeekers(JobSeeker jobSeeker) {
        this.jobSeekers.add(jobSeeker);
        jobSeeker.getPositions().add(this);
        return this;
    }

    public Position removeJobSeekers(JobSeeker jobSeeker) {
        this.jobSeekers.remove(jobSeeker);
        jobSeeker.getPositions().remove(this);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Position)) {
            return false;
        }
        return getId() != null && getId().equals(((Position) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Position{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            "}";
    }
}
