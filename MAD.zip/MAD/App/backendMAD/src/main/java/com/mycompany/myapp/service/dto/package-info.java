/**
 * Data transfer objects for rest mapping.
 */
package com.mycompany.myapp.service.dto;
