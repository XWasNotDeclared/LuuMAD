package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Category;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.PositionDTO;
import java.util.Set;
import java.util.stream.Collectors;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Position} and its DTO {@link PositionDTO}.
 */
@Mapper(componentModel = "spring", uses = { CategoryMapper.class })
public interface PositionMapper extends EntityMapper<PositionDTO, Position> {
    //    @Mapping(target = "jobSeekers", source = "jobSeekers", qualifiedByName = "jobSeekerIdSet")
    //    @Mapping(source = "category", target = "category")
    //    PositionDTO toDto(Position position);
    //
    //    @Mapping(target = "jobSeekers", ignore = true)
    //    @Mapping(source = "category.id", target = "category")
    //    Position toEntity(PositionDTO positionDTO);
    //
    //    default Category fromId(Long id) {
    //        if (id == null) {
    //            return null;
    //        }
    //        Category category = new Category();
    //        category.setId(id);
    //        return category;
    //    }
    //
    //    @Named("jobSeekerId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    @Mapping(target = "appUser.fullName", source = "appUser.fullName")
    //    JobSeekerDTO toDtoJobSeekerId(JobSeeker jobSeeker);
    //
    //    @Named("jobSeekerIdSet")
    //    default Set<JobSeekerDTO> toDtoJobSeekerIdSet(Set<JobSeeker> jobSeeker) {
    //        return jobSeeker.stream().map(this::toDtoJobSeekerId).collect(Collectors.toSet());
    //    }
}
