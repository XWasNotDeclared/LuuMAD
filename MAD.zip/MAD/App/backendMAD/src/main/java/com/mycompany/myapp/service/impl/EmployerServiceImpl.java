package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.*;
import com.mycompany.myapp.repository.ContractRepository;
import com.mycompany.myapp.repository.EmployerRepository;
import com.mycompany.myapp.repository.ReviewRepository;
import com.mycompany.myapp.service.EmployerService;
import com.mycompany.myapp.service.GoogleDriveService;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.request.EmployerInfoRequest;
import com.mycompany.myapp.service.dto.response.CompanyInforResponse;
import com.mycompany.myapp.service.mapper.EmployerMapper;
import com.mycompany.myapp.service.mapper.EmployerToCompanyMapper;
import com.mycompany.myapp.service.response.CompanyDetailResponse;
import com.mycompany.myapp.service.response.JobSeekerResponse;
import com.mycompany.myapp.service.response.ReviewResponse;
import jakarta.persistence.EntityNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Employer}.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class EmployerServiceImpl implements EmployerService {

    private static final Logger LOG = LoggerFactory.getLogger(EmployerServiceImpl.class);

    private final EmployerRepository employerRepository;

    private final EmployerMapper employerMapper;
    private final ContractRepository contractRepository;
    private final GoogleDriveService googleDriveService;
    private final ReviewRepository reviewRepository;

    @Override
    public List<JobSeekerResponse> findEmployerByJobSeekerId(Long jobSeekerId) {
        List<Contract> contracts = contractRepository.findContractByJobSeekerId(jobSeekerId);
        Set<Long> ids = new HashSet<>();
        for (Contract contract : contracts) {
            ids.add(contract.getEmployer().getId());
        }
        List<JobSeekerResponse> result = new ArrayList<>();
        for (Long id : ids) {
            Employer employer = employerRepository.findById(id).orElseThrow(EntityNotFoundException::new);
            JobSeekerResponse e = new JobSeekerResponse();
            e.setId(employer.getId());
            e.setName(employer.getCompanyName());
            e.setAvatarUrl(employer.getAppUser().getAvatarUrl());
            e.setEmail(employer.getAppUser().getEmail());
            result.add(e);
        }
        return result;
    }

    @Override
    public CompanyDetailResponse findEmployerById(Long id) {
        Employer e = employerRepository.findById(id).orElse(null);
        CompanyDetailResponse result = new CompanyDetailResponse();
        result.setId(e.getId());
        result.setName(e.getCompanyName());
        result.setLocation(e.getAppUser().getAddress());
        result.setLogo(e.getAppUser().getAvatarUrl());
        result.setAbout(e.getCompanyDescription());
        result.setWebsite(e.getCompanyWebsite());
        result.setEmployeeCount(e.getWorkforceSize());
        result.setCompanyType(e.getBusinessType());
        result.setFounded(e.getYearEstablished().toString());
        result.setSpecialties(e.getSpecialization());

        List<Review> reviews = reviewRepository.findByEmployerIdAndTypeReview_JobSeekerReview(e.getId());
        List<ReviewResponse> reviewResponses = new ArrayList<>();
        for (Review review : reviews) {
            ReviewResponse rr = new ReviewResponse();
            rr.setReviewerName(review.getJobSeeker().getAppUser().getFullName()); // hoặc tên job seeker
            rr.setComment(review.getComment());
            reviewResponses.add(rr);
        }
        result.setReviews(reviewResponses);
        System.out.println(result);
        return result;
    }

    @Override
    public EmployerDTO partialUpdateEmployer(Long id, EmployerInfoRequest employerInfoRequest) {
        Optional<Employer> employerOpt = employerRepository.findById(id);

        if (!employerOpt.isPresent()) {
            return null;
        }

        try {
            Employer employer = employerOpt.get();

            if (employerInfoRequest.getFullName() != null) {
                employer.getAppUser().setFullName(employerInfoRequest.getFullName());
            }

            if (employerInfoRequest.getPhone() != null) {
                employer.getAppUser().setPhone(employerInfoRequest.getPhone());
            }

            if (employerInfoRequest.getAddress() != null) {
                employer.getAppUser().setAddress(employerInfoRequest.getAddress());
            }

            if (employerInfoRequest.getAvatarFile() != null && !employerInfoRequest.getAvatarFile().isEmpty()) {
                String avatarUrl = googleDriveService.uploadFile(employerInfoRequest.getAvatarFile());
                employer.getAppUser().setAvatarUrl(avatarUrl);
            }

            if (employerInfoRequest.getCompanyName() != null) {
                employer.setCompanyName(employerInfoRequest.getCompanyName());
            }

            if (employerInfoRequest.getCompanyCode() != null) {
                String newCompanyCode = employerInfoRequest.getCompanyCode();
                Optional<Employer> existing = employerRepository.findByCompanyCode(newCompanyCode);

                if (existing.isPresent() && !existing.get().getId().equals(employer.getId())) {
                    throw new IllegalArgumentException("Mã công ty đã tồn tại.");
                }
                employer.setCompanyCode(employerInfoRequest.getCompanyCode());
            }

            if (employerInfoRequest.getCompanyDescription() != null) {
                employer.setCompanyDescription(employerInfoRequest.getCompanyDescription());
            }

            if (employerInfoRequest.getCompanyWebsite() != null) {
                employer.setCompanyCode(employerInfoRequest.getCompanyWebsite());
            }

            if (employerInfoRequest.getWorkforceSize() != null) {
                employer.setWorkforceSize(employerInfoRequest.getWorkforceSize());
            }

            if (employerInfoRequest.getBusinessType() != null) {
                employer.setBusinessType(employerInfoRequest.getBusinessType());
            }

            if (employerInfoRequest.getYearEstablished() != null) {
                employer.setYearEstablished(employerInfoRequest.getYearEstablished());
            }

            if (employerInfoRequest.getSpecialization() != null) {
                employer.setSpecialization(employerInfoRequest.getSpecialization());
            }

            employerRepository.save(employer);
            return employerMapper.toDto(employer);
        } catch (IOException e) {
            throw new RuntimeException("Error uploading file to Google Drive", e);
        }
    }

    @Override
    public EmployerDTO save(EmployerDTO employerDTO) {
        LOG.debug("Request to save Employer : {}", employerDTO);
        Employer employer = employerMapper.toEntity(employerDTO);
        employer = employerRepository.save(employer);
        return employerMapper.toDto(employer);
    }

    @Override
    public EmployerDTO update(EmployerDTO employerDTO) {
        LOG.debug("Request to update Employer : {}", employerDTO);
        Employer employer = employerMapper.toEntity(employerDTO);
        employer = employerRepository.save(employer);
        return employerMapper.toDto(employer);
    }

    @Override
    public Optional<EmployerDTO> partialUpdate(EmployerDTO employerDTO) {
        LOG.debug("Request to partially update Employer : {}", employerDTO);

        return employerRepository
            .findById(employerDTO.getId())
            .map(existingEmployer -> {
                employerMapper.partialUpdate(existingEmployer, employerDTO);

                return existingEmployer;
            })
            .map(employerRepository::save)
            .map(employerMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EmployerDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Employers");
        return employerRepository.findAll(pageable).map(employerMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EmployerDTO> findOne(Long id) {
        LOG.debug("Request to get Employer : {}", id);
        return employerRepository.findById(id).map(employerMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Employer : {}", id);
        employerRepository.deleteById(id);
    }
}
