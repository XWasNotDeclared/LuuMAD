package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.Contract;
import com.mycompany.myapp.domain.enumeration.ContractStatus;
import com.mycompany.myapp.repository.ContractRepository;
import com.mycompany.myapp.repository.EmployerRepository;
import com.mycompany.myapp.repository.JobSeekerRepository;
import com.mycompany.myapp.service.ContractService;
import com.mycompany.myapp.service.dto.ContractDTO;
import com.mycompany.myapp.service.mapper.ContractMapper;
import com.mycompany.myapp.service.request.ContractRequest;
import com.mycompany.myapp.service.response.ContractResponse;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Contract}.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class ContractServiceImpl implements ContractService {

    private static final Logger LOG = LoggerFactory.getLogger(ContractServiceImpl.class);

    private final ContractRepository contractRepository;

    private final ContractMapper contractMapper;

    private final EmployerRepository employerRepository;
    private final JobSeekerRepository jobSeekerRepository;

    @Override
    public List<ContractResponse> findContractByEmployerId(Long employerId) {
        List<Contract> contracts = contractRepository.findContractByEmployerId(employerId);
        List<ContractResponse> result = new ArrayList<>();
        for (Contract contract : contracts) {
            ContractResponse item = new ContractResponse();
            item.setId(contract.getId());
            item.setCompany(contract.getEmployer().getCompanyName());
            item.setBudget(contract.getSalary().toString());
            item.setTime(contract.getStartDate().toString());
            item.setTitle(contract.getContractTitle());
            item.setIcon(contract.getEmployer().getAppUser().getAvatarUrl());
            result.add(item);
        }
        return result;
    }

    @Override
    public ContractDTO createScheduleSignContract(ContractRequest contractRequest, Long employerId) {
        Contract contract = new Contract();
        contract.setContractTerm(contractRequest.getContractDuration());
        contract.setContractTitle(contractRequest.getJobTitle());
        // Parse chuỗi ngày tháng từ định dạng dd/MM/yyyy
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate localDate = LocalDate.parse(contractRequest.getAppointmentDate(), formatter);

        LocalDate now = LocalDate.now();

        // Chuyển LocalDate thành Instant (giả sử thời gian là 00:00:00 tại múi giờ hệ thống)
        Instant now2 = now.atStartOfDay(ZoneId.systemDefault()).toInstant();
        Instant instant = localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
        contract.setCreatedDate(now2);
        contract.setSalary(contractRequest.getProposedSalary());
        contract.setEmployer(employerRepository.findById(employerId).get());
        contract.setJobSeeker(jobSeekerRepository.findById(contractRequest.getRecieverId()).get());
        contract.setStatus(ContractStatus.PENDING);
        contract.setStartDate(instant);
        contract.setEndDate(instant);
        contract.setLink(contractRequest.getLink());
        Contract c = contractRepository.save(contract);
        return contractMapper.toDto(c);
    }

    @Override
    public List<ContractResponse> findContractByJobSeekerIdPending(Long jobSeekerId) {
        List<Contract> list = contractRepository.finContractByJobSeekerIdAndStatusPending(jobSeekerId);
        List<ContractResponse> result = new ArrayList<>();
        for (Contract contract : list) {
            ContractResponse item = new ContractResponse();
            item.setId(contract.getId());
            item.setCompany(contract.getEmployer().getCompanyName());
            item.setBudget(contract.getSalary().toString());
            item.setTime(contract.getCreatedDate().toString());
            item.setTitle(contract.getContractTitle());
            item.setIcon(contract.getEmployer().getAppUser().getAvatarUrl());
            item.setLink(contract.getLink());
            result.add(item);
        }
        return result;
    }

    @Override
    public ContractResponse getById(Long id) {
        Contract contract = contractRepository.findById(id).get();
        ContractResponse item = new ContractResponse();
        item.setId(contract.getId());
        item.setCompany(contract.getEmployer().getCompanyName());
        item.setBudget(contract.getSalary().toString());
        item.setTime(contract.getCreatedDate().toString());
        item.setTitle(contract.getContractTitle());
        item.setIcon(contract.getEmployer().getAppUser().getAvatarUrl());

        return item;
    }

    @Override
    public ContractDTO save(ContractDTO contractDTO) {
        LOG.debug("Request to save Contract : {}", contractDTO);
        Contract contract = contractMapper.toEntity(contractDTO);
        contract = contractRepository.save(contract);
        return contractMapper.toDto(contract);
    }

    @Override
    public ContractDTO update(ContractDTO contractDTO) {
        LOG.debug("Request to update Contract : {}", contractDTO);
        Contract contract = contractMapper.toEntity(contractDTO);
        contract = contractRepository.save(contract);
        return contractMapper.toDto(contract);
    }

    @Override
    public Optional<ContractDTO> partialUpdate(ContractDTO contractDTO) {
        LOG.debug("Request to partially update Contract : {}", contractDTO);

        return contractRepository
            .findById(contractDTO.getId())
            .map(existingContract -> {
                contractMapper.partialUpdate(existingContract, contractDTO);

                return existingContract;
            })
            .map(contractRepository::save)
            .map(contractMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ContractDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Contracts");
        return contractRepository.findAll(pageable).map(contractMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ContractDTO> findOne(Long id) {
        LOG.debug("Request to get Contract : {}", id);
        return contractRepository.findById(id).map(contractMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Contract : {}", id);
        contractRepository.deleteById(id);
    }
}
