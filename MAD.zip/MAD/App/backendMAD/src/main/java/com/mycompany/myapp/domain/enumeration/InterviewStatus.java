package com.mycompany.myapp.domain.enumeration;

/**
 * The InterviewStatus enumeration.
 */
public enum InterviewStatus {
    SCHEDULED,
    COMPLETED,
    CANCELED,
    RESCHEDULED,
}
