package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Application;
import com.mycompany.myapp.domain.ApplicationSchedule;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.Post;
import com.mycompany.myapp.service.dto.ApplicationDTO;
import com.mycompany.myapp.service.dto.ApplicationScheduleDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.PostDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Application} and its DTO {@link ApplicationDTO}.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ApplicationMapper extends EntityMapper<ApplicationDTO, Application> {
    @Mapping(source = "jobSeeker.id", target = "jobSeekerId")
    @Mapping(source = "post.id", target = "postId")
    @Mapping(source = "post.employer.id", target = "employerId") // nếu muốn có employerId
    ApplicationDTO toDto(Application application);

    @Mapping(source = "jobSeekerId", target = "jobSeeker.id")
    @Mapping(source = "postId", target = "post.id")
    Application toEntity(ApplicationDTO applicationDTO);

    default Application fromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }
}
