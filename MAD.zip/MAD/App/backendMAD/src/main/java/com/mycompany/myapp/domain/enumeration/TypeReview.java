package com.mycompany.myapp.domain.enumeration;

public enum TypeReview {
    EMPLOYER_REVIEW,
    JOB_SEEKER_REVIEW,
}
