package com.mycompany.myapp.service.dto;

import com.mycompany.myapp.domain.enumeration.InterviewStatus;
import com.mycompany.myapp.domain.enumeration.InterviewType;
import jakarta.persistence.Lob;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.Interview} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class InterviewDTO implements Serializable {

    private Long id;

    @NotNull
    private Instant scheduledTime;

    private Integer durationMinutes;

    @NotNull
    private InterviewType interviewType;

    private String locationOrLink;

    @NotNull
    private InterviewStatus status;

    @Lob
    private String notes;

    private ApplicationDTO application;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Instant getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(Instant scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public Integer getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(Integer durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public InterviewType getInterviewType() {
        return interviewType;
    }

    public void setInterviewType(InterviewType interviewType) {
        this.interviewType = interviewType;
    }

    public String getLocationOrLink() {
        return locationOrLink;
    }

    public void setLocationOrLink(String locationOrLink) {
        this.locationOrLink = locationOrLink;
    }

    public InterviewStatus getStatus() {
        return status;
    }

    public void setStatus(InterviewStatus status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public ApplicationDTO getApplication() {
        return application;
    }

    public void setApplication(ApplicationDTO application) {
        this.application = application;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof InterviewDTO)) {
            return false;
        }

        InterviewDTO interviewDTO = (InterviewDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, interviewDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "InterviewDTO{" +
            "id=" + getId() +
            ", scheduledTime='" + getScheduledTime() + "'" +
            ", durationMinutes=" + getDurationMinutes() +
            ", interviewType='" + getInterviewType() + "'" +
            ", locationOrLink='" + getLocationOrLink() + "'" +
            ", status='" + getStatus() + "'" +
            ", notes='" + getNotes() + "'" +
            ", application=" + getApplication() +
            "}";
    }
}
