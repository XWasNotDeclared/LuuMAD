package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.JobSeeker;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

/**
 * Utility repository to load bag relationships based on https://vladmihalcea.com/hibernate-multiplebagfetchexception/
 */
public class JobSeekerRepositoryWithBagRelationshipsImpl implements JobSeekerRepositoryWithBagRelationships {

    private static final String ID_PARAMETER = "id";
    private static final String JOBSEEKERS_PARAMETER = "jobSeekers";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<JobSeeker> fetchBagRelationships(Optional<JobSeeker> jobSeeker) {
        return jobSeeker.map(this::fetchPositions);
    }

    @Override
    public Page<JobSeeker> fetchBagRelationships(Page<JobSeeker> jobSeekers) {
        return new PageImpl<>(fetchBagRelationships(jobSeekers.getContent()), jobSeekers.getPageable(), jobSeekers.getTotalElements());
    }

    @Override
    public List<JobSeeker> fetchBagRelationships(List<JobSeeker> jobSeekers) {
        return Optional.of(jobSeekers).map(this::fetchPositions).orElse(Collections.emptyList());
    }

    JobSeeker fetchPositions(JobSeeker result) {
        return entityManager
            .createQuery(
                "select jobSeeker from JobSeeker jobSeeker left join fetch jobSeeker.positions where jobSeeker.id = :id",
                JobSeeker.class
            )
            .setParameter(ID_PARAMETER, result.getId())
            .getSingleResult();
    }

    List<JobSeeker> fetchPositions(List<JobSeeker> jobSeekers) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, jobSeekers.size()).forEach(index -> order.put(jobSeekers.get(index).getId(), index));
        List<JobSeeker> result = entityManager
            .createQuery(
                "select jobSeeker from JobSeeker jobSeeker left join fetch jobSeeker.positions where jobSeeker in :jobSeekers",
                JobSeeker.class
            )
            .setParameter(JOBSEEKERS_PARAMETER, jobSeekers)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }
}
