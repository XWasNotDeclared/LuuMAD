package com.mycompany.myapp.service.dto;

import jakarta.persistence.Lob;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.Employer} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class EmployerDTO implements Serializable {

    private Long id;

    private String companyName;

    private String companyCode;

    @Lob
    private String companyDescription;

    private String companyWebsite;

    private Integer workforceSize;

    private String businessType;

    private Integer yearEstablished;

    private String specialization;

    private AppUserDTO appUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyDescription() {
        return companyDescription;
    }

    public void setCompanyDescription(String companyDescription) {
        this.companyDescription = companyDescription;
    }

    public String getCompanyWebsite() {
        return companyWebsite;
    }

    public void setCompanyWebsite(String companyWebsite) {
        this.companyWebsite = companyWebsite;
    }

    public Integer getWorkforceSize() {
        return workforceSize;
    }

    public void setWorkforceSize(Integer workforceSize) {
        this.workforceSize = workforceSize;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public Integer getYearEstablished() {
        return yearEstablished;
    }

    public void setYearEstablished(Integer yearEstablished) {
        this.yearEstablished = yearEstablished;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public AppUserDTO getAppUser() {
        return appUser;
    }

    public void setAppUser(AppUserDTO appUser) {
        this.appUser = appUser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EmployerDTO)) {
            return false;
        }

        EmployerDTO employerDTO = (EmployerDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, employerDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "EmployerDTO{" +
            "id=" + getId() +
            ", companyName='" + getCompanyName() + "'" +
            ", companyCode='" + getCompanyCode() + "'" +
            ", companyDescription='" + getCompanyDescription() + "'" +
            ", companyWebsite='" + getCompanyWebsite() + "'" +
            ", workforceSize=" + getWorkforceSize() +
            ", businessType='" + getBusinessType() + "'" +
            ", yearEstablished=" + getYearEstablished() +
            ", specialization='" + getSpecialization() + "'" +
            ", appUser=" + getAppUser() +
            "}";
    }
}
