package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.JobSeekerFilterRequest;
import com.mycompany.myapp.service.dto.PositionDTO;
import com.mycompany.myapp.service.dto.request.JobSeekerInfoRequest;
import com.mycompany.myapp.service.dto.response.SuggestionInfoResponse;
import com.mycompany.myapp.service.response.JobSeekerResponse;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

/**
 * Service Interface for managing {@link com.mycompany.myapp.domain.JobSeeker}.
 */
public interface JobSeekerService {
    //    List<JobSeekerDTO> findJobSeekerByPostId(Long postId);
    //    JobSeekerDTO findJobSeekerById(Long id);
    //    List<JobSeekerDTO> findJobSeekerByEmployerId(Long employerId);
    List<JobSeekerResponse> findJobSeekerByPostId(Long postId);
    JobSeekerResponse findJobSeekerById(Long id);
    List<JobSeekerResponse> findJobSeekerByEmployerId(Long employerId);
    List<JobSeekerResponse> findJobSeekerInteractWithEmploer(Long employerId);

    JobSeekerDTO partialUpdateJobSeeker(Long id, JobSeekerInfoRequest jobSeekerInfoRequest);

    /**
     * Save a jobSeeker.
     *
     * @param jobSeekerDTO the entity to save.
     * @return the persisted entity.
     */
    JobSeekerDTO save(JobSeekerDTO jobSeekerDTO);

    /**
     * Updates a jobSeeker.
     *
     * @param jobSeekerDTO the entity to update.
     * @return the persisted entity.
     */
    JobSeekerDTO update(JobSeekerDTO jobSeekerDTO);

    /**
     * Partially updates a jobSeeker.
     *
     * @param jobSeekerDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<JobSeekerDTO> partialUpdate(JobSeekerDTO jobSeekerDTO);

    /**
     * Get all the jobSeekers.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<JobSeekerDTO> findAll(Pageable pageable);

    /**
     * Get all the jobSeekers with eager load of many-to-many relationships.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<JobSeekerDTO> findAllWithEagerRelationships(Pageable pageable);

    /**
     * Get the "id" jobSeeker.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<JobSeekerDTO> findOne(Long id);

    /**
     * Delete the "id" jobSeeker.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    List<JobSeekerDTO> filterJobSeekers(JobSeekerFilterRequest request);

    List<JobSeekerDTO> findByPositionId(Long positionId); // ✅ THÊM MỚI – lọc theo positionId

    Set<Position> findPositionsByJobSeekerId(Long jobSeekerId);

    SuggestionInfoResponse getSuggestionInfoResponse(Long jobSeekerId);
}
