package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Contract;
import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.service.dto.ContractDTO;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Contract} and its DTO {@link ContractDTO}.
 */
@Mapper(componentModel = "spring")
public interface ContractMapper extends EntityMapper<ContractDTO, Contract> {
    @Mapping(target = "jobSeeker", source = "jobSeeker", qualifiedByName = "jobSeekerId")
    @Mapping(target = "employer", source = "employer", qualifiedByName = "employerId")
    ContractDTO toDto(Contract s);

    @Named("jobSeekerId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    JobSeekerDTO toDtoJobSeekerId(JobSeeker jobSeeker);

    @Named("employerId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    EmployerDTO toDtoEmployerId(Employer employer);
}
