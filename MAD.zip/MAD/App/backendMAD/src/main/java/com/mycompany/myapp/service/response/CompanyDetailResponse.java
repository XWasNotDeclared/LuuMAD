package com.mycompany.myapp.service.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDetailResponse {

    private Long id;
    private String name;
    private String logo;
    private String about;
    private String website;
    private String industry;
    private String location;
    private String companyType;
    private String founded;
    private String specialties;
    private int employeeCount;
    private List<ReviewResponse> reviews;
}
