package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.*;
import com.mycompany.myapp.domain.enumeration.JobType;
import com.mycompany.myapp.repository.*;
import com.mycompany.myapp.service.GoogleDriveService;
import com.mycompany.myapp.service.JobSeekerService;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.JobSeekerFilterRequest;
import com.mycompany.myapp.service.dto.request.ExperienceRequest;
import com.mycompany.myapp.service.dto.request.JobSeekerInfoRequest;
import com.mycompany.myapp.service.dto.response.SuggestionInfoResponse;
import com.mycompany.myapp.service.mapper.JobSeekerMapper;
import com.mycompany.myapp.service.response.JobSeekerResponse;
import com.mycompany.myapp.service.response.ReviewResponse;
import jakarta.persistence.EntityNotFoundException;
import java.io.IOException;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.JobSeeker}.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class JobSeekerServiceImpl implements JobSeekerService {

    private static final Logger LOG = LoggerFactory.getLogger(JobSeekerServiceImpl.class);

    private final GoogleDriveService googleDriveService;

    private final JobSeekerRepository jobSeekerRepository;

    private final JobSeekerMapper jobSeekerMapper;
    private final ApplicationRepository applicationRepository;
    private final ContractRepository contractRepository;
    private final MessageReceiverRepository messageReceiverRepository;
    private final PositionRepository positionRepository;

    private final ExperienceRepository experienceRepository;
    private final ReviewRepository reviewRepository;
    private final EmployerRepository employerRepository;

    @Override
    public List<JobSeekerResponse> findJobSeekerByPostId(Long postId) {
        List<JobSeekerResponse> results = new ArrayList<>();
        List<Application> applicationList = applicationRepository.findByPost_Id(postId);

        for (Application application : applicationList) {
            JobSeekerResponse jobSeekerResponse = new JobSeekerResponse();

            jobSeekerResponse.setId(application.getJobSeeker().getId());
            jobSeekerResponse.setName(application.getJobSeeker().getAppUser().getFullName());
            jobSeekerResponse.setPosition(application.getPost().getPosition().getName());
            jobSeekerResponse.setAvatarUrl(application.getJobSeeker().getAppUser().getAvatarUrl());

            results.add(jobSeekerResponse);
        }
        return results;
    }

    @Override
    public JobSeekerResponse findJobSeekerById(Long id) {
        try {
            LOG.debug("Finding JobSeeker with id: {}", id);
            JobSeeker jobSeeker = jobSeekerRepository.findById(id).get();
            JobSeekerResponse jobSeekerResponse = new JobSeekerResponse();
            jobSeekerResponse.setId(jobSeeker.getId());
            jobSeekerResponse.setAvatarUrl(jobSeeker.getAppUser().getAvatarUrl());
            jobSeekerResponse.setEmail(jobSeeker.getAppUser().getEmail());
            jobSeekerResponse.setName(jobSeeker.getAppUser().getFullName());
            jobSeekerResponse.setLocation(jobSeeker.getAppUser().getAddress());
            jobSeekerResponse.setPhone(jobSeeker.getAppUser().getPhone());
            jobSeekerResponse.setBirthDate(String.valueOf(jobSeeker.getBirthDate()));
            jobSeekerResponse.setAddress(jobSeeker.getAppUser().getAddress());
            jobSeekerResponse.setEducation(jobSeeker.getEducation());
            jobSeekerResponse.setSalary(jobSeeker.getExpectedSalary().toString());

            List<Review> reviews = reviewRepository.findByJobSeekerIdAndTypeReview_EmployerReview(id);
            List<ReviewResponse> reviewResponses = new ArrayList<>();
            for (Review review : reviews) {
                ReviewResponse rr = new ReviewResponse();
                rr.setReviewerName(review.getEmployer().getAppUser().getFullName());
                rr.setComment(review.getComment());
                reviewResponses.add(rr);
            }
            jobSeekerResponse.setReviews(reviewResponses);
            return jobSeekerResponse;
        } catch (Exception e) {
            LOG.error("Error finding JobSeeker with id: {}. Cause: {}", id, e.getCause(), e);
            throw new RuntimeException("Error finding JobSeeker", e);
        }
    }

    @Override
    public List<JobSeekerResponse> findJobSeekerByEmployerId(Long employerId) {
        try {
            LOG.debug("Finding JobSeeker with id: {}", employerId);
            List<JobSeeker> jobSeekers = jobSeekerRepository.findJobSeekerByEmployerId(employerId);
            List<Contract> contractList = contractRepository.finContractByEmployerIdAndStatusNotPending(employerId);
            List<JobSeekerResponse> jobSeekerResponses = new ArrayList<>();

            for (Contract contract : contractList) {
                JobSeekerResponse jobSeekerResponse = new JobSeekerResponse();
                jobSeekerResponse.setId(contract.getJobSeeker().getId());
                jobSeekerResponse.setName(contract.getJobSeeker().getAppUser().getFullName());
                jobSeekerResponse.setAvatarUrl(contract.getJobSeeker().getAppUser().getAvatarUrl());
                jobSeekerResponse.setEmail(contract.getJobSeeker().getAppUser().getEmail());
                jobSeekerResponse.setLocation(contract.getJobSeeker().getAppUser().getAddress());
                jobSeekerResponse.setPhone(contract.getJobSeeker().getAppUser().getPhone());
                jobSeekerResponse.setBirthDate(String.valueOf(contract.getJobSeeker().getBirthDate()));
                jobSeekerResponse.setAddress(contract.getJobSeeker().getAppUser().getAddress());
                jobSeekerResponse.setEducation(contract.getJobSeeker().getEducation());
                jobSeekerResponse.setSalary(contract.getSalary().toString());
                jobSeekerResponse.setStatus(contract.getStatus().toString());
                jobSeekerResponses.add(jobSeekerResponse);
            }
            System.out.println(jobSeekerResponses.stream().toString());
            return jobSeekerResponses;
        } catch (Exception e) {
            LOG.error("Error finding JobSeeker with id: {}. Cause: {}", employerId, e.getCause(), e);
            throw new RuntimeException("Error finding JobSeeker", e);
        }
    }

    @Override
    public List<JobSeekerResponse> findJobSeekerInteractWithEmploer(Long employerId) {
        //        List<MessageReceiver> list = messageReceiverRepository.findMessageReceiverByMessage_Sender_Id(employerId);
        Employer employer = employerRepository.findById(employerId).get();
        List<MessageReceiver> list = messageReceiverRepository.findMessageReceiverByMessage_Sender_Id(employer.getAppUser().getId());
        List<JobSeekerResponse> result = new ArrayList<>();
        for (MessageReceiver messageReceiver : list) {
            AppUser receiver = messageReceiver.getReceiver();
            if (receiver.getJobSeeker() == null) {
                System.out.println("Bỏ qua vì JobSeeker null với userId = " + receiver.getId());
                continue;
            }
            JobSeekerResponse jobSeekerResponse = new JobSeekerResponse();
            long id = receiver.getJobSeeker().getId();
            System.out.println("JobSeeker ID: " + id);
            jobSeekerResponse.setId(id);
            jobSeekerResponse.setName(receiver.getFullName());
            jobSeekerResponse.setAvatarUrl(receiver.getAvatarUrl());

            result.add(jobSeekerResponse);
        }
        return result;
    }

    @Override
    public JobSeekerDTO partialUpdateJobSeeker(Long id, JobSeekerInfoRequest jobSeekerInfoRequest) {
        Optional<JobSeeker> jobSeekerOpt = jobSeekerRepository.findById(id);

        if (!jobSeekerOpt.isPresent()) {
            return null;
        }

        try {
            JobSeeker jobSeeker = jobSeekerOpt.get();

            if (jobSeekerInfoRequest.getFullName() != null) {
                jobSeeker.getAppUser().setFullName(jobSeekerInfoRequest.getFullName());
            }

            if (jobSeekerInfoRequest.getAddress() != null) {
                jobSeeker.getAppUser().setAddress(jobSeekerInfoRequest.getAddress());
            }

            if (jobSeekerInfoRequest.getPhone() != null) {
                jobSeeker.getAppUser().setPhone(jobSeekerInfoRequest.getPhone());
            }

            if (jobSeekerInfoRequest.getAvatarFile() != null && !jobSeekerInfoRequest.getAvatarFile().isEmpty()) {
                String avatarUrl = googleDriveService.uploadFile(jobSeekerInfoRequest.getAvatarFile());
                jobSeeker.getAppUser().setAvatarUrl(avatarUrl);
            }

            if (jobSeekerInfoRequest.getExpectedSalary() != null) {
                jobSeeker.setExpectedSalary(jobSeekerInfoRequest.getExpectedSalary());
            }

            if (jobSeekerInfoRequest.getBirthDate() != null) {
                jobSeeker.setBirthDate(jobSeekerInfoRequest.getBirthDate());
            }

            if (jobSeekerInfoRequest.getEducation() != null) {
                jobSeeker.setEducation(jobSeekerInfoRequest.getEducation());
            }

            if (jobSeekerInfoRequest.getJobType() != null && !jobSeekerInfoRequest.getJobType().isEmpty()) {
                jobSeeker.setJobType(JobType.valueOf(jobSeekerInfoRequest.getJobType()));
            }

            if (jobSeekerInfoRequest.getResumeFile() != null && !jobSeekerInfoRequest.getResumeFile().isEmpty()) {
                String resumeUrl = googleDriveService.uploadFile(jobSeekerInfoRequest.getResumeFile());
                jobSeeker.setResumeUrl(resumeUrl);
            }

            if (jobSeekerInfoRequest.getDescription() != null) {
                jobSeeker.setDescription(jobSeekerInfoRequest.getDescription());
            }

            if (jobSeekerInfoRequest.getPositionIds() != null) {
                Set<Position> positions = new HashSet<>();

                for (Long positionId : jobSeekerInfoRequest.getPositionIds()) {
                    Position position = positionRepository
                        .findById(positionId)
                        .orElseThrow(() -> new EntityNotFoundException("Position not found with ID: " + positionId));
                    positions.add(position);
                }

                jobSeeker.setPositions(positions);
            }

            if (jobSeekerInfoRequest.getExperiences() != null) {
                // Xoá hết kinh nghiệm cũ
                jobSeeker.getExperiences().clear();

                Set<Experience> newExperiences = new HashSet<>();

                for (ExperienceRequest experienceRequest : jobSeekerInfoRequest.getExperiences()) {
                    Experience experience = new Experience();
                    experience.setCompanyName(experienceRequest.getCompanyName());
                    experience.setJobTitle(experienceRequest.getJobTitle());
                    experience.setJobDescription(experienceRequest.getJobDescription());
                    experience.setStartDate(experienceRequest.getStartDate());
                    experience.setEndDate(experienceRequest.getEndDate());
                    experience.setIsCurrent(experienceRequest.getIsCurrent());
                    experience.setJobSeeker(jobSeeker);

                    newExperiences.add(experience);
                    experienceRepository.save(experience);
                }

                // Gán lại tập experience mới
                jobSeeker.setExperiences(newExperiences);
            }

            jobSeekerRepository.save(jobSeeker);
            return jobSeekerMapper.toDto(jobSeeker);
        } catch (IOException e) {
            throw new RuntimeException("Error uploading file to Google Drive", e);
        }
    }

    @Override
    public JobSeekerDTO save(JobSeekerDTO jobSeekerDTO) {
        LOG.debug("Request to save JobSeeker : {}", jobSeekerDTO);
        JobSeeker jobSeeker = jobSeekerMapper.toEntity(jobSeekerDTO);
        jobSeeker = jobSeekerRepository.save(jobSeeker);
        return jobSeekerMapper.toDto(jobSeeker);
    }

    @Override
    public JobSeekerDTO update(JobSeekerDTO jobSeekerDTO) {
        LOG.debug("Request to update JobSeeker : {}", jobSeekerDTO);
        JobSeeker jobSeeker = jobSeekerMapper.toEntity(jobSeekerDTO);
        jobSeeker = jobSeekerRepository.save(jobSeeker);
        return jobSeekerMapper.toDto(jobSeeker);
    }

    @Override
    public Optional<JobSeekerDTO> partialUpdate(JobSeekerDTO jobSeekerDTO) {
        LOG.debug("Request to partially update JobSeeker : {}", jobSeekerDTO);

        return jobSeekerRepository
            .findById(jobSeekerDTO.getId())
            .map(existingJobSeeker -> {
                jobSeekerMapper.partialUpdate(existingJobSeeker, jobSeekerDTO);

                return existingJobSeeker;
            })
            .map(jobSeekerRepository::save)
            .map(jobSeekerMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobSeekerDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all JobSeekers");
        return jobSeekerRepository.findAll(pageable).map(jobSeekerMapper::toDto);
    }

    public Page<JobSeekerDTO> findAllWithEagerRelationships(Pageable pageable) {
        return jobSeekerRepository.findAllWithEagerRelationships(pageable).map(jobSeekerMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<JobSeekerDTO> findOne(Long id) {
        LOG.debug("Request to get JobSeeker : {}", id);
        return jobSeekerRepository.findOneWithEagerRelationships(id).map(jobSeekerMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete JobSeeker : {}", id);
        jobSeekerRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobSeekerDTO> filterJobSeekers(JobSeekerFilterRequest request) {
        List<JobSeeker> allJobSeekers = jobSeekerRepository.findAllWithEagerRelationshipsFilter();

        return allJobSeekers
            .stream()
            .filter(js -> {
                // Job Type
                boolean matchJobType =
                    request.getJobTypes() == null ||
                    request.getJobTypes().isEmpty() ||
                    (js.getJobType() != null && request.getJobTypes().contains(js.getJobType().name()));

                // Location
                boolean matchLocation =
                    request.getLocations() == null ||
                    request.getLocations().isEmpty() ||
                    (js.getAppUser() != null && request.getLocations().contains(js.getAppUser().getAddress()));

                // Salary
                boolean matchSalary =
                    (request.getMinSalary() == null && request.getMaxSalary() == null) ||
                    (js.getExpectedSalary() != null &&
                        (request.getMinSalary() == null || js.getExpectedSalary() >= request.getMinSalary()) &&
                        (request.getMaxSalary() == null || js.getExpectedSalary() <= request.getMaxSalary()));

                // Experience
                double totalYearsExperience = js
                    .getExperiences()
                    .stream()
                    .mapToDouble(e -> {
                        if (e.getStartDate() != null) {
                            LocalDate endDate = e.getEndDate() != null ? e.getEndDate() : LocalDate.now();
                            return ChronoUnit.DAYS.between(e.getStartDate(), endDate) / 365.0;
                        }
                        return 0.0;
                    })
                    .sum();

                boolean matchExperience = true;
                String experienceRange = request.getMinYearsExperience();

                if (experienceRange != null && !experienceRange.equalsIgnoreCase("Tất cả")) {
                    switch (experienceRange) {
                        case "0":
                            matchExperience = totalYearsExperience == 0;
                            break;
                        case "1-":
                            matchExperience = totalYearsExperience > 0 && totalYearsExperience < 1;
                            break;
                        case "1-3":
                            matchExperience = totalYearsExperience >= 1 && totalYearsExperience < 3;
                            break;
                        case "3-5":
                            matchExperience = totalYearsExperience >= 3 && totalYearsExperience < 5;
                            break;
                        case "5-10":
                            matchExperience = totalYearsExperience >= 5 && totalYearsExperience < 10;
                            break;
                        case "10+":
                            matchExperience = totalYearsExperience >= 10;
                            break;
                        default:
                            matchExperience = true;
                    }
                }

                // Category
                boolean matchCategory = true;
                if (request.getCategoryIds() != null && !request.getCategoryIds().isEmpty()) {
                    Set<Long> seekerCategoryIds = js.getPositions().stream().map(p -> p.getCategory().getId()).collect(Collectors.toSet());
                    matchCategory = seekerCategoryIds.stream().anyMatch(request.getCategoryIds()::contains);
                }

                // Position Name
                boolean matchPositionName = true;
                if (request.getPositionName() != null && !request.getPositionName().isBlank()) {
                    matchPositionName =
                        js
                            .getPositions()
                            .stream()
                            .anyMatch(p ->
                                p.getName() != null && p.getName().toLowerCase().contains(request.getPositionName().toLowerCase())
                            );
                }

                return matchJobType && matchLocation && matchSalary && matchExperience && matchCategory && matchPositionName;
            })
            .map(jobSeekerMapper::toDto)
            .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobSeekerDTO> findByPositionId(Long positionId) {
        List<JobSeeker> jobSeekers = jobSeekerRepository.findByPositionId(positionId);
        return jobSeekers.stream().map(jobSeekerMapper::toDto).collect(Collectors.toList());
    }

    @Override
    public Set<Position> findPositionsByJobSeekerId(Long jobSeekerId) {
        JobSeeker jobSeeker = jobSeekerRepository
            .findById(jobSeekerId)
            .orElseThrow(() -> new RuntimeException("JobSeeker not found with id " + jobSeekerId));
        return jobSeeker.getPositions();
    }

    @Override
    public SuggestionInfoResponse getSuggestionInfoResponse(Long jobSeekerId) {
        JobSeeker jobSeeker = jobSeekerRepository
            .findOneWithEagerRelationships(jobSeekerId)
            .orElseThrow(() -> new RuntimeException("Không tìm thấy JobSeeker"));
        SuggestionInfoResponse suggestionInfoResponse = new SuggestionInfoResponse();
        suggestionInfoResponse.setJobType(jobSeeker.getJobType());
        suggestionInfoResponse.setExpectedSalary(jobSeeker.getExpectedSalary());
        suggestionInfoResponse.setPosition(jobSeeker.getPositions());

        return suggestionInfoResponse;
    }
}
