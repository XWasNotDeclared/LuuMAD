package com.mycompany.myapp.service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyInforResponse {

    private Long id;
    private String companyName;
    private String companyCode;
    private String companyDescription;
    private String companyWebsite;
    private Integer workforceSize;
    private String businessType;
    private Integer yearEstablished;
    private String specialization;
}
