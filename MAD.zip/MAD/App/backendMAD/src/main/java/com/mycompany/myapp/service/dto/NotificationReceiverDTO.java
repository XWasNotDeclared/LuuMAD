package com.mycompany.myapp.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.NotificationReceiver} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class NotificationReceiverDTO implements Serializable {

    private Long id;

    @NotNull
    private Boolean isRead;

    private NotificationDTO notification;

    private AppUserDTO receiver;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public NotificationDTO getNotification() {
        return notification;
    }

    public void setNotification(NotificationDTO notification) {
        this.notification = notification;
    }

    public AppUserDTO getReceiver() {
        return receiver;
    }

    public void setReceiver(AppUserDTO receiver) {
        this.receiver = receiver;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof NotificationReceiverDTO)) {
            return false;
        }

        NotificationReceiverDTO notificationReceiverDTO = (NotificationReceiverDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, notificationReceiverDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "NotificationReceiverDTO{" +
            "id=" + getId() +
            ", isRead='" + getIsRead() + "'" +
            ", notification=" + getNotification() +
            ", receiver=" + getReceiver() +
            "}";
    }
}
