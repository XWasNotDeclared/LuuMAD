package com.mycompany.myapp.domain.enumeration;

/**
 * The InterviewType enumeration.
 */
public enum InterviewType {
    IN_PERSON,
    PHONE,
    VIDEO,
}
