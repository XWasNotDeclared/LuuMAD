package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Employer;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Employer entity.
 */
@SuppressWarnings("unused")
@Repository
public interface EmployerRepository extends JpaRepository<Employer, Long> {
    Employer findByAppUserId(Long id);

    @Query(
        """
                SELECT e FROM Employer e
                JOIN Contract c ON e.id = c.employer.id
                WHERE e.id = :jobSeekerId

        """
    )
    List<Employer> findEmployerByJobSeekerId(@Param("jobSeekerId") Long jobSeekerId);

    Optional<Employer> findByCompanyCode(String companyCode);
}
