package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.enumeration.UserRole;
import com.mycompany.myapp.repository.AppUserRepository;
import com.mycompany.myapp.repository.EmployerRepository;
import com.mycompany.myapp.repository.JobSeekerRepository;
import com.mycompany.myapp.service.dto.request.LoginRequest;
import com.mycompany.myapp.service.dto.request.SignupRequest;
import com.mycompany.myapp.service.dto.response.AuthResponse;
import com.mycompany.myapp.service.dto.response.ResponseDTO;
import com.mycompany.myapp.service.impl.AppUserServiceImpl;
import com.mycompany.myapp.service.mapper.AppUserMapper;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AppUserRepository appUserRepository;
    private final AppUserServiceImpl appUserService;
    private final JwtService jwtService;
    private final AppUserMapper appUserMapper;
    private final ClerkService clerkService;
    private final PasswordEncoder passwordEncoder;
    private final JobSeekerRepository jobSeekerRepository;
    private final EmployerRepository employerRepository;

    public ResponseEntity<ResponseDTO<Object>> loginWithGoogle(String sessionId) {
        try {
            String email = clerkService.getEmailFromSessionId(sessionId);

            if (email == null) {
                return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(ResponseDTO.builder().success(false).message("Token không hợp lệ hoặc đã hết hạn.").data(null).build());
            }

            Optional<AppUser> existingAppUser = appUserRepository.findByEmail(email);

            if (existingAppUser.isPresent()) {
                AppUser appUser = existingAppUser.get();

                String token = "";
                if (appUser.getRole().equals(UserRole.JOB_SEEKER)) {
                    JobSeeker jobSeeker = jobSeekerRepository.findByAppUserId(appUser.getId());
                    token = jwtService.generateToken(jobSeeker.getId(), appUser.getEmail(), UserRole.JOB_SEEKER.name());
                } else {
                    Employer employer = employerRepository.findByAppUserId(appUser.getId());
                    token = jwtService.generateToken(employer.getId(), appUser.getEmail(), UserRole.EMPLOYER.name());
                }

                AuthResponse authResponse = AuthResponse
                    .builder()
                    .accessToken(token)
                    .appUserDTO(appUserMapper.toDto(appUser))
                    .isNew(false)
                    .build();

                return ResponseEntity.ok(
                    ResponseDTO.builder().success(true).message("Đăng nhập bằng Google thành công.").data(authResponse).build()
                );
            } else {
                AuthResponse authResponse = AuthResponse.builder().isNew(true).build();

                return ResponseEntity.ok(
                    ResponseDTO.builder().success(true).message("Người dùng chưa đăng ký tài khoản qua Google.").data(authResponse).build()
                );
            }
        } catch (Exception e) {
            System.err.println("Login with Google failed " + e);
            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ResponseDTO.builder().success(false).message("Đăng nhập qua Google thất bại.").data(null).build());
        }
    }

    public ResponseEntity<ResponseDTO<AuthResponse>> login(LoginRequest loginRequest) {
        try {
            Optional<AppUser> appUserOpt = appUserRepository.findByEmail(loginRequest.getEmail());

            if (!appUserOpt.isPresent()) {
                return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(ResponseDTO.<AuthResponse>builder().success(false).message("Email chưa được đăng ký.").data(null).build());
            }

            AppUser appUser = appUserOpt.get();

            // Nếu mật khẩu trống ("") -> tài khoản được tạo qua Google
            if (appUser.getPassword() == null || appUser.getPassword().isEmpty()) {
                return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ResponseDTO.<AuthResponse>builder().success(false).message("Vui lòng đăng nhập bằng Google.").data(null).build());
            }

            if (!appUserService.verifyPassword(loginRequest.getPassword(), appUser.getPassword())) {
                return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(ResponseDTO.<AuthResponse>builder().success(false).message("Mật khẩu không đúng.").data(null).build());
            }
            //            if (!appUser.getPassword().equals(loginRequest.getPassword())) {
            //                return ResponseEntity
            //                    .status(HttpStatus.UNAUTHORIZED)
            //                    .body(ResponseDTO.<AuthResponse>builder().success(false).message("Mật khẩu không đúng.").data(null).build());
            //            }
            String token = "";

            if (appUser.getRole().equals(UserRole.JOB_SEEKER)) {
                JobSeeker jobSeeker = jobSeekerRepository.findByAppUserId(appUser.getId());
                token = jwtService.generateToken(jobSeeker.getId(), loginRequest.getEmail(), UserRole.JOB_SEEKER.name());
            } else {
                Employer employer = employerRepository.findByAppUserId(appUser.getId());
                token = jwtService.generateToken(employer.getId(), loginRequest.getEmail(), UserRole.EMPLOYER.name());
            }

            AuthResponse authResponse = new AuthResponse(token, appUserMapper.toDto(appUser), null);

            return ResponseEntity.ok(
                ResponseDTO.<AuthResponse>builder().success(true).message("Đăng nhập thành công.").data(authResponse).build()
            );
        } catch (Exception e) {
            System.err.println("Login failed " + e);
            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                    ResponseDTO
                        .<AuthResponse>builder()
                        .success(false)
                        .message("Đã xảy ra lỗi trong quá trình đăng nhập.")
                        .data(null)
                        .build()
                );
        }
    }

    public ResponseEntity<ResponseDTO<AuthResponse>> signup(SignupRequest signupRequest) {
        try {
            Optional<AppUser> existingAppUser = appUserRepository.findByEmail(signupRequest.getEmail());

            if (existingAppUser.isPresent()) {
                return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(
                        ResponseDTO
                            .<AuthResponse>builder()
                            .success(false)
                            .message("Email đã được đăng ký. Vui lòng chuyển sang đăng nhập.")
                            .data(null)
                            .build()
                    );
            }

            AppUser saveAppUser = new AppUser();
            saveAppUser.setFullName(signupRequest.getFullName());
            saveAppUser.setEmail(signupRequest.getEmail());
            saveAppUser.setAvatarUrl("https://drive.google.com/uc?id=1cJ8NZz98GYRPhqdZLVWyY1NjXL-c2Bl_");
            if (!signupRequest.getPassword().isEmpty()) {
                saveAppUser.setPassword(passwordEncoder.encode(signupRequest.getPassword()));
            }
            saveAppUser.setRole(UserRole.valueOf(signupRequest.getRole()));

            try {
                appUserRepository.save(saveAppUser);

                String token = "";

                if (saveAppUser.getRole() == UserRole.JOB_SEEKER) {
                    JobSeeker jobSeeker = new JobSeeker();
                    jobSeeker.setAppUser(saveAppUser);
                    jobSeekerRepository.save(jobSeeker);
                    token = jwtService.generateToken(jobSeeker.getId(), signupRequest.getEmail(), signupRequest.getRole());
                    System.out.println("Saved job seeker successfully.");
                }

                if (saveAppUser.getRole() == UserRole.EMPLOYER) {
                    Employer employer = new Employer();
                    employer.setAppUser(saveAppUser);
                    employer.setCompanyCode(saveAppUser.getFullName() + saveAppUser.getId());
                    //                    employer.setCompanyName(saveAppUser.getFullName());

                    employerRepository.save(employer);
                    token = jwtService.generateToken(employer.getId(), signupRequest.getEmail(), signupRequest.getRole());
                    System.out.println("Saved employer successfully.");
                }

                AuthResponse authResponse = new AuthResponse(token, appUserMapper.toDto(saveAppUser), null);

                return ResponseEntity.ok(
                    ResponseDTO.<AuthResponse>builder().success(true).message("Đăng ký thành công.").data(authResponse).build()
                );
            } catch (Exception e) {
                System.err.println("Signup failed " + e);
                return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<AuthResponse>builder().success(false).message("Lưu người dùng thất bại.").data(null).build());
            }
        } catch (Exception e) {
            System.err.println("Signup failed " + e);
            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(
                    ResponseDTO.<AuthResponse>builder().success(false).message("Đã xảy ra lỗi trong quá trình đăng ký.").data(null).build()
                );
        }
    }
}
