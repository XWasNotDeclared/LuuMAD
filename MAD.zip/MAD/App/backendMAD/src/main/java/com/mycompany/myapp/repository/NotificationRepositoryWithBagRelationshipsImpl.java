package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Notification;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

/**
 * Utility repository to load bag relationships based on https://vladmihalcea.com/hibernate-multiplebagfetchexception/
 */
public class NotificationRepositoryWithBagRelationshipsImpl implements NotificationRepositoryWithBagRelationships {

    private static final String ID_PARAMETER = "id";
    private static final String NOTIFICATIONS_PARAMETER = "notifications";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<Notification> fetchBagRelationships(Optional<Notification> notification) {
        return notification.map(this::fetchAppUsers);
    }

    @Override
    public Page<Notification> fetchBagRelationships(Page<Notification> notifications) {
        return new PageImpl<>(
            fetchBagRelationships(notifications.getContent()),
            notifications.getPageable(),
            notifications.getTotalElements()
        );
    }

    @Override
    public List<Notification> fetchBagRelationships(List<Notification> notifications) {
        return Optional.of(notifications).map(this::fetchAppUsers).orElse(Collections.emptyList());
    }

    Notification fetchAppUsers(Notification result) {
        return entityManager
            .createQuery(
                "select notification from Notification notification left join fetch notification.appUsers where notification.id = :id",
                Notification.class
            )
            .setParameter(ID_PARAMETER, result.getId())
            .getSingleResult();
    }

    List<Notification> fetchAppUsers(List<Notification> notifications) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, notifications.size()).forEach(index -> order.put(notifications.get(index).getId(), index));
        List<Notification> result = entityManager
            .createQuery(
                "select notification from Notification notification left join fetch notification.appUsers where notification in :notifications",
                Notification.class
            )
            .setParameter(NOTIFICATIONS_PARAMETER, notifications)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }
}
