package com.mycompany.myapp.service.dto.response;

import com.mycompany.myapp.domain.enumeration.NotificationCode;
import java.time.Instant;

public record NotificationResponseByHung(Long id, String title, String content, NotificationCode code, Boolean isRead, Instant createdAt) {}
