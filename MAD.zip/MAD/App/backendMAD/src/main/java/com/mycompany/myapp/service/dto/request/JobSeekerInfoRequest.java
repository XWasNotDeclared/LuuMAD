package com.mycompany.myapp.service.dto.request;

import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobSeekerInfoRequest {

    private String fullName;

    private String phone;

    private String address;

    private MultipartFile avatarFile;

    private Integer expectedSalary;

    private Instant birthDate;

    private String education;

    private String jobType;

    private MultipartFile resumeFile;

    private String description;

    private List<Long> positionIds;

    private List<ExperienceRequest> experiences;
}
