package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Application;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Application entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findAllByIsDeleteFalse();
    Optional<Application> findByIdAndIsDeleteFalse(Long id);

    @Modifying
    @Query("UPDATE Application a SET a.isRead = true WHERE a.isRead = false")
    void markAllAsRead();

    @Modifying
    @Query("UPDATE Application a SET a.isDelete = true WHERE a.isDelete = false")
    void markAllAsDelete();

    List<Application> findByPostIdAndIsDeleteFalse(Long postId);

    @Query("SELECT a FROM Application a WHERE a.post.id IN :postIds AND a.isDelete = false")
    List<Application> findByPostIdInAndIsDeleteFalse(@Param("postIds") List<Long> postIds);

    @Query("SELECT a FROM Application a WHERE a.post.employer.id = :employerId AND a.isDelete = false")
    List<Application> findByEmployerIdAndIsDeleteFalse(@Param("employerId") Long employerId);

    @Modifying
    @Query("UPDATE Application a SET a.isDelete = true WHERE a.id = :id")
    int softDeleteById(@Param("id") Long id);

    @Modifying
    @Query("UPDATE Application a SET a.isRead = true WHERE a.id = :id")
    int softReadById(@Param("id") Long id);

    @Modifying
    @Query("UPDATE Application a SET a.isRead = false WHERE a.id = :id")
    int softNotReadById(@Param("id") Long id);

    @Modifying
    @Query("UPDATE Application a SET a.isDelete = true WHERE a.post.employer.id = :employerId AND a.isDelete = false")
    int markAllByEmployerIdAsDeleted(@Param("employerId") Long employerId);

    @Modifying
    @Query("UPDATE Application a SET a.isRead = true WHERE a.post.employer.id = :employerId AND a.isRead = false")
    int markAllByEmployerIdAsRead(@Param("employerId") Long employerId);

    @Query(
        "SELECT CASE WHEN COUNT(a) > 0 THEN true ELSE false END " +
        "FROM Application a " +
        "WHERE a.post.id = :postId AND a.jobSeeker.id = :jobSeekerId"
    )
    boolean existsByPostIdAndJobSeekerId(@Param("postId") Long postId, @Param("jobSeekerId") Long jobSeekerId);

    //    List<Application> findByPostIdAndIsDeleteFalse(Long employerId);
    //@Query("SELECT a FROM Application a WHERE a.post.employer.id = :employerId AND a.isDelete = false")
    //List<Application> findByPostEmployerIdAndIsDeleteFalse(@Param("employerId") Long employerId);
    @Query(
        """
                SELECT a FROM Application a WHERE a.post.id = :postId
        """
    )
    List<Application> findByPost_Id(@Param("postId") Long postId);

    ////
    //    @Query("SELECT COUNT(a) FROM Application a WHERE a.post.employer.id = :employerId AND a.isRead = false AND a.isDelete = false")
    ////    long countByEmployerIdAndIsReadFalseAndIsDeleteFalse(@Param("employerId") Long employerId);

    @Query("SELECT COUNT(a) FROM Application a WHERE a.post.employer.id = :employerId AND a.isRead = false AND a.isDelete = false")
    long countByEmployerIdAndIsReadFalseAndIsDeleteFalse(@Param("employerId") Long employerId);
}
