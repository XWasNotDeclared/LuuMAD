package com.mycompany.myapp.domain.enumeration;

/**
 * The NotificationCode enumeration.
 */
public enum NotificationCode {
    POST,
    CONTRACT,
}
