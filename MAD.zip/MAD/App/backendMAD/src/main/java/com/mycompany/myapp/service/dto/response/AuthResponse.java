package com.mycompany.myapp.service.dto.response;

import com.mycompany.myapp.service.dto.AppUserDTO;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthResponse {

    private String accessToken;
    private AppUserDTO appUserDTO;
    private Boolean isNew;
}
