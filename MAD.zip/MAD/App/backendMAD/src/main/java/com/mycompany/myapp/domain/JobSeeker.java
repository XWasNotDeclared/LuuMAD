package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.mycompany.myapp.domain.enumeration.JobType;
import com.mycompany.myapp.service.impl.CustomDateDeserializer;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * A JobSeeker.
 */
@Entity
@Table(name = "job_seeker")
@EntityListeners(AuditingEntityListener.class)
@Data
@SuppressWarnings("common-java:DuplicatedBlocks")
public class JobSeeker implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "resume_url")
    private String resumeUrl;

    @Column(name = "expected_salary")
    private Integer expectedSalary;

    @Column(name = "description")
    private String description;

    @Column(name = "education")
    private String education;

    @Column(name = "job_Type")
    @Enumerated(EnumType.STRING)
    private JobType jobType;

    @Column(name = "birth_date")
    @JsonDeserialize(using = CustomDateDeserializer.class)
    private Instant birthDate;

    @JsonIgnoreProperties(value = { "jobSeeker", "employer" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    @JsonBackReference
    private AppUser appUser;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "job_seeker__position",
        joinColumns = @JoinColumn(name = "job_seeker_id"),
        inverseJoinColumns = @JoinColumn(name = "position_id")
    )
    @JsonIgnoreProperties(value = { "category", "jobSeekers" }, allowSetters = true)
    private Set<Position> positions = new HashSet<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "jobSeeker")
    @JsonIgnoreProperties(value = { "jobSeeker" }, allowSetters = true)
    private Set<Experience> experiences = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public JobSeeker id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getResumeUrl() {
        return this.resumeUrl;
    }

    public JobSeeker resumeUrl(String resumeUrl) {
        this.setResumeUrl(resumeUrl);
        return this;
    }

    public void setResumeUrl(String resumeUrl) {
        this.resumeUrl = resumeUrl;
    }

    public Integer getExpectedSalary() {
        return this.expectedSalary;
    }

    public JobSeeker expectedSalary(Integer expectedSalary) {
        this.setExpectedSalary(expectedSalary);
        return this;
    }

    public void setExpectedSalary(Integer expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getDescription() {
        return this.description;
    }

    public JobSeeker description(String description) {
        this.setDescription(description);
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public JobType getJobType() {
        return jobType;
    }

    public void setJobType(JobType jobType) {
        this.jobType = jobType;
    }

    public Instant getBirthDate() {
        return this.birthDate;
    }

    public JobSeeker birthDate(Instant birthDate) {
        this.setBirthDate(birthDate);
        return this;
    }

    public void setBirthDate(Instant birthDate) {
        this.birthDate = birthDate;
    }

    public AppUser getAppUser() {
        return this.appUser;
    }

    public void setAppUser(AppUser appUser) {
        this.appUser = appUser;
    }

    public JobSeeker appUser(AppUser appUser) {
        this.setAppUser(appUser);
        return this;
    }

    public Set<Position> getPositions() {
        return this.positions;
    }

    public void setPositions(Set<Position> positions) {
        this.positions = positions;
    }

    public JobSeeker positions(Set<Position> positions) {
        this.setPositions(positions);
        return this;
    }

    public JobSeeker addPositions(Position position) {
        this.positions.add(position);
        return this;
    }

    public JobSeeker removePositions(Position position) {
        this.positions.remove(position);
        return this;
    }

    public Set<Experience> getExperiences() {
        return this.experiences;
    }

    public void setExperiences(Set<Experience> experiences) {
        if (this.experiences != null) {
            this.experiences.forEach(i -> i.setJobSeeker(null));
        }
        if (experiences != null) {
            experiences.forEach(i -> i.setJobSeeker(this));
        }
        this.experiences = experiences;
    }

    public JobSeeker experiences(Set<Experience> experiences) {
        this.setExperiences(experiences);
        return this;
    }

    public JobSeeker addExperiences(Experience experience) {
        this.experiences.add(experience);
        experience.setJobSeeker(this);
        return this;
    }

    public JobSeeker removeExperiences(Experience experience) {
        this.experiences.remove(experience);
        experience.setJobSeeker(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof JobSeeker)) {
            return false;
        }
        return getId() != null && getId().equals(((JobSeeker) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "JobSeeker{" +
            "id=" + getId() +
            ", resumeUrl='" + getResumeUrl() + "'" +
            ", expectedSalary=" + getExpectedSalary() +
            ", description='" + getDescription() + "'" +
            ", birthDate='" + getBirthDate() + "'" +
            "}";
    }
}
