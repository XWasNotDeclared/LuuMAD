package com.mycompany.myapp.service.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContractRequest {

    private String jobTitle;
    private String contractDuration;
    private Integer proposedSalary;
    private String appointmentDate;
    private Long recieverId;
    private String link;
}
