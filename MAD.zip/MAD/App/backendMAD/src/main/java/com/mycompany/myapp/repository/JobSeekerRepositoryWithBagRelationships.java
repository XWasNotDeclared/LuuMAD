package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.JobSeeker;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;

public interface JobSeekerRepositoryWithBagRelationships {
    Optional<JobSeeker> fetchBagRelationships(Optional<JobSeeker> jobSeeker);

    List<JobSeeker> fetchBagRelationships(List<JobSeeker> jobSeekers);

    Page<JobSeeker> fetchBagRelationships(Page<JobSeeker> jobSeekers);
}
