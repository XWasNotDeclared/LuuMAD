package com.mycompany.myapp.service.dto;

import com.mycompany.myapp.domain.enumeration.JobType;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.JobSeeker} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class JobSeekerDTO implements Serializable {

    private Long id;

    private String resumeUrl;

    private Integer expectedSalary;

    private String description;

    private Instant birthDate;
    private String education;
    private JobType jobType;

    private AppUserDTO appUser;

    //
    //    private Set<Long> positions;
    //
    //    private Set<Long> experiences;
    //    private Set<PositionDTO> positions;
    //
    //    private Set<ExperienceDTO> experiences;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getResumeUrl() {
        return resumeUrl;
    }

    public void setResumeUrl(String resumeUrl) {
        this.resumeUrl = resumeUrl;
    }

    public Integer getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(Integer expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Instant getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Instant birthDate) {
        this.birthDate = birthDate;
    }

    public AppUserDTO getAppUser() {
        return appUser;
    }

    public void setAppUser(AppUserDTO appUser) {
        this.appUser = appUser;
    }

    //    public Set<Long> getPositions() {
    //        return positions;
    //    }
    //
    //    public void setPositions(Set<Long> positions) {
    //        this.positions = positions;
    //    }
    //
    //    public Set<Long> getExperiences() {
    //        return experiences;
    //    }
    //
    //    public void setExperiences(Set<Long> experiences) {
    //        this.experiences = experiences;
    //    }
    //    public Set<PositionDTO> getPositions() {
    //        return positions;
    //    }
    //
    //    public void setPositions(Set<PositionDTO> positions) {
    //        this.positions = positions;
    //    }
    //
    //    public Set<ExperienceDTO> getExperiences() {
    //        return experiences;
    //    }
    //
    //    public void setExperiences(Set<ExperienceDTO> experiences) {
    //        this.experiences = experiences;
    //    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public JobType getJobType() {
        return jobType;
    }

    public void setJobType(JobType jobType) {
        this.jobType = jobType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof JobSeekerDTO)) {
            return false;
        }

        JobSeekerDTO jobSeekerDTO = (JobSeekerDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, jobSeekerDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "JobSeekerDTO{" +
            "id=" + getId() +
            ", resumeUrl='" + getResumeUrl() + "'" +
            ", expectedSalary=" + getExpectedSalary() +
            ", description='" + getDescription() + "'" +
            ", birthDate='" + getBirthDate() + "'" +
            ", appUser=" + getAppUser() +
//            ", positions=" + getPositions() +
//            ", experiences=" + getExperiences() +
            "}";
    }
}
