package com.mycompany.myapp.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * A Employer.
 */
@Entity
@Table(name = "employer")
@EntityListeners(AuditingEntityListener.class)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class Employer implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "company_code", unique = true, nullable = true)
    private String companyCode;

    @Lob
    @Column(name = "company_description")
    private String companyDescription;

    @Column(name = "company_website")
    private String companyWebsite;

    @Column(name = "workforce_size")
    private Integer workforceSize;

    @Column(name = "business_type")
    private String businessType;

    @Column(name = "year_established")
    private Integer yearEstablished;

    @Column(name = "specialization")
    private String specialization;

    @JsonIgnoreProperties(value = { "jobSeeker", "employer" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private AppUser appUser;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public Employer id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return this.companyName;
    }

    public Employer companyName(String companyName) {
        this.setCompanyName(companyName);
        return this;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCode() {
        return this.companyCode;
    }

    public Employer companyCode(String companyCode) {
        this.setCompanyCode(companyCode);
        return this;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyDescription() {
        return this.companyDescription;
    }

    public Employer companyDescription(String companyDescription) {
        this.setCompanyDescription(companyDescription);
        return this;
    }

    public void setCompanyDescription(String companyDescription) {
        this.companyDescription = companyDescription;
    }

    public String getCompanyWebsite() {
        return this.companyWebsite;
    }

    public Employer companyWebsite(String companyWebsite) {
        this.setCompanyWebsite(companyWebsite);
        return this;
    }

    public void setCompanyWebsite(String companyWebsite) {
        this.companyWebsite = companyWebsite;
    }

    public Integer getWorkforceSize() {
        return this.workforceSize;
    }

    public Employer workforceSize(Integer workforceSize) {
        this.setWorkforceSize(workforceSize);
        return this;
    }

    public void setWorkforceSize(Integer workforceSize) {
        this.workforceSize = workforceSize;
    }

    public String getBusinessType() {
        return this.businessType;
    }

    public Employer businessType(String businessType) {
        this.setBusinessType(businessType);
        return this;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public Integer getYearEstablished() {
        return this.yearEstablished;
    }

    public Employer yearEstablished(Integer yearEstablished) {
        this.setYearEstablished(yearEstablished);
        return this;
    }

    public void setYearEstablished(Integer yearEstablished) {
        this.yearEstablished = yearEstablished;
    }

    public String getSpecialization() {
        return this.specialization;
    }

    public Employer specialization(String specialization) {
        this.setSpecialization(specialization);
        return this;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public AppUser getAppUser() {
        return this.appUser;
    }

    public void setAppUser(AppUser appUser) {
        this.appUser = appUser;
    }

    public Employer appUser(AppUser appUser) {
        this.setAppUser(appUser);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Employer)) {
            return false;
        }
        return getId() != null && getId().equals(((Employer) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Employer{" +
            "id=" + getId() +
            ", companyName='" + getCompanyName() + "'" +
            ", companyCode='" + getCompanyCode() + "'" +
            ", companyDescription='" + getCompanyDescription() + "'" +
            ", companyWebsite='" + getCompanyWebsite() + "'" +
            ", workforceSize=" + getWorkforceSize() +
            ", businessType='" + getBusinessType() + "'" +
            ", yearEstablished=" + getYearEstablished() +
            ", specialization='" + getSpecialization() + "'" +
            "}";
    }
}
