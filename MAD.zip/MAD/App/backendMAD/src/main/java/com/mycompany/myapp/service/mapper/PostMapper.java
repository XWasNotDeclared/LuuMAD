package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.domain.Post;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.PositionDTO;
import com.mycompany.myapp.service.dto.PostDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Post} and its DTO {@link PostDTO}.
 */
@Mapper(componentModel = "spring")
public interface PostMapper extends EntityMapper<PostDTO, Post> {
    @Mapping(target = "position", source = "position", qualifiedByName = "positionIdAndName")
    @Mapping(target = "employer", source = "employer", qualifiedByName = "employerIdAndCompanyName")
    @Mapping(target = "appUser", source = "employer.appUser", qualifiedByName = "appUserBasic")
    PostDTO toDto(Post s);

    @Named("positionIdAndName")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "name", source = "name")
    PositionDTO toDtoPositionIdAndName(Position position);

    @Named("employerIdAndCompanyName")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "companyName", source = "companyName")
    EmployerDTO toDtoEmployerIdAndCompanyName(Employer employer);

    @Named("appUserBasic")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "email", source = "email")
    @Mapping(target = "fullName", source = "fullName")
    @Mapping(target = "avatarUrl", source = "avatarUrl")
    AppUserDTO toDtoAppUserBasic(com.mycompany.myapp.domain.AppUser appUser);
    // @Mapping(target = "position", source = "position", qualifiedByName = "positionId")
    // @Mapping(target = "employer", source = "employer", qualifiedByName = "employerId")
    // PostDTO toDto(Post s);

    // @Named("positionId")
    // @BeanMapping(ignoreByDefault = true)
    // @Mapping(target = "id", source = "id")
    // PositionDTO toDtoPositionId(Position position);

    // @Named("employerId")
    // @BeanMapping(ignoreByDefault = true)
    // @Mapping(target = "id", source = "id")
    // EmployerDTO toDtoEmployerId(Employer employer);
}
