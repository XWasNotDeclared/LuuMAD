package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.repository.ApplicationScheduleRepository;
import com.mycompany.myapp.service.ApplicationScheduleService;
import com.mycompany.myapp.service.dto.ApplicationScheduleDTO;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ApplicationSchedule}.
 */
@RestController
@RequestMapping("/api/app/application-schedules")
public class ApplicationScheduleResource {

    private static final Logger LOG = LoggerFactory.getLogger(ApplicationScheduleResource.class);

    private static final String ENTITY_NAME = "applicationSchedule";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ApplicationScheduleService applicationScheduleService;

    private final ApplicationScheduleRepository applicationScheduleRepository;

    public ApplicationScheduleResource(
        ApplicationScheduleService applicationScheduleService,
        ApplicationScheduleRepository applicationScheduleRepository
    ) {
        this.applicationScheduleService = applicationScheduleService;
        this.applicationScheduleRepository = applicationScheduleRepository;
    }

    /**
     * {@code POST  /application-schedules} : Create a new applicationSchedule.
     *
     * @param applicationScheduleDTO the applicationScheduleDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new applicationScheduleDTO, or with status {@code 400 (Bad Request)} if the applicationSchedule has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<ApplicationScheduleDTO> createApplicationSchedule(
        @Valid @RequestBody ApplicationScheduleDTO applicationScheduleDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to save ApplicationSchedule : {}", applicationScheduleDTO);
        if (applicationScheduleDTO.getId() != null) {
            throw new BadRequestAlertException("A new applicationSchedule cannot already have an ID", ENTITY_NAME, "idexists");
        }
        applicationScheduleDTO = applicationScheduleService.save(applicationScheduleDTO);
        return ResponseEntity
            .created(new URI("/api/application-schedules/" + applicationScheduleDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, applicationScheduleDTO.getId().toString()))
            .body(applicationScheduleDTO);
    }

    /**
     * {@code PUT  /application-schedules/:id} : Updates an existing applicationSchedule.
     *
     * @param id the id of the applicationScheduleDTO to save.
     * @param applicationScheduleDTO the applicationScheduleDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated applicationScheduleDTO,
     * or with status {@code 400 (Bad Request)} if the applicationScheduleDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the applicationScheduleDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApplicationScheduleDTO> updateApplicationSchedule(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody ApplicationScheduleDTO applicationScheduleDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update ApplicationSchedule : {}, {}", id, applicationScheduleDTO);
        if (applicationScheduleDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, applicationScheduleDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!applicationScheduleRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        applicationScheduleDTO = applicationScheduleService.update(applicationScheduleDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, applicationScheduleDTO.getId().toString()))
            .body(applicationScheduleDTO);
    }

    /**
     * {@code PATCH  /application-schedules/:id} : Partial updates given fields of an existing applicationSchedule, field will ignore if it is null
     *
     * @param id the id of the applicationScheduleDTO to save.
     * @param applicationScheduleDTO the applicationScheduleDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated applicationScheduleDTO,
     * or with status {@code 400 (Bad Request)} if the applicationScheduleDTO is not valid,
     * or with status {@code 404 (Not Found)} if the applicationScheduleDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the applicationScheduleDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<ApplicationScheduleDTO> partialUpdateApplicationSchedule(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody ApplicationScheduleDTO applicationScheduleDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update ApplicationSchedule partially : {}, {}", id, applicationScheduleDTO);
        if (applicationScheduleDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, applicationScheduleDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!applicationScheduleRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<ApplicationScheduleDTO> result = applicationScheduleService.partialUpdate(applicationScheduleDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, applicationScheduleDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /application-schedules} : get all the applicationSchedules.
     *
     * @param pageable the pagination information.
     * @param filter the filter of the request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of applicationSchedules in body.
     */
    @GetMapping("")
    public ResponseEntity<List<ApplicationScheduleDTO>> getAllApplicationSchedules(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable,
        @RequestParam(name = "filter", required = false) String filter
    ) {
        if ("application-is-null".equals(filter)) {
            LOG.debug("REST request to get all ApplicationSchedules where application is null");
            return new ResponseEntity<>(applicationScheduleService.findAllWhereApplicationIsNull(), HttpStatus.OK);
        }
        LOG.debug("REST request to get a page of ApplicationSchedules");
        Page<ApplicationScheduleDTO> page = applicationScheduleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /application-schedules/:id} : get the "id" applicationSchedule.
     *
     * @param id the id of the applicationScheduleDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the applicationScheduleDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApplicationScheduleDTO> getApplicationSchedule(@PathVariable("id") Long id) {
        LOG.debug("REST request to get ApplicationSchedule : {}", id);
        Optional<ApplicationScheduleDTO> applicationScheduleDTO = applicationScheduleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(applicationScheduleDTO);
    }

    /**
     * {@code DELETE  /application-schedules/:id} : delete the "id" applicationSchedule.
     *
     * @param id the id of the applicationScheduleDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteApplicationSchedule(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete ApplicationSchedule : {}", id);
        applicationScheduleService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
