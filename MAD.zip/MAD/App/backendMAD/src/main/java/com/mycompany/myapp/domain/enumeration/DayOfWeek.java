package com.mycompany.myapp.domain.enumeration;

/**
 * The DayOfWeek enumeration.
 */
public enum DayOfWeek {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY,
}
