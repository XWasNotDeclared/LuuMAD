package com.mycompany.myapp.service.dto;

import java.util.List;

public class JobSeekerFilterRequest {

    private List<Long> categoryIds;
    private List<String> jobTypes;
    private List<String> locations;
    private Integer minSalary;
    private Integer maxSalary;
    private String minYearsExperience;
    private String positionName;

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public List<String> getJobTypes() {
        return jobTypes;
    }

    public void setJobTypes(List<String> jobTypes) {
        this.jobTypes = jobTypes;
    }

    public List<String> getLocations() {
        return locations;
    }

    public void setLocations(List<String> locations) {
        this.locations = locations;
    }

    public Integer getMinSalary() {
        return minSalary;
    }

    public void setMinSalary(Integer minSalary) {
        this.minSalary = minSalary;
    }

    public Integer getMaxSalary() {
        return maxSalary;
    }

    public void setMaxSalary(Integer maxSalary) {
        this.maxSalary = maxSalary;
    }

    public String getMinYearsExperience() {
        return minYearsExperience;
    }

    public void setMinYearsExperience(String minYearsExperience) {
        this.minYearsExperience = minYearsExperience;
    }
}
