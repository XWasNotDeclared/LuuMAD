package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Notification;
import com.mycompany.myapp.domain.NotificationReceiver;
import com.mycompany.myapp.domain.enumeration.NotificationCode;
import com.mycompany.myapp.repository.NotificationReceiverRepository;
import com.mycompany.myapp.repository.NotificationRepository;
import com.mycompany.myapp.service.NotificationService;
import com.mycompany.myapp.service.dto.NotificationDTO;
import com.mycompany.myapp.service.mapper.NotificationMapper;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Notification}.
 */
@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationServiceImpl.class);

    private final NotificationRepository notificationRepository;

    private final NotificationMapper notificationMapper;

    private final NotificationReceiverRepository notificationReceiverRepository;

    public NotificationServiceImpl(
        NotificationRepository notificationRepository,
        NotificationMapper notificationMapper,
        NotificationReceiverRepository notificationReceiverRepository
    ) {
        this.notificationRepository = notificationRepository;
        this.notificationMapper = notificationMapper;
        this.notificationReceiverRepository = notificationReceiverRepository;
    }

    @Override
    public NotificationDTO save(NotificationDTO notificationDTO) {
        LOG.debug("Request to save Notification : {}", notificationDTO);
        Notification notification = notificationMapper.toEntity(notificationDTO);
        notification = notificationRepository.save(notification);
        return notificationMapper.toDto(notification);
    }

    @Override
    public NotificationDTO update(NotificationDTO notificationDTO) {
        LOG.debug("Request to update Notification : {}", notificationDTO);
        Notification notification = notificationMapper.toEntity(notificationDTO);
        notification = notificationRepository.save(notification);
        return notificationMapper.toDto(notification);
    }

    @Override
    public Optional<NotificationDTO> partialUpdate(NotificationDTO notificationDTO) {
        LOG.debug("Request to partially update Notification : {}", notificationDTO);

        return notificationRepository
            .findById(notificationDTO.getId())
            .map(existingNotification -> {
                notificationMapper.partialUpdate(existingNotification, notificationDTO);

                return existingNotification;
            })
            .map(notificationRepository::save)
            .map(notificationMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NotificationDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Notifications");
        return notificationRepository.findAll(pageable).map(notificationMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<NotificationDTO> findOne(Long id) {
        LOG.debug("Request to get Notification : {}", id);
        return notificationRepository.findById(id).map(notificationMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Notification : {}", id);
        notificationRepository.deleteById(id);
    }

    @Override
    public void notifyUser(
        AppUser sender,
        List<AppUser> receivers,
        String title,
        String content,
        NotificationCode code,
        String metaType,
        Map<String, String> metaData
    ) {
        // 1. Tạo metadata string để nhét vào content
        StringBuilder metaStr = new StringBuilder("{meta:type=" + metaType);
        metaData.forEach((k, v) -> metaStr.append("," + k + "=" + v));
        metaStr.append("}");

        // 2. Ghép vào content
        String finalContent = content + " " + metaStr;

        // 3. Tạo thông báo
        Notification noti = new Notification();
        noti.setTitle(title);
        noti.setContent(finalContent);
        noti.setNotiCode(code);
        noti.setSender(sender);
        notificationRepository.save(noti);

        // 4. Gửi cho từng người nhận
        for (AppUser receiver : receivers) {
            NotificationReceiver nr = new NotificationReceiver();
            nr.setNotification(noti);
            nr.setReceiver(receiver);
            nr.setIsRead(false);
            notificationReceiverRepository.save(nr);
            // TODO: Push notify (nếu có)
            // pushService.push(nr);
        }
    }
}
