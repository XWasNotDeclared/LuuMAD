package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Notification;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;

public interface NotificationRepositoryWithBagRelationships {
    Optional<Notification> fetchBagRelationships(Optional<Notification> notification);

    List<Notification> fetchBagRelationships(List<Notification> notifications);

    Page<Notification> fetchBagRelationships(Page<Notification> notifications);
}
