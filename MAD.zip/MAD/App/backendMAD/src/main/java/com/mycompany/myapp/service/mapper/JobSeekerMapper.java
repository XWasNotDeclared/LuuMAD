package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.PositionDTO;
import java.util.Set;
import java.util.stream.Collectors;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link JobSeeker} and its DTO {@link JobSeekerDTO}.
 */
@Mapper(componentModel = "spring", uses = { AppUserMapper.class })
public interface JobSeekerMapper extends EntityMapper<JobSeekerDTO, JobSeeker> {
    //    @Mapping(target = "positions", source = "positions", qualifiedByName = "positionIdSet")
    //    @Mapping(target = "appUser", source = "appUser") // full mapping
    //    JobSeekerDTO toDto(JobSeeker jobSeeker);
    //
    //    @Mapping(target = "appUser", source = "appUser")
    //    JobSeeker toEntity(JobSeekerDTO jobSeekerDTO);
    //
    //    @Named("appUserId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    AppUserDTO toDtoAppUserId(AppUser appUser);
    //
    //    @Named("positionId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    @Mapping(target = "name", source = "name")
    //    PositionDTO toDtoPositionId(Position position);
    //
    //    @Named("positionIdSet")
    //    default Set<PositionDTO> toDtoPositionIdSet(Set<Position> position) {
    //        return position.stream().map(this::toDtoPositionId).collect(Collectors.toSet());
    //    }
}
