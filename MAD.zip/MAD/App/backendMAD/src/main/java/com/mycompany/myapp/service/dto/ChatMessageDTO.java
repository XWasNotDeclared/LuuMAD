package com.mycompany.myapp.service.dto;

import com.mycompany.myapp.domain.enumeration.MessageType;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.web.multipart.MultipartFile;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatMessageDTO {

    private Long id; // Lấy từ Message.id
    private String content; // Lấy từ Message.content
    private Instant sentAt; // Lấy từ Message.sentAt
    private MessageType messageType; // Lấy từ Message.messageType

    private Long senderId; // Lấy từ Message.sender.id
    private Long receiverId; // Lấy từ MessageReceiver.receiver.id
    private Boolean isRead; // Lấy từ MessageReceiver.isRead

    @Nullable
    private MultipartFile file;
}
