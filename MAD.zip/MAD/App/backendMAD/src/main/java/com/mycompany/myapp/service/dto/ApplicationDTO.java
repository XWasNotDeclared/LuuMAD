package com.mycompany.myapp.service.dto;

import com.mycompany.myapp.domain.enumeration.ApplicationStatus;
import java.io.Serializable;
import java.time.Instant;

/**
 * A DTO for the {@link com.mycompany.myapp.domain.Application} entity.
 */
public class ApplicationDTO implements Serializable {

    private Long id;
    private ApplicationStatus status;
    private Instant appliedAt;
    private String coverLetter;
    private String cvLink;
    private String timeslot;
    private Boolean isRead;
    private Boolean isDelete;
    private Long jobSeekerId;
    private Long postId;
    private Long employerId;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public void setStatus(ApplicationStatus status) {
        this.status = status;
    }

    public Instant getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(Instant appliedAt) {
        this.appliedAt = appliedAt;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public String getCvLink() {
        return cvLink;
    }

    public void setCvLink(String cvLink) {
        this.cvLink = cvLink;
    }

    public String getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(String timeslot) {
        this.timeslot = timeslot;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Boolean getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Boolean isDelete) {
        this.isDelete = isDelete;
    }

    public Long getJobSeekerId() {
        return jobSeekerId;
    }

    public void setJobSeekerId(Long jobSeekerId) {
        this.jobSeekerId = jobSeekerId;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public Long getEmployerId() {
        return employerId;
    }

    public void setEmployerId(Long employerId) {
        this.employerId = employerId;
    }

    @Override
    public String toString() {
        return (
            "ApplicationDTO{" +
            "id=" +
            id +
            ", status=" +
            status +
            ", appliedAt=" +
            appliedAt +
            ", coverLetter='" +
            coverLetter +
            '\'' +
            ", cvLink='" +
            cvLink +
            '\'' +
            ", timeslot='" +
            timeslot +
            '\'' +
            ", isRead=" +
            isRead +
            ", isDelete=" +
            isDelete +
            ", jobSeekerId=" +
            jobSeekerId +
            ", postId=" +
            postId +
            ", employerId=" +
            employerId +
            '}'
        );
    }
}
