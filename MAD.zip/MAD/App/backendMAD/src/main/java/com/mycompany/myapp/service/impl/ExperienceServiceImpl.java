package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.Experience;
import com.mycompany.myapp.repository.ExperienceRepository;
import com.mycompany.myapp.service.ExperienceService;
import com.mycompany.myapp.service.dto.ExperienceDTO;
import com.mycompany.myapp.service.dto.PositionDTO;
import com.mycompany.myapp.service.mapper.ExperienceMapper;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Experience}.
 */
@Service
@Transactional
public class ExperienceServiceImpl implements ExperienceService {

    private static final Logger LOG = LoggerFactory.getLogger(ExperienceServiceImpl.class);

    private final ExperienceRepository experienceRepository;

    private final ExperienceMapper experienceMapper;

    public ExperienceServiceImpl(ExperienceRepository experienceRepository, ExperienceMapper experienceMapper) {
        this.experienceRepository = experienceRepository;
        this.experienceMapper = experienceMapper;
    }

    @Override
    public List<ExperienceDTO> getExperiencesByJobSeekerId(Long jobSeekerId) {
        return experienceRepository.findByJobSeeker_Id(jobSeekerId).stream().map(experienceMapper::toDto).collect(Collectors.toList());
    }

    @Override
    public ExperienceDTO save(ExperienceDTO experienceDTO) {
        LOG.debug("Request to save Experience : {}", experienceDTO);
        Experience experience = experienceMapper.toEntity(experienceDTO);
        experience = experienceRepository.save(experience);
        return experienceMapper.toDto(experience);
    }

    @Override
    public ExperienceDTO update(ExperienceDTO experienceDTO) {
        LOG.debug("Request to update Experience : {}", experienceDTO);
        Experience experience = experienceMapper.toEntity(experienceDTO);
        experience = experienceRepository.save(experience);
        return experienceMapper.toDto(experience);
    }

    @Override
    public Optional<ExperienceDTO> partialUpdate(ExperienceDTO experienceDTO) {
        LOG.debug("Request to partially update Experience : {}", experienceDTO);

        return experienceRepository
            .findById(experienceDTO.getId())
            .map(existingExperience -> {
                experienceMapper.partialUpdate(existingExperience, experienceDTO);

                return existingExperience;
            })
            .map(experienceRepository::save)
            .map(experienceMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ExperienceDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Experiences");
        return experienceRepository.findAll(pageable).map(experienceMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ExperienceDTO> findOne(Long id) {
        LOG.debug("Request to get Experience : {}", id);
        return experienceRepository.findById(id).map(experienceMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Experience : {}", id);
        experienceRepository.deleteById(id);
    }

    @Override
    public double calculateTotalYearsOfExperience(Long jobSeekerId) {
        List<Experience> experiences = experienceRepository.findByJobSeeker_Id(jobSeekerId);

        double totalYears = 0.0;

        for (Experience exp : experiences) {
            LocalDate start = exp.getStartDate();
            LocalDate end = exp.getEndDate() != null ? exp.getEndDate() : LocalDate.now();

            if (start != null && end != null && !end.isBefore(start)) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(start, end);
                totalYears += days / 365.0; // Convert days to years
            }
        }

        return Math.round(totalYears * 100.0) / 100.0; // round to 2 decimal places
    }
}
