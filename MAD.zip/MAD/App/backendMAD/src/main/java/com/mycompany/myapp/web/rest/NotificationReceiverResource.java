package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.repository.NotificationReceiverRepository;
import com.mycompany.myapp.service.NotificationReceiverService;
import com.mycompany.myapp.service.dto.NotificationReceiverDTO;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.NotificationReceiver}.
 */
@RestController
@RequestMapping("/api/app/notification-receivers")
public class NotificationReceiverResource {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationReceiverResource.class);

    private static final String ENTITY_NAME = "notificationReceiver";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final NotificationReceiverService notificationReceiverService;

    private final NotificationReceiverRepository notificationReceiverRepository;

    public NotificationReceiverResource(
        NotificationReceiverService notificationReceiverService,
        NotificationReceiverRepository notificationReceiverRepository
    ) {
        this.notificationReceiverService = notificationReceiverService;
        this.notificationReceiverRepository = notificationReceiverRepository;
    }

    /**
     * {@code POST  /notification-receivers} : Create a new notificationReceiver.
     *
     * @param notificationReceiverDTO the notificationReceiverDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new notificationReceiverDTO, or with status {@code 400 (Bad Request)} if the notificationReceiver has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<NotificationReceiverDTO> createNotificationReceiver(
        @Valid @RequestBody NotificationReceiverDTO notificationReceiverDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to save NotificationReceiver : {}", notificationReceiverDTO);
        if (notificationReceiverDTO.getId() != null) {
            throw new BadRequestAlertException("A new notificationReceiver cannot already have an ID", ENTITY_NAME, "idexists");
        }
        notificationReceiverDTO = notificationReceiverService.save(notificationReceiverDTO);
        return ResponseEntity
            .created(new URI("/api/notification-receivers/" + notificationReceiverDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, notificationReceiverDTO.getId().toString()))
            .body(notificationReceiverDTO);
    }

    /**
     * {@code PUT  /notification-receivers/:id} : Updates an existing notificationReceiver.
     *
     * @param id the id of the notificationReceiverDTO to save.
     * @param notificationReceiverDTO the notificationReceiverDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated notificationReceiverDTO,
     * or with status {@code 400 (Bad Request)} if the notificationReceiverDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the notificationReceiverDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<NotificationReceiverDTO> updateNotificationReceiver(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody NotificationReceiverDTO notificationReceiverDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update NotificationReceiver : {}, {}", id, notificationReceiverDTO);
        if (notificationReceiverDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, notificationReceiverDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!notificationReceiverRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        notificationReceiverDTO = notificationReceiverService.update(notificationReceiverDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, notificationReceiverDTO.getId().toString()))
            .body(notificationReceiverDTO);
    }

    /**
     * {@code PATCH  /notification-receivers/:id} : Partial updates given fields of an existing notificationReceiver, field will ignore if it is null
     *
     * @param id the id of the notificationReceiverDTO to save.
     * @param notificationReceiverDTO the notificationReceiverDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated notificationReceiverDTO,
     * or with status {@code 400 (Bad Request)} if the notificationReceiverDTO is not valid,
     * or with status {@code 404 (Not Found)} if the notificationReceiverDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the notificationReceiverDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<NotificationReceiverDTO> partialUpdateNotificationReceiver(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody NotificationReceiverDTO notificationReceiverDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update NotificationReceiver partially : {}, {}", id, notificationReceiverDTO);
        if (notificationReceiverDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, notificationReceiverDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!notificationReceiverRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<NotificationReceiverDTO> result = notificationReceiverService.partialUpdate(notificationReceiverDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, notificationReceiverDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /notification-receivers} : get all the notificationReceivers.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of notificationReceivers in body.
     */
    @GetMapping("")
    public ResponseEntity<List<NotificationReceiverDTO>> getAllNotificationReceivers(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable
    ) {
        LOG.debug("REST request to get a page of NotificationReceivers");
        Page<NotificationReceiverDTO> page = notificationReceiverService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /notification-receivers/:id} : get the "id" notificationReceiver.
     *
     * @param id the id of the notificationReceiverDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the notificationReceiverDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<NotificationReceiverDTO> getNotificationReceiver(@PathVariable("id") Long id) {
        LOG.debug("REST request to get NotificationReceiver : {}", id);
        Optional<NotificationReceiverDTO> notificationReceiverDTO = notificationReceiverService.findOne(id);
        return ResponseUtil.wrapOrNotFound(notificationReceiverDTO);
    }

    /**
     * {@code DELETE  /notification-receivers/:id} : delete the "id" notificationReceiver.
     *
     * @param id the id of the notificationReceiverDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNotificationReceiver(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete NotificationReceiver : {}", id);
        notificationReceiverService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
