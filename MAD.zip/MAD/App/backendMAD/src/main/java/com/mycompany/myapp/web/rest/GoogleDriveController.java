package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.service.GoogleDriveService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "Google Drive", description = "APIs for uploading files to Google Drive")
@RestController
@RequestMapping("/api/app/job-seekers")
public class GoogleDriveController {

    private final GoogleDriveService googleDriveService;

    @Autowired
    public GoogleDriveController(GoogleDriveService googleDriveService) {
        this.googleDriveService = googleDriveService;
    }

    @Operation(
        summary = "Upload a PDF file to Google Drive",
        description = "Uploads a PDF file to Google Drive and returns a link to view or download the file."
    )
    @ApiResponse(
        responseCode = "200",
        description = "File uploaded successfully",
        content = @Content(schema = @Schema(implementation = String.class))
    )
    @ApiResponse(responseCode = "400", description = "File is empty", content = @Content)
    @ApiResponse(responseCode = "500", description = "Upload failed", content = @Content)
    @PostMapping(value = "/upload", consumes = "multipart/form-data")
    public ResponseEntity<?> uploadFile(
        @Parameter(description = "PDF file to upload", required = true) @RequestParam("file") MultipartFile file
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("File is empty.");
        }

        try {
            String url = googleDriveService.uploadFile(file);
            return ResponseEntity.ok().body(url);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("Upload failed: " + e.getMessage());
        }
    }
}
