package com.mycompany.myapp.service;

import com.mycompany.myapp.service.dto.AppUserDTO;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.mycompany.myapp.domain.AppUser}.
 */
public interface AppUserService {
    Page<AppUserDTO> searchAppUsersByName(String keyword, Pageable pageable);

    void updateStatus(Long id, String status);

    /**
     * Save a appUser.
     *
     * @param appUserDTO the entity to save.
     * @return the persisted entity.
     */
    AppUserDTO save(AppUserDTO appUserDTO);

    /**
     * Updates a appUser.
     *
     * @param appUserDTO the entity to update.
     * @return the persisted entity.
     */
    AppUserDTO update(AppUserDTO appUserDTO);

    /**
     * Partially updates a appUser.
     *
     * @param appUserDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AppUserDTO> partialUpdate(AppUserDTO appUserDTO);

    /**
     * Get all the appUsers.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<AppUserDTO> findAll(Pageable pageable);

    /**
     * Get all the AppUserDTO where JobSeeker is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<AppUserDTO> findAllWhereJobSeekerIsNull();
    /**
     * Get all the AppUserDTO where Employer is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<AppUserDTO> findAllWhereEmployerIsNull();

    /**
     * Get the "id" appUser.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AppUserDTO> findOne(Long id);

    /**
     * Delete the "id" appUser.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
