package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.ApplicationSchedule;
import com.mycompany.myapp.repository.ApplicationScheduleRepository;
import com.mycompany.myapp.service.ApplicationScheduleService;
import com.mycompany.myapp.service.dto.ApplicationScheduleDTO;
import com.mycompany.myapp.service.mapper.ApplicationScheduleMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.ApplicationSchedule}.
 */
@Service
@Transactional
public class ApplicationScheduleServiceImpl implements ApplicationScheduleService {

    private static final Logger LOG = LoggerFactory.getLogger(ApplicationScheduleServiceImpl.class);

    private final ApplicationScheduleRepository applicationScheduleRepository;

    private final ApplicationScheduleMapper applicationScheduleMapper;

    public ApplicationScheduleServiceImpl(
        ApplicationScheduleRepository applicationScheduleRepository,
        ApplicationScheduleMapper applicationScheduleMapper
    ) {
        this.applicationScheduleRepository = applicationScheduleRepository;
        this.applicationScheduleMapper = applicationScheduleMapper;
    }

    @Override
    public ApplicationScheduleDTO save(ApplicationScheduleDTO applicationScheduleDTO) {
        LOG.debug("Request to save ApplicationSchedule : {}", applicationScheduleDTO);
        ApplicationSchedule applicationSchedule = applicationScheduleMapper.toEntity(applicationScheduleDTO);
        applicationSchedule = applicationScheduleRepository.save(applicationSchedule);
        return applicationScheduleMapper.toDto(applicationSchedule);
    }

    @Override
    public ApplicationScheduleDTO update(ApplicationScheduleDTO applicationScheduleDTO) {
        LOG.debug("Request to update ApplicationSchedule : {}", applicationScheduleDTO);
        ApplicationSchedule applicationSchedule = applicationScheduleMapper.toEntity(applicationScheduleDTO);
        applicationSchedule = applicationScheduleRepository.save(applicationSchedule);
        return applicationScheduleMapper.toDto(applicationSchedule);
    }

    @Override
    public Optional<ApplicationScheduleDTO> partialUpdate(ApplicationScheduleDTO applicationScheduleDTO) {
        LOG.debug("Request to partially update ApplicationSchedule : {}", applicationScheduleDTO);

        return applicationScheduleRepository
            .findById(applicationScheduleDTO.getId())
            .map(existingApplicationSchedule -> {
                applicationScheduleMapper.partialUpdate(existingApplicationSchedule, applicationScheduleDTO);

                return existingApplicationSchedule;
            })
            .map(applicationScheduleRepository::save)
            .map(applicationScheduleMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ApplicationScheduleDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all ApplicationSchedules");
        return applicationScheduleRepository.findAll(pageable).map(applicationScheduleMapper::toDto);
    }

    /**
     *  Get all the applicationSchedules where Application is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<ApplicationScheduleDTO> findAllWhereApplicationIsNull() {
        LOG.debug("Request to get all applicationSchedules where Application is null");
        return StreamSupport
            .stream(applicationScheduleRepository.findAll().spliterator(), false)
            .filter(applicationSchedule -> applicationSchedule.getApplication() == null)
            .map(applicationScheduleMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ApplicationScheduleDTO> findOne(Long id) {
        LOG.debug("Request to get ApplicationSchedule : {}", id);
        return applicationScheduleRepository.findById(id).map(applicationScheduleMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete ApplicationSchedule : {}", id);
        applicationScheduleRepository.deleteById(id);
    }
}
