/**
 * Rest layer error handling.
 */
package com.mycompany.myapp.web.rest.errors;
