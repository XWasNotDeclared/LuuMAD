package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Contract;
import com.mycompany.myapp.domain.enumeration.ContractStatus;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Contract entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ContractRepository extends JpaRepository<Contract, Long> {
    @Query(
        """
                SELECT c FROM Contract c
                JOIN c.employer e ON e.id = c.employer.id
                WHERE c.employer.id = :employerId
        """
    )
    List<Contract> findContractByEmployerId(@Param("employerId") Long employerId);

    @Query(
        """
                SELECT c FROM Contract c
                JOIN c.jobSeeker e ON e.id = c.jobSeeker.id
                WHERE c.jobSeeker.id = :jobSeekerId
        """
    )
    List<Contract> findContractByJobSeekerId(@Param("jobSeekerId") Long employerId);

    @Query(
        """
                SELECT c FROM Contract c
                JOIN c.employer e ON e.id = c.employer.id
                WHERE c.employer.id = :employerId AND c.jobSeeker.id = :jobSeekerId
        """
    )
    Contract findContractByEmployerIdAndJobSeekerId(@Param("employerId") Long employerId, @Param("jobSeekerId") Long jobSeekerId);

    @Query(
        """
                SELECT c FROM Contract c
                WHERE  c.jobSeeker.id = :jobSeekerId AND c.status = 'PENDING'
        """
    )
    List<Contract> finContractByJobSeekerIdAndStatusPending(@Param("jobSeekerId") Long jobSeekerId);

    @Query(
        """
                SELECT c FROM Contract c
                WHERE  c.employer.id = :employerId AND c.status != 'PENDING'
        """
    )
    List<Contract> finContractByEmployerIdAndStatusNotPending(@Param("employerId") Long employerId);
}
