package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ApplicationSchedule;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the ApplicationSchedule entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ApplicationScheduleRepository extends JpaRepository<ApplicationSchedule, Long> {}
