package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.enumeration.UserRole;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.util.Date;
import java.util.Optional;
import javax.crypto.SecretKey;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class JwtService {

    @Value("${spring.jwt.access.secret}")
    private String jwtSecret;

    @Value("${spring.jwt.access.expire}")
    private Long jwtExpiration; // milliseconds

    @Value("${clerk.public-key}")
    private String clerkPublicKey;

    /**
     * Xác thực token Clerk và lấy email từ token
     * @param token JWT token từ frontend
     * @return Email nếu token hợp lệ, hoặc null nếu không hợp lệ
     */
    public String getEmailFromClerkToken(String token) {
        try {
            SecretKey clerkKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(clerkPublicKey));

            return Jwts.parser().verifyWith(clerkKey).build().parseSignedClaims(token).getPayload().getSubject();
        } catch (Exception e) {
            log.error("Error getting email from clerk token", e);
            return null;
        }
    }

    /**
     * Tạo JWT access token từ email, role
     */
    public String generateToken(Long id, String email, String role) {
        SecretKey secretKey = getSigningKey();
        Date now = new Date();
        Date expDate = new Date(now.getTime() + jwtExpiration);

        return Jwts
            .builder()
            .subject(email)
            .claim("id", id)
            .claim("role", role)
            .signWith(secretKey)
            .issuedAt(now)
            .expiration(expDate)
            .compact();
    }

    /**
     * Xác thực token và trả về thông tin nếu hợp lệ
     */
    public Optional<Jws<Claims>> validateToken(String token) {
        try {
            SecretKey secretKey = getSigningKey();
            Jws<Claims> jws = Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token);
            return Optional.of(jws);
        } catch (JwtException | IllegalArgumentException e) {
            log.error("Invalid JWT token", e);
            return Optional.empty();
        }
    }

    /**
     * Lấy id, email, role từ token
     */
    public Long getIdFromToken(String token) {
        try {
            return Jwts.parser().verifyWith(getSigningKey()).build().parseSignedClaims(token).getPayload().get("id", Long.class);
        } catch (Exception e) {
            log.error("Error getting id from token", e);
            return null;
        }
    }

    public String getEmailFromToken(String token) {
        try {
            return Jwts.parser().verifyWith(getSigningKey()).build().parseSignedClaims(token).getPayload().getSubject();
        } catch (Exception e) {
            log.error("Error getting email from token", e);
            return null;
        }
    }

    public UserRole getRoleFromToken(String token) {
        try {
            String roleStr = Jwts
                .parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .get("role", String.class);
            return UserRole.valueOf(roleStr);
        } catch (Exception e) {
            log.error("Error getting role from token", e);
            return null;
        }
    }

    private SecretKey getSigningKey() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
