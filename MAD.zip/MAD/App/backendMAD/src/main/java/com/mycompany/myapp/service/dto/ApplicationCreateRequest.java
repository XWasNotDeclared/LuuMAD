package com.mycompany.myapp.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.multipart.MultipartFile;

@Schema(description = "Thông tin tạo mới một đơn ứng tuyển")
public class ApplicationCreateRequest {

    @Schema(description = "Thư xin việc")
    private String coverLetter;

    @Schema(description = "Lịch làm việc (JSON string)")
    private String scheduleTable;

    @Schema(description = "ID của người tìm việc")
    private Long jobSeekerId;

    @Schema(description = "ID bài đăng tuyển")
    private Long postId;

    @Schema(description = "CV dạng file PDF hoặc Word", type = "string", format = "binary")
    private MultipartFile cvFile;

    // Getters & Setters

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public String getScheduleTable() {
        return scheduleTable;
    }

    public void setScheduleTable(String scheduleTable) {
        this.scheduleTable = scheduleTable;
    }

    public Long getJobSeekerId() {
        return jobSeekerId;
    }

    public void setJobSeekerId(Long jobSeekerId) {
        this.jobSeekerId = jobSeekerId;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public MultipartFile getCvFile() {
        return cvFile;
    }

    public void setCvFile(MultipartFile cvFile) {
        this.cvFile = cvFile;
    }
}
