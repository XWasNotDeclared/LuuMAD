package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Message;
import com.mycompany.myapp.service.dto.AppUserDTO;
import com.mycompany.myapp.service.dto.MessageDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Message} and its DTO {@link MessageDTO}.
 */
@Mapper(componentModel = "spring", uses = { MessageMapper.class })
public interface MessageMapper extends EntityMapper<MessageDTO, Message> {
    //    @Mapping(target = "sender", source = "sender", qualifiedByName = "appUserId")
    //    MessageDTO toDto(Message s);
    //
    //    @Named("appUserId")
    //    @BeanMapping(ignoreByDefault = true)
    //    AppUserDTO toDtoAppUserId(AppUser appUser);
}
