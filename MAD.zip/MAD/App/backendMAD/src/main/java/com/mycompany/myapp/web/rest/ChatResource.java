package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.service.ChatService;
import com.mycompany.myapp.service.dto.ChatMessageDTO;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/app/chats")
@RequiredArgsConstructor
public class ChatResource {

    private static final Logger LOG = LoggerFactory.getLogger(ChatResource.class);

    private final ChatService chatService;

    @GetMapping("/latestMessages/{receiverId}")
    public ResponseEntity<List<MessageReceiverDTO>> getLastMessagesWithEachUser(@PathVariable Long receiverId) {
        return ResponseEntity.ok(chatService.getLastMessagesWithEachUser(receiverId));
    }

    @GetMapping("/between")
    public ResponseEntity<List<ChatMessageDTO>> getMessagesBetweenUsers(@RequestParam Long myId, @RequestParam Long otherId) {
        List<ChatMessageDTO> messages = chatService.getMessagesBetweenUsers(myId, otherId);
        return ResponseEntity.ok(messages);
    }

    @PostMapping(value = "/send", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ChatMessageDTO> sendMessage(@ModelAttribute ChatMessageDTO chatMessageDTO) {
        return ResponseEntity.ok(chatService.sendMessage(chatMessageDTO));
    }

    @GetMapping("/has-new")
    public ResponseEntity<Boolean> hasUnreadMessages(@RequestParam Long receiverId) {
        boolean hasUnread = chatService.hasUnreadMessages(receiverId);
        return ResponseEntity.ok(hasUnread);
    }

    @GetMapping("/unread/{receiverId}")
    public ResponseEntity<List<ChatMessageDTO>> getUnreadMessages(@PathVariable Long receiverId) {
        return ResponseEntity.ok(chatService.getUnreadMessages(receiverId));
    }

    @GetMapping("/unnotified/{receiverId}")
    public ResponseEntity<List<ChatMessageDTO>> getUnnotifiedMessages(@PathVariable Long receiverId) {
        return ResponseEntity.ok(chatService.getUnnotifiedMessages(receiverId));
    }

    @PostMapping("/mark-read")
    public ResponseEntity<Void> markMessagesAsRead(@RequestParam Long myId, @RequestParam Long otherId) {
        chatService.markMessagesAsRead(myId, otherId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/mark-notified")
    public ResponseEntity<Void> markMessagesAsNotified(@RequestBody List<Long> messageIds) {
        chatService.markMessagesAsNotified(messageIds);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/meeting")
    public ResponseEntity<String> createMeeting(@RequestParam Long senderId, @RequestParam Long receiverId) {
        return ResponseEntity.ok(chatService.createMeeting(senderId, receiverId));
    }
}
