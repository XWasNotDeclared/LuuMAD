package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.repository.JobSeekerRepository;
import com.mycompany.myapp.service.JobSeekerService;
import com.mycompany.myapp.service.JwtService;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.JobSeekerFilterRequest;
import com.mycompany.myapp.service.dto.request.JobSeekerInfoRequest;
import com.mycompany.myapp.service.dto.response.SuggestionInfoResponse;
import com.mycompany.myapp.service.response.JobSeekerResponse;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.JobSeeker}.
 */
@RestController
@RequestMapping("/api/app/job-seekers")
@RequiredArgsConstructor
public class JobSeekerResource {

    private static final Logger LOG = LoggerFactory.getLogger(JobSeekerResource.class);

    private static final String ENTITY_NAME = "jobSeeker";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final JobSeekerService jobSeekerService;

    private final JobSeekerRepository jobSeekerRepository;
    private final JwtService jwtService;

    @GetMapping("/apply")
    @Operation(summary = "get all job seeker apply the post")
    public ResponseEntity<List<JobSeekerResponse>> findJobSeekerByPostId(@RequestParam("postId") Long postId) {
        return ResponseEntity.ok(jobSeekerService.findJobSeekerByPostId(postId));
    }

    @GetMapping("/detail")
    @Operation(summary = "get detail job seeker")
    public ResponseEntity<JobSeekerResponse> findJobSeekerById(@RequestParam("id") Long id) {
        return ResponseEntity.ok(jobSeekerService.findJobSeekerById(id));
    }

    @GetMapping("/employer/jobseeker")
    @Operation(summary = "get job seeker signed contract with employer")
    public ResponseEntity<List<JobSeekerResponse>> findJobSeekerByEmployerId(HttpServletRequest request) {
        String token = getJwtFromRequest(request);
        Long employerId = jwtService.getIdFromToken(token);
        return ResponseEntity.ok(jobSeekerService.findJobSeekerByEmployerId(employerId));
    }

    @GetMapping("/job-seeker-interact")
    @Operation(summary = "get all jobseeker interract with employer")
    public ResponseEntity<List<JobSeekerResponse>> findJobSeekerInteractWithEmployer(HttpServletRequest request) {
        String token = getJwtFromRequest(request);
        Long employerId = jwtService.getIdFromToken(token);
        return ResponseEntity.ok(jobSeekerService.findJobSeekerInteractWithEmploer(employerId));
    }

    private String getJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        // Kiểm tra xem header Authorization có chứa thông tin jwt không
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    @PatchMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<JobSeekerDTO> partialUpdateJobSeeker(
        @PathVariable("id") Long id,
        @ModelAttribute JobSeekerInfoRequest jobSeekerInfoRequest
    ) {
        JobSeekerDTO result = jobSeekerService.partialUpdateJobSeeker(id, jobSeekerInfoRequest);

        if (result == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok().body(result);
    }

    /**
     * {@code POST  /job-seekers} : Create a new jobSeeker.
     *
     * @param jobSeekerDTO the jobSeekerDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new jobSeekerDTO, or with status {@code 400 (Bad Request)} if the jobSeeker has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<JobSeekerDTO> createJobSeeker(@RequestBody JobSeekerDTO jobSeekerDTO) throws URISyntaxException {
        LOG.debug("REST request to save JobSeeker : {}", jobSeekerDTO);
        if (jobSeekerDTO.getId() != null) {
            throw new BadRequestAlertException("A new jobSeeker cannot already have an ID", ENTITY_NAME, "idexists");
        }
        jobSeekerDTO = jobSeekerService.save(jobSeekerDTO);
        return ResponseEntity
            .created(new URI("/api/job-seekers/" + jobSeekerDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, jobSeekerDTO.getId().toString()))
            .body(jobSeekerDTO);
    }

    /**
     * {@code PUT  /job-seekers/:id} : Updates an existing jobSeeker.
     *
     * @param id the id of the jobSeekerDTO to save.
     * @param jobSeekerDTO the jobSeekerDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated jobSeekerDTO,
     * or with status {@code 400 (Bad Request)} if the jobSeekerDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the jobSeekerDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<JobSeekerDTO> updateJobSeeker(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody JobSeekerDTO jobSeekerDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update JobSeeker : {}, {}", id, jobSeekerDTO);
        if (jobSeekerDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, jobSeekerDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!jobSeekerRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        jobSeekerDTO = jobSeekerService.update(jobSeekerDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, jobSeekerDTO.getId().toString()))
            .body(jobSeekerDTO);
    }

    /**
     * {@code PATCH  /job-seekers/:id} : Partial updates given fields of an existing jobSeeker, field will ignore if it is null
     *
     * @param id the id of the jobSeekerDTO to save.
     * @param jobSeekerDTO the jobSeekerDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated jobSeekerDTO,
     * or with status {@code 400 (Bad Request)} if the jobSeekerDTO is not valid,
     * or with status {@code 404 (Not Found)} if the jobSeekerDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the jobSeekerDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    //    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    //    public ResponseEntity<JobSeekerDTO> partialUpdateJobSeeker(
    //        @PathVariable(value = "id", required = false) final Long id,
    //        @RequestBody JobSeekerDTO jobSeekerDTO
    //    ) throws URISyntaxException {
    //        LOG.debug("REST request to partial update JobSeeker partially : {}, {}", id, jobSeekerDTO);
    //        if (jobSeekerDTO.getId() == null) {
    //            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
    //        }
    //        if (!Objects.equals(id, jobSeekerDTO.getId())) {
    //            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
    //        }
    //
    //        if (!jobSeekerRepository.existsById(id)) {
    //            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
    //        }
    //
    //        Optional<JobSeekerDTO> result = jobSeekerService.partialUpdate(jobSeekerDTO);
    //
    //        return ResponseUtil.wrapOrNotFound(
    //            result,
    //            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, jobSeekerDTO.getId().toString())
    //        );
    //    }

    /**
     * {@code GET  /job-seekers} : get all the jobSeekers.
     *
     * @param pageable the pagination information.
     * @param eagerload flag to eager load entities from relationships (This is applicable for many-to-many).
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of jobSeekers in body.
     */
    @GetMapping("")
    public ResponseEntity<List<JobSeekerDTO>> getAllJobSeekers(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable,
        @RequestParam(name = "eagerload", required = false, defaultValue = "true") boolean eagerload
    ) {
        LOG.debug("REST request to get a page of JobSeekers");
        Page<JobSeekerDTO> page;
        if (eagerload) {
            page = jobSeekerService.findAllWithEagerRelationships(pageable);
        } else {
            page = jobSeekerService.findAll(pageable);
        }
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /job-seekers/:id} : get the "id" jobSeeker.
     *
     * @param id the id of the jobSeekerDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the jobSeekerDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<JobSeekerDTO> getJobSeeker(@PathVariable("id") Long id) {
        LOG.debug("REST request to get JobSeeker : {}", id);
        Optional<JobSeekerDTO> jobSeekerDTO = jobSeekerService.findOne(id);
        return ResponseUtil.wrapOrNotFound(jobSeekerDTO);
    }

    /**
     * {@code DELETE  /job-seekers/:id} : delete the "id" jobSeeker.
     *
     * @param id the id of the jobSeekerDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJobSeeker(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete JobSeeker : {}", id);
        jobSeekerService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }

    @PostMapping("/filter")
    @Operation(summary = "Filter job seekers")
    public ResponseEntity<List<JobSeekerDTO>> filterJobSeekers(@RequestBody JobSeekerFilterRequest request) {
        List<JobSeekerDTO> result = jobSeekerService.filterJobSeekers(request);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/job-seekers/by-position/{positionId}")
    @Operation(summary = "Get job seekers by position ID")
    public ResponseEntity<List<JobSeekerDTO>> getByPosition(@PathVariable Long positionId) {
        List<JobSeekerDTO> jobSeekers = jobSeekerService.findByPositionId(positionId);
        return ResponseEntity.ok(jobSeekers);
    }

    @GetMapping("/{id}/positions")
    public Set<Position> getPositionsByJobSeekerId(@PathVariable Long id) {
        return jobSeekerService.findPositionsByJobSeekerId(id);
    }

    @GetMapping("/{id}/suggestInfor")
    public SuggestionInfoResponse getSuggestionInfoResponse(@PathVariable Long id) {
        return jobSeekerService.getSuggestionInfoResponse(id);
    }
}
