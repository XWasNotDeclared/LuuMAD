package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Review;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Review entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    @Query(
        """
                SELECT r FROM Review r
                where r.employer.id = :employerId and r.typeReview = 'JOB_SEEKER_REVIEW'

        """
    )
    List<Review> findByEmployerIdAndTypeReview_JobSeekerReview(@Param("employerId") Long employerId);

    @Query(
        """
                SELECT r FROM Review r
                where r.jobSeeker.id = :jobSeekerId and r.typeReview = 'EMPLOYER_REVIEW'

        """
    )
    List<Review> findByJobSeekerIdAndTypeReview_EmployerReview(@Param("jobSeekerId") Long jobSeekerId);
}
