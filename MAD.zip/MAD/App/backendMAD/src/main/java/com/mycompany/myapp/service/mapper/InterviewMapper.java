package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Application;
import com.mycompany.myapp.domain.Interview;
import com.mycompany.myapp.service.dto.ApplicationDTO;
import com.mycompany.myapp.service.dto.InterviewDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Interview} and its DTO {@link InterviewDTO}.
 */
@Mapper(componentModel = "spring")
public interface InterviewMapper extends EntityMapper<InterviewDTO, Interview> {
    @Mapping(target = "application", source = "application", qualifiedByName = "applicationId")
    InterviewDTO toDto(Interview s);

    @Named("applicationId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    ApplicationDTO toDtoApplicationId(Application application);
}
