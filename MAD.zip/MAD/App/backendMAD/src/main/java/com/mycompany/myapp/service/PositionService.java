package com.mycompany.myapp.service;

import com.mycompany.myapp.repository.PositionRepository;
import com.mycompany.myapp.service.dto.PositionDTO;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.mycompany.myapp.domain.Position}.
 */
public interface PositionService {
    List<PositionDTO> getPositionsByJobSeekerId(Long jobSeekerId);

    Page<PositionDTO> searchPositionsByName(String keyword, Pageable pageable);

    List<PositionDTO> getTop3PositionsWithMostJobSeekers();

    /**
     * Save a position.
     *
     * @param positionDTO the entity to save.
     * @return the persisted entity.
     */
    PositionDTO save(PositionDTO positionDTO);

    /**
     * Updates a position.
     *
     * @param positionDTO the entity to update.
     * @return the persisted entity.
     */
    PositionDTO update(PositionDTO positionDTO);

    /**
     * Partially updates a position.
     *
     * @param positionDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<PositionDTO> partialUpdate(PositionDTO positionDTO);

    /**
     * Get all the positions.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PositionDTO> findAll(Pageable pageable);

    /**
     * Get all the positions with eager load of many-to-many relationships.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PositionDTO> findAllWithEagerRelationships(Pageable pageable);

    /**
     * Get the "id" position.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<PositionDTO> findOne(Long id);

    /**
     * Delete the "id" position.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    List<PositionDTO> findTop3PopularPositions();
}
