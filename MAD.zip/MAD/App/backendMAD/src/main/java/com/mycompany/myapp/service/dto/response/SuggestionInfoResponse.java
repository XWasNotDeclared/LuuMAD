package com.mycompany.myapp.service.dto.response;

import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.domain.enumeration.JobType;
import com.mycompany.myapp.service.dto.PositionDTO;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SuggestionInfoResponse {

    private JobType jobType;
    private Integer expectedSalary;
    private Set<Position> position;
}
