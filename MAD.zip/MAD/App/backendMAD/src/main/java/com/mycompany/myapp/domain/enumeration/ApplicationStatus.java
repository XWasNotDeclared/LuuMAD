package com.mycompany.myapp.domain.enumeration;

/**
 * The ApplicationStatus enumeration.
 */
public enum ApplicationStatus {
    PENDING,
    UNDER_REVIEW,
    INTERVIEWING,
    ACCEPTED,
    REJECTED,
    WITHDRAWN,
}
