package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.NotificationReceiver;
import com.mycompany.myapp.domain.enumeration.NotificationCode;
import com.mycompany.myapp.service.dto.NotificationDTO;
import com.mycompany.myapp.service.dto.response.NotificationResponseByHung;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the NotificationReceiver entity.
 */
@SuppressWarnings("unused")
@Repository
public interface NotificationReceiverRepository extends JpaRepository<NotificationReceiver, Long> {
    @Query(
        """
            SELECT new com.mycompany.myapp.service.dto.response.NotificationResponseByHung(
                nr.id, n.title, n.content, n.notiCode, nr.isRead, n.createdAt
            )
            FROM NotificationReceiver nr
            JOIN nr.notification n
            WHERE nr.receiver.id = :receiverId AND n.notiCode = :code
            ORDER BY n.createdAt DESC
        """
    )
    List<NotificationResponseByHung> findAllNotiDTOByReceiverIdAndNotiCode(
        @Param("receiverId") Long receiverId,
        @Param("code") NotificationCode code
    );
}
