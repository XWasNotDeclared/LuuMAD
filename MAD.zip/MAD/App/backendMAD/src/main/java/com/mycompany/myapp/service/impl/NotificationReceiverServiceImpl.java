package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.NotificationReceiver;
import com.mycompany.myapp.repository.NotificationReceiverRepository;
import com.mycompany.myapp.service.NotificationReceiverService;
import com.mycompany.myapp.service.dto.NotificationReceiverDTO;
import com.mycompany.myapp.service.mapper.NotificationReceiverMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.NotificationReceiver}.
 */
@Service
@Transactional
public class NotificationReceiverServiceImpl implements NotificationReceiverService {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationReceiverServiceImpl.class);

    private final NotificationReceiverRepository notificationReceiverRepository;

    private final NotificationReceiverMapper notificationReceiverMapper;

    public NotificationReceiverServiceImpl(
        NotificationReceiverRepository notificationReceiverRepository,
        NotificationReceiverMapper notificationReceiverMapper
    ) {
        this.notificationReceiverRepository = notificationReceiverRepository;
        this.notificationReceiverMapper = notificationReceiverMapper;
    }

    @Override
    public NotificationReceiverDTO save(NotificationReceiverDTO notificationReceiverDTO) {
        LOG.debug("Request to save NotificationReceiver : {}", notificationReceiverDTO);
        NotificationReceiver notificationReceiver = notificationReceiverMapper.toEntity(notificationReceiverDTO);
        notificationReceiver = notificationReceiverRepository.save(notificationReceiver);
        return notificationReceiverMapper.toDto(notificationReceiver);
    }

    @Override
    public NotificationReceiverDTO update(NotificationReceiverDTO notificationReceiverDTO) {
        LOG.debug("Request to update NotificationReceiver : {}", notificationReceiverDTO);
        NotificationReceiver notificationReceiver = notificationReceiverMapper.toEntity(notificationReceiverDTO);
        notificationReceiver = notificationReceiverRepository.save(notificationReceiver);
        return notificationReceiverMapper.toDto(notificationReceiver);
    }

    @Override
    public Optional<NotificationReceiverDTO> partialUpdate(NotificationReceiverDTO notificationReceiverDTO) {
        LOG.debug("Request to partially update NotificationReceiver : {}", notificationReceiverDTO);

        return notificationReceiverRepository
            .findById(notificationReceiverDTO.getId())
            .map(existingNotificationReceiver -> {
                notificationReceiverMapper.partialUpdate(existingNotificationReceiver, notificationReceiverDTO);

                return existingNotificationReceiver;
            })
            .map(notificationReceiverRepository::save)
            .map(notificationReceiverMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NotificationReceiverDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all NotificationReceivers");
        return notificationReceiverRepository.findAll(pageable).map(notificationReceiverMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<NotificationReceiverDTO> findOne(Long id) {
        LOG.debug("Request to get NotificationReceiver : {}", id);
        return notificationReceiverRepository.findById(id).map(notificationReceiverMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete NotificationReceiver : {}", id);
        notificationReceiverRepository.deleteById(id);
    }
}
