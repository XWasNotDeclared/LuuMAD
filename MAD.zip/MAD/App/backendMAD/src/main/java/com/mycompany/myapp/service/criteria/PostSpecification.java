package com.mycompany.myapp.service.criteria;

import com.mycompany.myapp.domain.Category;
import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.domain.Post;
import com.mycompany.myapp.service.dto.PostFilterDTO;
import jakarta.persistence.criteria.Fetch;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.jpa.domain.Specification;

// src/main/java/com/yourcompany/app/service/criteria/PostSpecification.java

public class PostSpecification {

    public static Specification<Post> build(PostFilterDTO filter) {
        return (root, query, cb) -> {
            // Fetch liên kết
            Fetch<Post, Position> positionFetch = root.fetch("position", JoinType.LEFT);
            root.fetch("employer", JoinType.LEFT);
            if (query.getResultType() != Long.class) {
                query.distinct(true);
            }
            // Fetch employer và appUser
            Fetch<Post, Employer> employerFetch = root.fetch("employer", JoinType.LEFT);
            employerFetch.fetch("appUser", JoinType.LEFT); // << dòng này là quan trọng

            // Tham chiếu join để lọc
            Join<Post, Position> positionJoin = root.join("position", JoinType.LEFT);
            Join<Position, Category> categoryJoin = positionJoin.join("category", JoinType.LEFT);

            List<Predicate> predicates = new ArrayList<>();

            // JobType filter
            if (filter.getJobTypes() != null && !filter.getJobTypes().isEmpty()) {
                predicates.add(root.get("jobType").in(filter.getJobTypes()));
            }

            // Experience range
            if (filter.getExperienceStart() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("experienceYearsRequired"), filter.getExperienceStart()));
            }
            if (filter.getExperienceEnd() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("experienceYearsRequired"), filter.getExperienceEnd()));
            }

            // Work location
            if (filter.getLocation() != null) {
                predicates.add(cb.equal(root.get("location"), filter.getLocation()));
            }

            // Thành phố từ address
            if (filter.getCity() != null) {
                predicates.add(cb.like(cb.lower(root.get("address")), "%" + filter.getCity().toLowerCase() + "%"));
            }

            // Date range
            if (filter.getStartDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), filter.getStartDate()));
            }
            if (filter.getEndDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), filter.getEndDate()));
            }

            // Filter theo category ID (chính xác)
            if (filter.getCategoryId() != null) {
                predicates.add(cb.equal(categoryJoin.get("id"), filter.getCategoryId()));
            }

            // Filter theo position name (gần đúng, không phân biệt hoa thường)
            if (filter.getPositionName() != null && !filter.getPositionName().trim().isEmpty()) {
                predicates.add(cb.like(cb.lower(positionJoin.get("name")), "%" + filter.getPositionName().toLowerCase() + "%"));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
// public static Specification<Post> build(PostFilterDTO filter) {
//     return (root, query, cb) -> {
//         root.fetch("position", JoinType.LEFT);
//         root.fetch("employer", JoinType.LEFT);
//         // Tránh bị lỗi khi dùng fetch + count
//         if (query.getResultType() != Long.class) {
//             query.distinct(true); // tránh bị duplicate
//         }
//         List<Predicate> predicates = new ArrayList<>();
//         if (filter.getPositionName() != null) {
//             predicates.add(cb.equal(cb.lower(root.get("position").get("name")), filter.getPositionName().toLowerCase()));
//         }
//         if (filter.getAddress() != null) {
//             predicates.add(cb.equal(root.get("address"), filter.getAddress()));
//         }
//         if (filter.getJobType() != null) {
//             predicates.add(cb.equal(root.get("jobType"), filter.getJobType()));
//         }
//         if (filter.getPostStatus() != null) {
//             predicates.add(cb.equal(root.get("status"), filter.getPostStatus()));
//         }
//         if (filter.getExperienceYearsRequired() != null) {
//             predicates.add(cb.lessThanOrEqualTo(root.get("experienceYearsRequired"), filter.getExperienceYearsRequired()));
//         }
//         return cb.and(predicates.toArray(new Predicate[0]));
//     };
// }
