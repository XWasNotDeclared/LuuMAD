package com.mycompany.myapp.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class PositionDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private CategoryDTO category;

    //    private Set<Long> jobSeekers;
    private Set<JobSeekerDTO> jobSeekers = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CategoryDTO getCategory() {
        return category;
    }

    public void setCategory(CategoryDTO category) {
        this.category = category;
    }

    //    public Set<Long> getJobSeekers() {
    //        return jobSeekers;
    //    }
    //
    //    public void setJobSeekers(Set<Long> jobSeekers) {
    //        this.jobSeekers = jobSeekers;
    //    }

    public Set<JobSeekerDTO> getJobSeekers() {
        return jobSeekers;
    }

    public void setJobSeekers(Set<JobSeekerDTO> jobSeekers) {
        this.jobSeekers = jobSeekers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PositionDTO)) {
            return false;
        }

        PositionDTO positionDTO = (PositionDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, positionDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    @Override
    public String toString() {
        return (
            "PositionDTO{" +
            "id=" +
            getId() +
            ", name='" +
            getName() +
            "'" +
            ", category=" +
            getCategory() +
            ", jobSeekers=" +
            getJobSeekers() +
            "}"
        );
    }
}
