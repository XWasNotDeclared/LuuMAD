package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Post;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Post entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PostRepository extends JpaRepository<Post, Long>, JpaSpecificationExecutor<Post> {
    @Query("SELECT  p FROM Post p WHERE p.employer.id =:employerId ")
    List<Post> findPostsByEmployerId(@Param("employerId") Long employerId);

    @Query("SELECT p.id FROM Post p WHERE p.employer.id = :employerId")
    List<Long> findAllPostIdsByEmployerId(@Param("employerId") Long employerId);
}
