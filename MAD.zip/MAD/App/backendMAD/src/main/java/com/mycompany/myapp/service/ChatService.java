package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.MessageReceiver;
import com.mycompany.myapp.service.dto.ChatMessageDTO;
import com.mycompany.myapp.service.dto.MessageDTO;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface ChatService {
    List<MessageReceiverDTO> getLastMessagesWithEachUser(Long receiverId);

    List<ChatMessageDTO> getMessagesBetweenUsers(Long myId, Long otherId);

    ChatMessageDTO sendMessage(ChatMessageDTO chatMessageDTO);

    boolean hasUnreadMessages(Long receiverId);

    List<ChatMessageDTO> getUnreadMessages(Long receiverId);

    List<ChatMessageDTO> getUnnotifiedMessages(Long receiverId);

    void markMessagesAsRead(Long myId, Long otherId);

    void markMessagesAsNotified(List<Long> messageIds);

    String createMeeting(Long senderId, Long receiverId);
}
