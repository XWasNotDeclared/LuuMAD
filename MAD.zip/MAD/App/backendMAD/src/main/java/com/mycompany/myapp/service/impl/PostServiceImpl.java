package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.Notification;
import com.mycompany.myapp.domain.Position;
import com.mycompany.myapp.domain.Post;
import com.mycompany.myapp.domain.enumeration.NotificationCode;
import com.mycompany.myapp.repository.AppUserRepository;
import com.mycompany.myapp.repository.EmployerRepository;
import com.mycompany.myapp.repository.PositionRepository;
import com.mycompany.myapp.repository.PostRepository;
import com.mycompany.myapp.service.EmployerService;
import com.mycompany.myapp.service.NotificationService;
import com.mycompany.myapp.service.PostService;
import com.mycompany.myapp.service.criteria.PostSpecification;
import com.mycompany.myapp.service.dto.PostDTO;
import com.mycompany.myapp.service.dto.PostFilterDTO;
import com.mycompany.myapp.service.mapper.PostMapper;
import com.mycompany.myapp.service.response.CompanyDetailResponse;
import com.mycompany.myapp.service.response.JobItemDTO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Post}.
 */
@Service
@Transactional
public class PostServiceImpl implements PostService {

    private static final Logger LOG = LoggerFactory.getLogger(PostServiceImpl.class);

    private final PostRepository postRepository;

    private final PostMapper postMapper;

    private final EmployerService employerService;

    private final AppUserRepository appUserRepository;

    private final NotificationService notificationService;
    private final EmployerRepository employerRepository;
    private final PositionRepository positionRepository;

    public PostServiceImpl(
        PostRepository postRepository,
        PostMapper postMapper,
        EmployerService employerService,
        AppUserRepository appUserRepository,
        NotificationService notificationService,
        EmployerRepository employerRepository,
        PositionRepository positionRepository
    ) {
        this.postRepository = postRepository;
        this.postMapper = postMapper;
        this.employerService = employerService;
        this.appUserRepository = appUserRepository;
        this.notificationService = notificationService;
        this.employerRepository = employerRepository;
        this.positionRepository = positionRepository;
    }

    @Override
    public List<JobItemDTO> findPostsByEmployerId(Long employerId) {
        List<Post> posts = postRepository.findPostsByEmployerId(employerId);
        List<JobItemDTO> result = new ArrayList<>();
        for (Post post : posts) {
            JobItemDTO jobItemDTO = new JobItemDTO();

            jobItemDTO.setId(post.getId());
            jobItemDTO.setCompany(post.getEmployer().getCompanyName());
            jobItemDTO.setLocation(post.getLocation());
            jobItemDTO.setSalary(post.getSalaryRange());
            jobItemDTO.setUrl(post.getEmployer().getCompanyWebsite());
            jobItemDTO.setTitle(post.getPosition().getName());

            result.add(jobItemDTO);
        }
        return result;
    }

    @Override
    public PostDTO save(PostDTO postDTO) {
        LOG.debug("Request to save Post : {}", postDTO);
        boolean isCreate = postDTO.getId() == null;

        Post post = postMapper.toEntity(postDTO);
        post = postRepository.save(post);
        if (isCreate) {
            triggerPostCreatedNotification(post);
        }

        return postMapper.toDto(post);
    }

    @Override
    public PostDTO update(PostDTO postDTO) {
        LOG.debug("Request to update Post : {}", postDTO);
        Post post = postMapper.toEntity(postDTO);
        post = postRepository.save(post);
        return postMapper.toDto(post);
    }

    @Override
    public Optional<PostDTO> partialUpdate(PostDTO postDTO) {
        LOG.debug("Request to partially update Post : {}", postDTO);

        return postRepository
            .findById(postDTO.getId())
            .map(existingPost -> {
                postMapper.partialUpdate(existingPost, postDTO);

                return existingPost;
            })
            .map(postRepository::save)
            .map(postMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PostDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Posts");
        return postRepository.findAll(pageable).map(postMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PostDTO> findOne(Long id) {
        LOG.debug("Request to get Post : {}", id);
        return postRepository.findById(id).map(postMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Post : {}", id);
        postRepository.deleteById(id);
    }

    // @Override
    // @Transactional(readOnly = true)
    // public List<PostDTO> findAllByFilter(PostFilterDTO filter) {
    // return
    // postRepository.findAll(PostSpecification.build(filter)).stream().map(postMapper::toDto).collect(Collectors.toList());
    // }
    @Override
    @Transactional(readOnly = true)
    public List<PostDTO> findAllByFilter(PostFilterDTO filter) {
        List<PostDTO> posts = postRepository
            .findAll(PostSpecification.build(filter))
            .stream()
            .map(postMapper::toDto)
            .collect(Collectors.toList());

        boolean shouldFilterSalary =
            filter.getSalaryMin() != null && filter.getSalaryMin() >= 0 && filter.getSalaryMax() != null && filter.getSalaryMax() >= 0;

        if (shouldFilterSalary) {
            posts =
                posts
                    .stream()
                    .filter(post -> {
                        if (post.getSalaryRange() == null || post.getSalaryRange().isBlank()) return true;
                        return salaryOverlaps(
                            post.getSalaryRange(),
                            filter.getSalaryMin(),
                            filter.getSalaryMax(),
                            filter.getSalaryCurrency()
                        );
                    })
                    .collect(Collectors.toList());
        }

        return posts;
    }

    // private boolean salaryOverlaps(String salaryRange, long filterMin, long filterMax) {
    //     try {
    //         // VD salaryRange = "15000000 - 25000000 VNĐ"
    //         String[] parts = salaryRange.split("-");
    //         if (parts.length < 2)
    //             return true; // Không rõ range => giữ lại

    //         long postMin = Long.parseLong(parts[0].trim().replaceAll("[^\\d]", ""));
    //         long postMax = Long.parseLong(parts[1].trim().replaceAll("[^\\d]", ""));

    //         // Giao nhau khi: postMax >= filterMin AND postMin <= filterMax
    //         return postMax >= filterMin && postMin <= filterMax;
    //     } catch (Exception e) {
    //         // Nếu parse lỗi => giữ lại bài post
    //         return true;
    //     }
    // }
    private boolean salaryOverlaps(String salaryRange, long filterMin, long filterMax, String filterCurrency) {
        try {
            // VD salaryRange = "15000000 - 25000000 VNĐ"
            String[] parts = salaryRange.split("-");
            if (parts.length < 2) return true; // Không rõ range => giữ lại

            String leftPart = parts[0].trim();
            String rightPart = parts[1].trim();

            // Parse số
            long postMin = Long.parseLong(leftPart.replaceAll("[^\\d]", ""));
            long postMax = Long.parseLong(rightPart.replaceAll("[^\\d]", ""));

            // Parse đơn vị tiền tệ từ phần cuối
            String currency = rightPart.replaceAll("[^A-Za-z]", "").toUpperCase();
            System.out.println(
                "CURRENCYYYYYYYYYyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyYYYYYYYYYYYYYY\n\n\n\n\n\n\n" +
                filterCurrency
            );
            // Nếu không có đơn vị tiền hoặc không khớp với filter => loại
            // if (currency.isEmpty() || filterCurrency == null || !currency.equalsIgnoreCase(filterCurrency)) {
            //     return false;
            // }
            // Nếu đang lọc theo lương (filterMin/max khác 0), thì cần kiểm tra currency
            boolean isFiltering = filterMin != 0 || filterMax != 0;
            if (isFiltering) {
                if (currency.isEmpty() || filterCurrency == null || !currency.equalsIgnoreCase(filterCurrency)) {
                    return false;
                }
            }

            // Kiểm tra giao nhau
            return postMax >= filterMin && postMin <= filterMax;
        } catch (Exception e) {
            // Nếu lỗi parse, giữ lại bài đăng (an toàn)
            return true;
        }
    }

    private void triggerPostCreatedNotification(Post post) {
        // 🟢 Hardcode sender (system)
        AppUser sender = appUserRepository.findById(1L).orElse(null); // ID = 1 => system user
        if (sender == null) {
            LOG.warn("Sender (system) not found, skipping notification");
            return;
        }
        Employer e = employerRepository.findById(post.getEmployer().getId()).get();

        Position p = positionRepository.findById(post.getPosition().getId()).get();
        // 🟢 Hardcode receivers (ví dụ user id = 2,3,4)
        // có post rồi, có position post rồi -> tìm trong job_seeker những ai có position này
        // List<Long> receiverIds = List.of(7L, 8L);
        // List<AppUser> receivers = appUserRepository.findAllById(receiverIds);
        List<AppUser> receivers = appUserRepository.findAppUsersByPositionId(p.getId());
        System.out.println("FLAGGGGGGG--------------: " + receivers);

        if (receivers.isEmpty()) {
            LOG.warn("No receivers found, skipping notification");
            return;
        }

        // 🟢 Metadata
        Map<String, String> meta = new HashMap<>();
        meta.put("id", String.valueOf(post.getId()));
        meta.put("url", "app://job/" + post.getId());

        // 🟢 Gửi notify
        notificationService.notifyUser(
            sender,
            receivers,
            "Việc làm mới phù hợp với bạn",
            "Công ty: " +
            e.getCompanyName() +
            "\nvừa đăng công việc: " +
            p.getName() +
            " \nChúng tôi nghĩ công việc này phù hợp với hồ sơ của bạn. \nXem ngay!",
            NotificationCode.POST,
            "job",
            meta
        );
    }
}
