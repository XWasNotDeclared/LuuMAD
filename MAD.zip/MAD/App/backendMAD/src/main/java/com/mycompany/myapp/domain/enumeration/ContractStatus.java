package com.mycompany.myapp.domain.enumeration;

/**
 * The ContractStatus enumeration.
 */
public enum ContractStatus {
    ACTIVE,
    COMPLETE,
    PENDING,
}
