package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.Interview;
import com.mycompany.myapp.repository.InterviewRepository;
import com.mycompany.myapp.service.InterviewService;
import com.mycompany.myapp.service.dto.InterviewDTO;
import com.mycompany.myapp.service.mapper.InterviewMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.Interview}.
 */
@Service
@Transactional
public class InterviewServiceImpl implements InterviewService {

    private static final Logger LOG = LoggerFactory.getLogger(InterviewServiceImpl.class);

    private final InterviewRepository interviewRepository;

    private final InterviewMapper interviewMapper;

    public InterviewServiceImpl(InterviewRepository interviewRepository, InterviewMapper interviewMapper) {
        this.interviewRepository = interviewRepository;
        this.interviewMapper = interviewMapper;
    }

    @Override
    public InterviewDTO save(InterviewDTO interviewDTO) {
        LOG.debug("Request to save Interview : {}", interviewDTO);
        Interview interview = interviewMapper.toEntity(interviewDTO);
        interview = interviewRepository.save(interview);
        return interviewMapper.toDto(interview);
    }

    @Override
    public InterviewDTO update(InterviewDTO interviewDTO) {
        LOG.debug("Request to update Interview : {}", interviewDTO);
        Interview interview = interviewMapper.toEntity(interviewDTO);
        interview = interviewRepository.save(interview);
        return interviewMapper.toDto(interview);
    }

    @Override
    public Optional<InterviewDTO> partialUpdate(InterviewDTO interviewDTO) {
        LOG.debug("Request to partially update Interview : {}", interviewDTO);

        return interviewRepository
            .findById(interviewDTO.getId())
            .map(existingInterview -> {
                interviewMapper.partialUpdate(existingInterview, interviewDTO);

                return existingInterview;
            })
            .map(interviewRepository::save)
            .map(interviewMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<InterviewDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Interviews");
        return interviewRepository.findAll(pageable).map(interviewMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<InterviewDTO> findOne(Long id) {
        LOG.debug("Request to get Interview : {}", id);
        return interviewRepository.findById(id).map(interviewMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Interview : {}", id);
        interviewRepository.deleteById(id);
    }
}
