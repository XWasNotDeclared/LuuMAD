package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.service.AuthService;
import com.mycompany.myapp.service.dto.request.LoginRequest;
import com.mycompany.myapp.service.dto.request.SignupRequest;
import com.mycompany.myapp.service.dto.response.AuthResponse;
import com.mycompany.myapp.service.dto.response.ResponseDTO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/app/auth")
@RequiredArgsConstructor
public class AuthResource {

    private final AuthService authService;

    //    @GetMapping("/google/callback")
    //    public ResponseEntity<ResponseDTO<Object>> authenticateWithGoogle(@RequestBody Map<String, String> body) {
    //        String code = body.get("code");
    //        return authService.handleOAuthCallback(code);
    //    }

    @PostMapping("/google")
    public ResponseEntity<ResponseDTO<Object>> loginWithGoogle(@Valid @RequestParam String sessionId) {
        return authService.loginWithGoogle(sessionId);
    }

    @PostMapping("/login")
    public ResponseEntity<ResponseDTO<AuthResponse>> login(@Valid @RequestBody LoginRequest loginRequest) {
        return authService.login(loginRequest);
    }

    @PostMapping("/signup")
    public ResponseEntity<ResponseDTO<AuthResponse>> signup(@Valid @RequestBody SignupRequest signupRequest) {
        return authService.signup(signupRequest);
    }
}
