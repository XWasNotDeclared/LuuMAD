package com.mycompany.myapp.domain.enumeration;

/**
 * The UserRole enumeration.
 */
public enum UserRole {
    JOB_SEEKER,
    EMPLOYER,
}
