package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.MessageReceiver;
import com.mycompany.myapp.repository.MessageReceiverRepository;
import com.mycompany.myapp.service.MessageReceiverService;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import com.mycompany.myapp.service.mapper.MessageReceiverMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.mycompany.myapp.domain.MessageReceiver}.
 */
@Service
@Transactional
public class MessageReceiverServiceImpl implements MessageReceiverService {

    private final Logger log = LoggerFactory.getLogger(MessageReceiverServiceImpl.class);

    private final MessageReceiverRepository messageReceiverRepository;

    private final MessageReceiverMapper messageReceiverMapper;

    public MessageReceiverServiceImpl(MessageReceiverRepository messageReceiverRepository, MessageReceiverMapper messageReceiverMapper) {
        this.messageReceiverRepository = messageReceiverRepository;
        this.messageReceiverMapper = messageReceiverMapper;
    }

    @Override
    public MessageReceiverDTO save(MessageReceiverDTO messageReceiverDTO) {
        log.debug("Request to save MessageReceiver : {}", messageReceiverDTO);
        MessageReceiver messageReceiver = messageReceiverMapper.toEntity(messageReceiverDTO);
        messageReceiver = messageReceiverRepository.save(messageReceiver);
        return messageReceiverMapper.toDto(messageReceiver);
    }

    @Override
    public MessageReceiverDTO update(MessageReceiverDTO messageReceiverDTO) {
        log.debug("Request to update MessageReceiver : {}", messageReceiverDTO);
        MessageReceiver messageReceiver = messageReceiverMapper.toEntity(messageReceiverDTO);
        messageReceiver = messageReceiverRepository.save(messageReceiver);
        return messageReceiverMapper.toDto(messageReceiver);
    }

    @Override
    public Optional<MessageReceiverDTO> partialUpdate(MessageReceiverDTO messageReceiverDTO) {
        log.debug("Request to partially update MessageReceiver : {}", messageReceiverDTO);

        return messageReceiverRepository
            .findById(messageReceiverDTO.getId())
            .map(existingMessageReceiver -> {
                messageReceiverMapper.partialUpdate(existingMessageReceiver, messageReceiverDTO);

                return existingMessageReceiver;
            })
            .map(messageReceiverRepository::save)
            .map(messageReceiverMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<MessageReceiverDTO> findAll(Pageable pageable) {
        log.debug("Request to get all MessageReceivers");
        return messageReceiverRepository.findAll(pageable).map(messageReceiverMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<MessageReceiverDTO> findOne(Long id) {
        log.debug("Request to get MessageReceiver : {}", id);
        return messageReceiverRepository.findById(id).map(messageReceiverMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete MessageReceiver : {}", id);
        messageReceiverRepository.deleteById(id);
    }
}
