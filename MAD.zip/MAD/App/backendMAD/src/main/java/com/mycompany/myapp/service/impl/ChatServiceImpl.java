package com.mycompany.myapp.service.impl;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.Message;
import com.mycompany.myapp.domain.MessageReceiver;
import com.mycompany.myapp.domain.enumeration.MessageType;
import com.mycompany.myapp.repository.AppUserRepository;
import com.mycompany.myapp.repository.MessageReceiverRepository;
import com.mycompany.myapp.repository.MessageRepository;
import com.mycompany.myapp.service.ChatService;
import com.mycompany.myapp.service.GoogleDriveService;
import com.mycompany.myapp.service.dto.ChatMessageDTO;
import com.mycompany.myapp.service.dto.MessageReceiverDTO;
import com.mycompany.myapp.service.mapper.MessageReceiverMapper;
import jakarta.persistence.EntityNotFoundException;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ChatServiceImpl implements ChatService {

    private final MessageReceiverRepository messageReceiverRepository;
    private final MessageReceiverMapper messageReceiverMapper;
    private final GoogleDriveService googleDriveService;
    private final AppUserRepository appUserRepository;
    private final MessageRepository messageRepository;

    @Override
    public List<MessageReceiverDTO> getLastMessagesWithEachUser(Long receiverId) {
        // Lấy tin nhắn mới nhất từ mỗi người gửi
        List<MessageReceiver> allMessages = messageReceiverRepository.findLastMessagesWithEachUser(receiverId);
        return messageReceiverMapper.toDto(allMessages);
    }

    @Override
    @Transactional
    public List<ChatMessageDTO> getMessagesBetweenUsers(Long myId, Long otherId) {
        List<MessageReceiver> messageReceivers = messageReceiverRepository.findChatMessagesBetweenUsers(myId, otherId);
        return messageReceivers
            .stream()
            .map(mr -> {
                return new ChatMessageDTO(
                    mr.getMessage().getId(),
                    mr.getMessage().getContent(),
                    mr.getMessage().getSentAt(),
                    mr.getMessage().getMessageType(),
                    mr.getMessage().getSender().getId(),
                    mr.getReceiver().getId(),
                    mr.getIsRead(),
                    null
                );
            })
            .collect(Collectors.toList());
    }

    @Override
    public ChatMessageDTO sendMessage(ChatMessageDTO chatMessageDTO) {
        try {
            Message message = new Message();
            MessageReceiver messageReceiver = new MessageReceiver();
            AppUser sender = appUserRepository
                .findById(chatMessageDTO.getSenderId())
                .orElseThrow(() -> new EntityNotFoundException("Người gửi không tồn tại với ID: " + chatMessageDTO.getSenderId()));
            AppUser receiver = appUserRepository
                .findById(chatMessageDTO.getReceiverId())
                .orElseThrow(() -> new EntityNotFoundException("Người nhận không tồn tại với ID: " + chatMessageDTO.getReceiverId()));

            message.setSender(sender);
            message.setMessageType(chatMessageDTO.getMessageType());

            messageReceiver.setReceiver(receiver);
            messageReceiver.setIsRead(false);

            if (chatMessageDTO.getSentAt() == null) {
                chatMessageDTO.setSentAt(Instant.now());
            }

            if (chatMessageDTO.getFile() != null && !chatMessageDTO.getFile().isEmpty()) {
                String fileUrl = googleDriveService.uploadFile(chatMessageDTO.getFile());
                message.setContent(chatMessageDTO.getFile().getOriginalFilename() + "||" + fileUrl);
                chatMessageDTO.setContent(chatMessageDTO.getFile().getOriginalFilename() + "||" + fileUrl);
                chatMessageDTO.setFile(null);
            } else {
                message.setContent(chatMessageDTO.getContent());
            }

            message.setSentAt(chatMessageDTO.getSentAt());
            messageReceiver.setMessage(message);

            messageRepository.save(message);
            messageReceiverRepository.save(messageReceiver);

            chatMessageDTO.setId(message.getId());
            System.out.println(chatMessageDTO);

            return chatMessageDTO;
        } catch (IOException e) {
            throw new RuntimeException("Error uploading file to Google Drive", e);
        }
    }

    @Override
    public boolean hasUnreadMessages(Long receiverId) {
        return messageReceiverRepository.existsByReceiverIdAndIsReadFalse(receiverId);
    }

    @Override
    @Transactional
    public List<ChatMessageDTO> getUnreadMessages(Long receiverId) {
        List<MessageReceiver> messageReceivers = messageReceiverRepository.findUnreadMessagesByReceiverId(receiverId);
        return messageReceivers
            .stream()
            .map(mr -> {
                return new ChatMessageDTO(
                    mr.getMessage().getId(),
                    mr.getMessage().getContent(),
                    mr.getMessage().getSentAt(),
                    mr.getMessage().getMessageType(),
                    mr.getMessage().getSender().getId(),
                    mr.getReceiver().getId(),
                    mr.getIsRead(),
                    null
                );
            })
            .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public List<ChatMessageDTO> getUnnotifiedMessages(Long receiverId) {
        List<MessageReceiver> messageReceivers = messageReceiverRepository.findUnnotifiedMessagesByReceiverId(receiverId);
        return messageReceivers
            .stream()
            .map(mr ->
                new ChatMessageDTO(
                    mr.getMessage().getId(),
                    mr.getMessage().getContent(),
                    mr.getMessage().getSentAt(),
                    mr.getMessage().getMessageType(),
                    mr.getMessage().getSender().getId(),
                    mr.getReceiver().getId(),
                    mr.getIsRead(),
                    null
                )
            )
            .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void markMessagesAsRead(Long myId, Long otherId) {
        List<MessageReceiver> unread = messageReceiverRepository.findUnreadFromSenderToReceiver(otherId, myId);
        unread.forEach(mr -> mr.setIsRead(true));
        messageReceiverRepository.saveAll(unread);
    }

    @Override
    public void markMessagesAsNotified(List<Long> messageIds) {
        List<MessageReceiver> receivers = messageReceiverRepository.findByMessageIdIn(messageIds);
        for (MessageReceiver receiver : receivers) {
            receiver.setIsNotified(true);
        }
        messageReceiverRepository.saveAll(receivers);
    }

    @Override
    @Transactional
    public String createMeeting(Long senderId, Long receiverId) {
        AppUser sender = appUserRepository
            .findById(senderId)
            .orElseThrow(() -> new EntityNotFoundException("Người gửi không tồn tại với ID: " + senderId));
        AppUser receiver = appUserRepository
            .findById(receiverId)
            .orElseThrow(() -> new EntityNotFoundException("Người nhận không tồn tại với ID: " + receiverId));

        Message message = new Message();
        message.setSender(sender);
        message.setContent("Cuộc gọi video");
        message.setMessageType(MessageType.VIDEO_CALL);
        message.setSentAt(Instant.now());

        MessageReceiver messageReceiver = new MessageReceiver();
        messageReceiver.setMessage(message);
        messageReceiver.setIsRead(false);
        messageReceiver.setIsNotified(false);
        messageReceiver.setReceiver(receiver);

        messageRepository.save(message);
        messageReceiverRepository.save(messageReceiver);

        String meetingUrl = "https://meet.jit.si/room-";
        if (senderId < receiverId) {
            meetingUrl += senderId + "-" + receiverId;
        } else {
            meetingUrl += receiverId + "-" + senderId;
        }

        return meetingUrl;
    }
}
