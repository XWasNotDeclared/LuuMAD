package com.mycompany.myapp.service.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ContractResponse {

    private Long id;
    private String title;
    private String company;
    private String tags;
    private String time;
    private String budget;
    private String icon;
    private String link;

    public ContractResponse(Long id, String title, String company, String tags, String time, String budget, String icon) {
        this.id = id;
        this.title = title;
        this.company = company;
        this.tags = tags;
        this.time = time;
        this.budget = budget;
        this.icon = icon;
    }
}
