package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Experience;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.service.dto.ExperienceDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Experience} and its DTO {@link ExperienceDTO}.
 */
@Mapper(componentModel = "spring")
public interface ExperienceMapper extends EntityMapper<ExperienceDTO, Experience> {
    //    @Mapping(target = "jobSeeker", source = "jobSeeker", qualifiedByName = "jobSeekerId")
    //    ExperienceDTO toDto(Experience s);
    //
    //    @Named("jobSeekerId")
    //    @BeanMapping(ignoreByDefault = true)
    //    @Mapping(target = "id", source = "id")
    //    JobSeekerDTO toDtoJobSeekerId(JobSeeker jobSeeker);
}
