package com.mycompany.myapp.config.security;

import com.mycompany.myapp.domain.AppUser;
import com.mycompany.myapp.domain.enumeration.UserRole;
import java.util.Collection;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@RequiredArgsConstructor
public class AppUserDetailsImpl implements UserDetails {

    private final AppUser appUser;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(appUser.getRole().name()));
    }

    @Override
    public String getPassword() {
        return appUser.getPassword();
    }

    @Override
    public String getUsername() {
        return appUser.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // tuỳ chỉnh thêm nếu cần
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // tuỳ chỉnh thêm nếu cần
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // tuỳ chỉnh thêm nếu cần
    }

    @Override
    public boolean isEnabled() {
        return true; // tuỳ chỉnh thêm nếu cần
    }

    public UserRole getRole() {
        return appUser.getRole();
    }

    public Long getId() {
        return appUser.getId();
    }
}
