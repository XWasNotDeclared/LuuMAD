package com.mycompany.myapp.service.mapper;

import com.mycompany.myapp.domain.Employer;
import com.mycompany.myapp.domain.JobSeeker;
import com.mycompany.myapp.domain.Review;
import com.mycompany.myapp.service.dto.EmployerDTO;
import com.mycompany.myapp.service.dto.JobSeekerDTO;
import com.mycompany.myapp.service.dto.ReviewDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Review} and its DTO {@link ReviewDTO}.
 */
@Mapper(componentModel = "spring")
public interface ReviewMapper extends EntityMapper<ReviewDTO, Review> {
    @Mapping(target = "jobSeeker", source = "jobSeeker", qualifiedByName = "jobSeekerId")
    @Mapping(target = "employer", source = "employer", qualifiedByName = "employerId")
    ReviewDTO toDto(Review s);

    @Named("jobSeekerId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    JobSeekerDTO toDtoJobSeekerId(JobSeeker jobSeeker);

    @Named("employerId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    EmployerDTO toDtoEmployerId(Employer employer);
}
