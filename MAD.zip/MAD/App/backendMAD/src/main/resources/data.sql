INSERT INTO app_user (address, avatar_url, created_at, email, full_name, password, phone, role, status, updated_at) VALUES
-- Nhà tuyển dụng
('123 Đường Nguyễn Huệ, Quận 1, TP.HCM', 'https://example.com/avatar/emp1.jpg', '2025-05-01 10:00:00', 'hr1@viettech.vn', 'Công ty VietTech', 'password123', '0901234567', 'EMPLOYER', 1, '2025-05-01 10:00:00'),
('456 Đường Lê Lợi, Quận 3, TP.HCM', 'https://example.com/avatar/emp2.jpg', '2025-05-02 09:00:00', 'recruit@finbank.vn', 'Ngân hàng FinBank', 'password123', '0912345678', 'EMPLOYER', 1, '2025-05-02 09:00:00'),
-- Người tìm việc
('789 Đường Phạm Văn Đồng, Thủ Đức, TP.HCM', 'https://example.com/avatar/js1.jpg', '2025-05-03 08:00:00', 'nguyen.van.a@gmail.com', 'Nguyễn Văn An', 'password123', '0933456789', 'JOB_SEEKER', 1, '2025-05-03 08:00:00'),
('101 Đường Trần Hưng Đạo, Quận 5, TP.HCM', 'https://example.com/avatar/js2.jpg', '2025-05-03 09:00:00', 'tran.thi.b@gmail.com', 'Trần Thị Bình', 'password123', '0944567890', 'JOB_SEEKER', 1, '2025-05-03 09:00:00'),
('202 Đường Võ Văn Tần, Quận 3, TP.HCM', 'https://example.com/avatar/js3.jpg', '2025-05-04 10:00:00', 'le.van.c@gmail.com', 'Lê Văn Cường', 'password123', '0955678901', 'JOB_SEEKER', 1, '2025-05-04 10:00:00'),
('303 Đường Nguyễn Thị Minh Khai, Quận 1, TP.HCM', 'https://example.com/avatar/js4.jpg', '2025-05-04 11:00:00', 'pham.thi.d@gmail.com', 'Phạm Thị Dung', 'password123', '0966789012', 'JOB_SEEKER', 1, '2025-05-04 11:00:00'),
('404 Đường Cách Mạng Tháng Tám, Quận 10, TP.HCM', 'https://example.com/avatar/js5.jpg', '2025-05-05 12:00:00', 'hoang.van.e@gmail.com', 'Hoàng Văn Em', 'password123', '0977890123', 'JOB_SEEKER', 1, '2025-05-05 12:00:00'),
('505 Đường Lý Thường Kiệt, Quận Tân Bình, TP.HCM', 'https://example.com/avatar/js6.jpg', '2025-05-05 13:00:00', 'vu.thi.f@gmail.com', 'Vũ Thị Phượng', 'password123', '0988901234', 'JOB_SEEKER', 1, '2025-05-05 13:00:00'),
('606 Đường Điện Biên Phủ, Quận Bình Thạnh, TP.HCM', 'https://example.com/avatar/js7.jpg', '2025-05-06 14:00:00', 'dang.van.g@gmail.com', 'Đặng Văn Giang', 'password123', '0999012345', 'JOB_SEEKER', 1, '2025-05-06 14:00:00'),
('707 Đường Trường Chinh, Quận Tân Phú, TP.HCM', 'https://example.com/avatar/js8.jpg', '2025-05-06 15:00:00', 'bui.thi.h@gmail.com', 'Bùi Thị Hạnh', 'password123', '0910123456', 'JOB_SEEKER', 1, '2025-05-06 15:00:00');

INSERT INTO employer (business_type, company_code, company_description, company_name, company_website, specialization, workforce_size, year_established, app_user_id) VALUES
                                                                                                                                                                          ('Công nghệ thông tin', 'VT001', 'Công ty phát triển phần mềm hàng đầu tại Việt Nam', 'Công ty VietTech', 'https://viettech.vn', 'Phát triển phần mềm', 200, 2010, 1),
                                                                                                                                                                          ('Tài chính', 'FB001', 'Ngân hàng thương mại cung cấp dịch vụ tài chính đa dạng', 'Ngân hàng FinBank', 'https://finbank.vn', 'Ngân hàng', 500, 2005, 2);

INSERT INTO job_seeker (birth_date, description, education, expected_salary, job_type, resume_url, app_user_id) VALUES
                                                                                                                    ('1995-03-15 00:00:00', 'Lập trình viên với 3 năm kinh nghiệm Java', 'Đại học CNTT', 25000000, 'FULL_TIME', 'https://example.com/resume/an.pdf', 3),
                                                                                                                    ('1997-07-22 00:00:00', 'Chuyên viên marketing với kỹ năng SEO', 'Đại học Kinh tế', 18000000, 'FULL_TIME', 'https://example.com/resume/binh.pdf', 4),
                                                                                                                    ('1993-11-10 00:00:00', 'Kỹ sư cơ khí với kinh nghiệm thiết kế CAD', 'Đại học Bách Khoa', 22000000, 'FULL_TIME', 'https://example.com/resume/cuong.pdf', 5),
                                                                                                                    ('1998-05-30 00:00:00', 'Nhân viên kế toán có chứng chỉ ACCA', 'Đại học Tài chính', 15000000, 'PART_TIME', 'https://example.com/resume/dung.pdf', 6),
                                                                                                                    ('1996-09-12 00:00:00', 'Nhà thiết kế đồ họa sáng tạo', 'Đại học Mỹ thuật', 20000000, 'FREELANCE', 'https://example.com/resume/em.pdf', 7),
                                                                                                                    ('1999-02-25 00:00:00', 'Sinh viên thực tập ngành CNTT', 'Đại học Khoa học Tự nhiên', 8000000, 'INTERNSHIP', 'https://example.com/resume/phuong.pdf', 8),
                                                                                                                    ('1994-04-18 00:00:00', 'Chuyên viên nhân sự với 2 năm kinh nghiệm', 'Đại học Lao động Xã hội', 17000000, 'FULL_TIME', 'https://example.com/resume/giang.pdf', 9),
                                                                                                                    ('1997-12-05 00:00:00', 'Giáo viên tiếng Anh có chứng chỉ TESOL', 'Đại học Sư phạm', 20000000, 'PART_TIME', 'https://example.com/resume/hanh.pdf', 10);

INSERT INTO category (image_url, name) VALUES
                                           ('https://example.com/category/it.jpg', 'Công nghệ thông tin'),
                                           ('https://example.com/category/finance.jpg', 'Tài chính - Ngân hàng'),
                                           ('https://example.com/category/marketing.jpg', 'Marketing'),
                                           ('https://example.com/category/education.jpg', 'Giáo dục');

INSERT INTO position (name, category_id) VALUES
                                             ('Lập trình viên', 1),
                                             ('Chuyên viên tài chính', 2),
                                             ('Nhân viên marketing', 3),
                                             ('Giáo viên', 4);

INSERT INTO job_seeker__position (job_seeker_id, position_id) VALUES
                                                                  (1, 1), -- Nguyễn Văn An (Lập trình viên)
                                                                  (2, 3), -- Trần Thị Bình (Marketing)
                                                                  (3, 1), -- Lê Văn Cường (Lập trình viên)
                                                                  (4, 2), -- Phạm Thị Dung (Tài chính)
                                                                  (5, 3), -- Hoàng Văn Em (Marketing, thiết kế)
                                                                  (6, 1), -- Vũ Thị Phượng (Lập trình viên, thực tập)
                                                                  (7, 2), -- Đặng Văn Giang (Tài chính, nhân sự)
                                                                  (8, 4); -- Bùi Thị Hạnh (Giáo viên)

INSERT INTO post (address, benefit, created_at, description, experience_years_required, expiration_date, job_type, location, requirements, salary_range, status, updated_at, employer_id, position_id) VALUES
                                                                                                                                                                                                           ('123 Đường Nguyễn Huệ, Quận 1, TP.HCM', 'Bảo hiểm, thưởng cuối năm', '2025-05-10 09:00:00', 'Tuyển lập trình viên Java', 2, '2025-06-10 23:59:59', 'FULL_TIME', 'TP.HCM', 'Java, Spring, SQL', '20-25 triệu', 'PUBLISHED', '2025-05-10 09:00:00', 1, 1),
                                                                                                                                                                                                           ('456 Đường Lê Lợi, Quận 3, TP.HCM', 'Bảo hiểm, du lịch hàng năm', '2025-05-11 10:00:00', 'Tuyển chuyên viên tài chính', 3, '2025-06-11 23:59:59', 'FULL_TIME', 'TP.HCM', 'ACCA, Excel, phân tích tài chính', '18-22 triệu', 'PUBLISHED', '2025-05-11 10:00:00', 2, 2);

INSERT INTO contract (contract_term, contract_title, created_date, end_date, salary, start_date, status, employer_id, job_seeker_id) VALUES
    ('1 năm', 'Hợp đồng lập trình viên', '2025-06-01 09:00:00', '2026-06-01 00:00:00', 25000000, '2025-06-01 00:00:00', 'PENDING', 1, 1);
INSERT INTO experience (company_name, created_at, end_date, is_current, job_description, job_title, start_date, job_seeker_id) VALUES
                                                                                                                                   ('FPT Software', '2025-05-03 08:00:00', '2025-04-30', 0, 'Phát triển ứng dụng web', 'Lập trình viên Java', '2022-01-01', 1),
                                                                                                                                   ('VNG Corporation', '2025-05-04 10:00:00', NULL, 1, 'Quản lý chiến dịch quảng cáo', 'Nhân viên marketing', '2023-06-01', 2);
INSERT INTO message (content, message_type, sent_at, sender_id) VALUES
                                                                    ('Mời bạn tham gia phỏng vấn', 'TEXT', '2025-05-15 10:00:00', 1),
                                                                    ('Cảm ơn, tôi sẽ tham gia', 'TEXT', '2025-05-15 11:00:00', 3);
INSERT INTO message_receiver (is_notified, is_read, message_id, receiver_id) VALUES
                                                                                 (1, 1, 1, 3),
                                                                                 (1, 1, 2, 1);
INSERT INTO notification (content, created_at, noti_code, title, sender_id) VALUES
                                                                                ('Đơn ứng tuyển của bạn đã được xem', '2025-05-12 10:00:00', 'POST', 'Cập nhật đơn ứng tuyển', 1),
                                                                                ('Hợp đồng đã được gửi', '2025-06-01 10:00:00', 'CONTRACT', 'Thông báo hợp đồng', 1);
INSERT INTO notification_receiver (is_read, notification_id, receiver_id) VALUES
                                                                              (1, 1, 3),
                                                                              (0, 2, 3);
INSERT INTO review (comment, created_at, rating, type_review, employer_id, job_seeker_id) VALUES
                                                                                              ('Môi trường làm việc tốt', '2025-06-02 09:00:00', 5, 'JOB_SEEKER_REVIEW', 1, 1),
                                                                                              ('Ứng viên có kỹ năng tốt', '2025-06-02 10:00:00', 4, 'EMPLOYER_REVIEW', 1, 1);

INSERT INTO application_schedule (day_of_week, end_time, start_time) VALUES
                                                                         ('MONDAY', '10:00:00', '09:00:00'),
                                                                         ('TUESDAY', '15:00:00', '14:00:00');

INSERT INTO schedule_slot (day_of_week, end_time, start_time, application_schedule_id) VALUES
                                                                                           ('MONDAY', '10:00:00', '09:00:00', 1),
                                                                                           ('TUESDAY', '15:00:00', '14:00:00', 2);
INSERT INTO application (applied_at, cover_letter, cv_link, is_delete, is_read, status, timeslot, application_schedule_id, job_seeker_id, post_id) VALUES
                                                                                                                                                       ('2025-05-12 08:00:00', 'Tôi có kinh nghiệm Java 3 năm', 'https://example.com/cv/an.pdf', 0, 1, 'PENDING', '09:00-10:00', 1, 1, 1),
                                                                                                                                                       ('2025-05-12 09:00:00', 'Tôi phù hợp với vị trí tài chính', 'https://example.com/cv/dung.pdf', 0, 1, 'INTERVIEWING', '14:00-15:00', 2, 4, 2);
INSERT INTO interview (duration_minutes, interview_type, location_or_link, notes, scheduled_time, status, application_id) VALUES
                                                                                                                              (60, 'VIDEO', 'https://zoom.us/j/123456', 'Phỏng vấn kỹ thuật Java', '2025-05-20 09:00:00', 'SCHEDULED', 1),
                                                                                                                              (45, 'IN_PERSON', '456 Đường Lê Lợi, Quận 3, TP.HCM', 'Phỏng vấn tài chính', '2025-05-21 14:00:00', 'SCHEDULED', 2);

INSERT INTO interview (duration_minutes, interview_type, location_or_link, notes, scheduled_time, status, application_id) VALUES
                                                                                                                              (60, 'VIDEO', 'https://zoom.us/j/123456', 'Phỏng vấn kỹ thuật Java', '2025-05-20 09:00:00', 'SCHEDULED', 3),
                                                                                                                              (45, 'IN_PERSON', '456 Đường Lê Lợi, Quận 3, TP.HCM', 'Phỏng vấn tài chính', '2025-05-21 14:00:00', 'SCHEDULED', 4);
