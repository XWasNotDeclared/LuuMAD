-- Insert data for app_user (1 employer, 9 job seekers)
INSERT INTO app_user (id, address, avatar_url, created_at, email, full_name, password, phone, role, status, updated_at) VALUES
                                                                                                                            (1, '123 Đường Láng, Hà Nội', 'avatar.png', '2025-05-01 10:00:00', 'employer1@example.com', 'Công ty Tech Corp', '123456', '0901234561', 'EMPLOYER', 1, '2025-05-01 10:00:00'),
                                                                                                                            (2, '456 Lê Lợi, TP.HCM', 'avatar.png', '2025-05-02 11:00:00', 'jobseeker1@example.com', 'Trần Thị B', '123456', '0901234562', 'JOB_SEEKER', 1, '2025-05-02 11:00:00'),
                                                                                                                            (3, '789 Nguyễn Huệ, Đà Nẵng', 'avatar.png', '2025-05-03 12:00:00', 'jobseeker2@example.com', 'Lê Văn C', '123456', '0901234563', 'JOB_SEEKER', 1, '2025-05-03 12:00:00'),
                                                                                                                            (4, '101 Hai Bà Trưng, Huế', 'avatar.png', '2025-05-04 13:00:00', 'jobseeker3@example.com', 'Phạm Thị D', '123456', '0901234564', 'JOB_SEEKER', 1, '2025-05-04 13:00:00'),
                                                                                                                            (5, '202 Trần Phú, Nha Trang', 'avatar.png', '2025-05-05 14:00:00', 'jobseeker4@example.com', 'Hoàng Văn E', '123456', '0901234565', 'JOB_SEEKER', 1, '2025-05-05 14:00:00'),
                                                                                                                            (6, '303 Lý Thường Kiệt, Cần Thơ', 'avatar.png', '2025-05-06 15:00:00', 'jobseeker5@example.com', 'Võ Thị F', '123456', '0901234566', 'JOB_SEEKER', 1, '2025-05-06 15:00:00'),
                                                                                                                            (7, '404 Nguyễn Trãi, Hà Nội', 'avatar.png', '2025-05-07 16:00:00', 'jobseeker6@example.com', 'Đặng Văn G', '123456', '0901234567', 'JOB_SEEKER', 1, '2025-05-07 16:00:00'),
                                                                                                                            (8, '505 Phạm Văn Đồng, Đà Nẵng', 'avatar.png', '2025-05-08 17:00:00', 'jobseeker7@example.com', 'Bùi Thị H', '123456', '0901234568', 'JOB_SEEKER', 1, '2025-05-08 17:00:00'),
                                                                                                                            (9, '606 Tôn Đức Thắng, TP.HCM', 'avatar.png', '2025-05-09 18:00:00', 'jobseeker8@example.com', 'Ngô Văn I', '123456', '0901234569', 'JOB_SEEKER', 1, '2025-05-09 18:00:00'),
                                                                                                                            (10, '707 Bà Triệu, Hà Nội', 'avatar.png', '2025-05-10 19:00:00', 'jobseeker9@example.com', 'Lý Thị K', '123456', '0901234570', 'JOB_SEEKER', 1, '2025-05-10 19:00:00');

-- Insert data for application_schedule
INSERT INTO application_schedule (id, day_of_week, end_time, start_time) VALUES
                                                                             (1, 'MONDAY', '10:00:00', '09:00:00'),
                                                                             (2, 'TUESDAY', '11:00:00', '10:00:00'),
                                                                             (3, 'WEDNESDAY', '12:00:00', '11:00:00'),
                                                                             (4, 'THURSDAY', '13:00:00', '12:00:00'),
                                                                             (5, 'FRIDAY', '14:00:00', '13:00:00'),
                                                                             (6, 'SATURDAY', '15:00:00', '14:00:00'),
                                                                             (7, 'SUNDAY', '16:00:00', '15:00:00'),
                                                                             (8, 'MONDAY', '17:00:00', '16:00:00'),
                                                                             (9, 'TUESDAY', '18:00:00', '17:00:00'),
                                                                             (10, 'WEDNESDAY', '19:00:00', '18:00:00');

-- Insert data for category
INSERT INTO category (id, name) VALUES
                                    (1, 'Công nghệ thông tin'),
                                    (2, 'Kinh doanh'),
                                    (3, 'Marketing'),
                                    (4, 'Kế toán'),
                                    (5, 'Nhân sự'),
                                    (6, 'Thiết kế'),
                                    (7, 'Kỹ thuật'),
                                    (8, 'Y tế'),
                                    (9, 'Giáo dục'),
                                    (10, 'Dịch vụ khách hàng');


-- Insert data for employer (only 1 employer)
INSERT INTO employer (id, business_type, company_code, company_description, company_name, company_website, specialization, workforce_size, year_established, app_user_id) VALUES
    (1, 'Công nghệ', 'COMP001', 'Công ty công nghệ hàng đầu', 'Tech Corp', 'https://techcorp.com', 'Phần mềm', 100, 2010, 1);


-- Insert data for job_seeker (9 job seekers)
INSERT INTO job_seeker (id, birth_date, description, education, expected_salary, job_type, resume_url, app_user_id) VALUES
                                                                                                                        (1, '1995-01-01 00:00:00', 'Nhiệt huyết, có kinh nghiệm', 'Đại học CNTT', 15000000, 'FULL_TIME', 'https://example.com/resume1.pdf', 2),
                                                                                                                        (2, '1996-02-02 00:00:00', 'Tinh thần học hỏi', 'Đại học Kinh tế', 12000000, 'PART_TIME', 'https://example.com/resume2.pdf', 3),
                                                                                                                        (3, '1997-03-03 00:00:00', 'Chăm chỉ, sáng tạo', 'Đại học Thiết kế', 18000000, 'FREELANCE', 'https://example.com/resume3.pdf', 4),
                                                                                                                        (4, '1998-04-04 00:00:00', 'Kỹ năng giao tiếp tốt', 'Đại học Y', 20000000, 'FULL_TIME', 'https://example.com/resume4.pdf', 5),
                                                                                                                        (5, '1999-05-05 00:00:00', 'Kinh nghiệm thực tập', 'Đại học Kỹ thuật', 10000000, 'INTERNSHIP', 'https://example.com/resume5.pdf', 6),
                                                                                                                        (6, '1994-06-06 00:00:00', 'Tư duy logic', 'Đại học CNTT', 16000000, 'FULL_TIME', 'https://example.com/resume6.pdf', 7),
                                                                                                                        (7, '1993-07-07 00:00:00', 'Kỹ năng quản lý', 'Đại học Quản trị', 17000000, 'FULL_TIME', 'https://example.com/resume7.pdf', 8),
                                                                                                                        (8, '1992-08-08 00:00:00', 'Kinh nghiệm marketing', 'Đại học Marketing', 14000000, 'PART_TIME', 'https://example.com/resume8.pdf', 9),
                                                                                                                        (9, '1991-09-09 00:00:00', 'Chuyên môn tài chính', 'Đại học Tài chính', 19000000, 'FULL_TIME', 'https://example.com/resume9.pdf', 10);

-- Insert data for contract
INSERT INTO contract (id, contract_term, contract_title, created_date, end_date, salary, start_date, status, employer_id, job_seeker_id) VALUES
                                                                                                                                             (1, '1 năm', 'Hợp đồng lập trình viên', '2025-05-01 10:00:00', '2026-05-01 10:00:00', 15000000, '2025-05-01 10:00:00', 'ACTIVE', 1, 1),
                                                                                                                                             (2, '6 tháng', 'Hợp đồng marketing', '2025-05-02 10:00:00', '2025-11-02 10:00:00', 12000000, '2025-05-02 10:00:00', 'PENDING', 1, 2),
                                                                                                                                             (3, '2 năm', 'Hợp đồng kỹ sư', '2025-05-03 10:00:00', '2027-05-03 10:00:00', 18000000, '2025-05-03 10:00:00', 'ACTIVE', 1, 3),
                                                                                                                                             (4, '3 tháng', 'Hợp đồng thực tập', '2025-05-04 10:00:00', '2025-08-04 10:00:00', 10000000, '2025-05-04 10:00:00', 'COMPLETE', 1, 4),
                                                                                                                                             (5, '1 năm', 'Hợp đồng bác sĩ', '2025-05-05 10:00:00', '2026-05-05 10:00:00', 20000000, '2025-05-05 10:00:00', 'ACTIVE', 1, 5),
                                                                                                                                             (6, '6 tháng', 'Hợp đồng phân tích', '2025-05-06 10:00:00', '2025-11-06 10:00:00', 13000000, '2025-05-06 10:00:00', 'PENDING', 1, 6),
                                                                                                                                             (7, '1 năm', 'Hợp đồng quản lý', '2025-05-07 10:00:00', '2026-05-07 10:00:00', 17000000, '2025-05-07 10:00:00', 'ACTIVE', 1, 7),
                                                                                                                                             (8, '3 tháng', 'Hợp đồng thiết kế', '2025-05-08 10:00:00', '2025-08-08 10:00:00', 14000000, '2025-05-08 10:00:00', 'COMPLETE', 1, 8),
                                                                                                                                             (9, '2 năm', 'Hợp đồng tài chính', '2025-05-09 10:00:00', '2027-05-09 10:00:00', 19000000, '2025-05-09 10:00:00', 'ACTIVE', 1, 9);

-- Insert data for experience
INSERT INTO experience (id, company_name, created_at, end_date, is_current, job_description, job_title, start_date, job_seeker_id) VALUES
                                                                                                                                       (1, 'Tech Corp', '2025-05-01 10:00:00', '2024-12-31', 0, 'Phát triển phần mềm', 'Lập trình viên', '2023-01-01', 1),
                                                                                                                                       (2, 'Finance Ltd', '2025-05-02 10:00:00', NULL, 1, 'Phân tích tài chính', 'Chuyên viên tài chính', '2024-01-01', 2),
                                                                                                                                       (3, 'Electro Inc', '2025-05-03 10:00:00', '2024-06-30', 0, 'Thiết kế mạch điện', 'Kỹ sư điện', '2022-01-01', 3),
                                                                                                                                       (4, 'Retail Group', '2025-05-04 10:00:00', NULL, 1, 'Quản lý cửa hàng', 'Quản lý bán lẻ', '2023-06-01', 4),
                                                                                                                                       (5, 'Transport Co', '2025-05-05 10:00:00', '2024-03-31', 0, 'Điều phối vận chuyển', 'Nhân viên logistics', '2022-06-01', 5),
                                                                                                                                       (6, 'SoftPeak', '2025-05-06 10:00:00', NULL, 1, 'Phát triển ứng dụng', 'Lập trình viên', '2024-03-01', 6),
                                                                                                                                       (7, 'BuildMax', '2025-05-07 10:00:00', '2024-09-30', 0, 'Quản lý dự án', 'Quản lý xây dựng', '2023-03-01', 7),
                                                                                                                                       (8, 'HealthCare', '2025-05-08 10:00:00', NULL, 1, 'Chăm sóc bệnh nhân', 'Bác sĩ', '2022-09-01', 8),
                                                                                                                                       (9, 'EduCenter', '2025-05-09 10:00:00', '2024-12-31', 0, 'Giảng dạy CNTT', 'Giảng viên', '2023-09-01', 9);

-- Insert data for message
INSERT INTO message (id, content, message_type, sent_at, sender_id) VALUES
                                                                        (1, 'Xin chào, tôi muốn trao đổi về công việc', 'TEXT', '2025-05-01 10:00:00', 2),
                                                                        (2, 'https://example.com/image.jpg', 'IMAGE', '2025-05-02 10:00:00', 1),
                                                                        (3, 'Cảm ơn bạn đã ứng tuyển', 'TEXT', '2025-05-03 10:00:00', 3),
                                                                        (4, 'https://example.com/file.pdf', 'FILE', '2025-05-04 10:00:00', 1),
                                                                        (5, 'Lịch phỏng vấn đã được gửi', 'TEXT', '2025-05-05 10:00:00', 4),
                                                                        (6, 'Vui lòng gửi CV của bạn', 'TEXT', '2025-05-06 10:00:00', 1),
                                                                        (7, 'https://example.com/image2.jpg', 'IMAGE', '2025-05-07 10:00:00', 5),
                                                                        (8, 'Hợp đồng đã được ký', 'TEXT', '2025-05-08 10:00:00', 6),
                                                                        (9, 'https://example.com/file2.pdf', 'FILE', '2025-05-09 10:00:00', 1),
                                                                        (10, 'Cảm ơn bạn đã liên hệ', 'TEXT', '2025-05-10 10:00:00', 7);

-- Insert data for message_receiver
INSERT INTO message_receiver (id, is_read, message_id, receiver_id) VALUES
                                                                        (1, 1, 1, 1),
                                                                        (2, 0, 2, 2),
                                                                        (3, 1, 3, 1),
                                                                        (4, 0, 4, 3),
                                                                        (5, 1, 5, 1),
                                                                        (6, 0, 6, 4),
                                                                        (7, 1, 7, 1),
                                                                        (8, 0, 8, 1),
                                                                        (9, 1, 9, 5),
                                                                        (10, 0, 10, 1);

-- Insert data for notification
INSERT INTO notification (id, content, created_at, noti_code, title, sender_id) VALUES
                                                                                    (1, 'Bạn có một tin nhắn mới', '2025-05-01 10:00:00', 'POST', 'Tin nhắn mới', 2),
                                                                                    (2, 'Hợp đồng đã được ký', '2025-05-02 10:00:00', 'CONTRACT', 'Hợp đồng ký kết', 1),
                                                                                    (3, 'Bài đăng mới được tạo', '2025-05-03 10:00:00', 'POST', 'Bài đăng mới', 3),
                                                                                    (4, 'Phỏng vấn đã được lên lịch', '2025-05-04 10:00:00', 'CONTRACT', 'Lịch phỏng vấn', 1),
                                                                                    (5, 'Ứng tuyển thành công', '2025-05-05 10:00:00', 'POST', 'Ứng tuyển', 4),
                                                                                    (6, 'Bạn có một thông báo mới', '2025-05-06 10:00:00', 'POST', 'Thông báo mới', 1),
                                                                                    (7, 'Hợp đồng sắp hết hạn', '2025-05-07 10:00:00', 'CONTRACT', 'Hợp đồng hết hạn', 5),
                                                                                    (8, 'Bài đăng đã được phê duyệt', '2025-05-08 10:00:00', 'POST', 'Phê duyệt bài đăng', 1),
                                                                                    (9, 'Tin nhắn mới từ nhà tuyển dụng', '2025-05-09 10:00:00', 'POST', 'Tin nhắn nhà tuyển dụng', 6),
                                                                                    (10, 'Hợp đồng đã được gia hạn', '2025-05-10 10:00:00', 'CONTRACT', 'Gia hạn hợp đồng', 1);

-- Insert data for notification_receiver
INSERT INTO notification_receiver (id, is_read, notification_id, receiver_id) VALUES
                                                                                  (1, 1, 1, 1),
                                                                                  (2, 0, 2, 2),
                                                                                  (3, 1, 3, 1),
                                                                                  (4, 0, 4, 3),
                                                                                  (5, 1, 5, 1),
                                                                                  (6, 0, 6, 4),
                                                                                  (7, 1, 7, 1),
                                                                                  (8, 0, 8, 5),
                                                                                  (9, 1, 9, 1),
                                                                                  (10, 0, 10, 6);

-- Insert data for position
INSERT INTO position (id, name, category_id) VALUES
                                                 (1, 'Lập trình viên Java', 1),
                                                 (2, 'Nhà phân tích tài chính', 2),
                                                 (3, 'Chuyên viên marketing', 3),
                                                 (4, 'Kế toán viên', 4),
                                                 (5, 'Chuyên viên nhân sự', 5),
                                                 (6, 'Nhà thiết kế đồ họa', 6),
                                                 (7, 'Kỹ sư cơ khí', 7),
                                                 (8, 'Bác sĩ nội khoa', 8),
                                                 (9, 'Giảng viên CNTT', 9);

-- Insert data for job_seeker__position
INSERT INTO job_seeker__position (job_seeker_id, position_id) VALUES
                                                                  (1, 1),
                                                                  (2, 2),
                                                                  (3, 3),
                                                                  (4, 4),
                                                                  (5, 5),
                                                                  (6, 6),
                                                                  (7, 7),
                                                                  (8, 8),
                                                                  (9, 9);

-- Insert data for post
INSERT INTO post (id, address, benefit, created_at, description, experience_years_required, expiration_date, job_type, location, requirements, salary_range, status, updated_at, employer_id, position_id) VALUES
                                                                                                                                                                                                               (1, '123 Đường Láng, Hà Nội', 'Bảo hiểm, thưởng', '2025-05-01 10:00:00', 'Phát triển phần mềm', 2, '2025-06-01 10:00:00', 'FULL_TIME', 'Hà Nội', 'Java, Spring', '15-20 triệu', 'PUBLISHED', '2025-05-01 10:00:00', 1, 1),
                                                                                                                                                                                                               (2, '123 Đường Láng, Hà Nội', 'Nghỉ phép, đào tạo', '2025-05-02 10:00:00', 'Phân tích tài chính', 3, '2025-06-02 10:00:00', 'PART_TIME', 'Hà Nội', 'Excel, CFA', '12-15 triệu', 'DRAFT', '2025-05-02 10:00:00', 1, 2),
                                                                                                                                                                                                               (3, '123 Đường Láng, Hà Nội', 'Thưởng dự án', '2025-05-03 10:00:00', 'Quảng cáo số', 1, '2025-06-03 10:00:00', 'FREELANCE', 'Hà Nội', 'Google Ads', '10-18 triệu', 'PUBLISHED', '2025-05-03 10:00:00', 1, 3),
                                                                                                                                                                                                               (4, '123 Đường Láng, Hà Nội', 'Bảo hiểm y tế', '2025-05-04 10:00:00', 'Kế toán tổng hợp', 2, '2025-06-04 10:00:00', 'FULL_TIME', 'Hà Nội', 'MISA, Excel', '12-16 triệu', 'CLOSED', '2025-05-04 10:00:00', 1, 4),
                                                                                                                                                                                                               (5, '123 Đường Láng, Hà Nội', 'Du lịch công ty', '2025-05-05 10:00:00', 'Tuyển dụng nhân sự', 3, '2025-06-05 10:00:00', 'FULL_TIME', 'Hà Nội', 'HRM, phỏng vấn', '15-20 triệu', 'PUBLISHED', '2025-05-05 10:00:00', 1, 5),
                                                                                                                                                                                                               (6, '123 Đường Láng, Hà Nội', 'Thưởng cuối năm', '2025-05-06 10:00:00', 'Thiết kế giao diện', 2, '2025-06-06 10:00:00', 'PART_TIME', 'Hà Nội', 'Figma, Photoshop', '10-15 triệu', 'DRAFT', '2025-05-06 10:00:00', 1, 6),
                                                                                                                                                                                                               (7, '123 Đường Láng, Hà Nội', 'Bảo hiểm xã hội', '2025-05-07 10:00:00', 'Thiết kế cơ khí', 4, '2025-06-07 10:00:00', 'FULL_TIME', 'Hà Nội', 'AutoCAD, SolidWorks', '18-22 triệu', 'PUBLISHED', '2025-05-07 10:00:00', 1, 7),
                                                                                                                                                                                                               (8, '123 Đường Láng, Hà Nội', 'Hỗ trợ ăn trưa', '2025-05-08 10:00:00', 'Chăm sóc bệnh nhân', 3, '2025-06-08 10:00:00', 'FULL_TIME', 'Hà Nội', 'Y khoa, giao tiếp', '20-25 triệu', 'CLOSED', '2025-05-08 10:00:00', 1, 8),
                                                                                                                                                                                                               (9, '123 Đường Láng, Hà Nội', 'Học bổng', '2025-05-09 10:00:00', 'Giảng dạy CNTT', 2, '2025-06-09 10:00:00', 'PART_TIME', 'Hà Nội', 'Python, Java', '15-20 triệu', 'PUBLISHED', '2025-05-09 10:00:00', 1, 9);

-- Insert data for application
INSERT INTO application (id, applied_at, cover_letter, status, application_schedule_id, job_seeker_id, post_id) VALUES
                                                                                                                    (1, '2025-05-01 10:00:00', 'Tôi rất quan tâm đến vị trí này', 'PENDING', 1, 1, 1),
                                                                                                                    (2, '2025-05-02 10:00:00', 'Kinh nghiệm phù hợp với công việc', 'UNDER_REVIEW', 2, 2, 2),
                                                                                                                    (3, '2025-05-03 10:00:00', 'Mong muốn đóng góp cho công ty', 'INTERVIEWING', 3, 3, 3),
                                                                                                                    (4, '2025-05-04 10:00:00', 'Tôi có kỹ năng cần thiết', 'ACCEPTED', 4, 4, 4),
                                                                                                                    (5, '2025-05-05 10:00:00', 'Sẵn sàng học hỏi', 'REJECTED', 5, 5, 5),
                                                                                                                    (6, '2025-05-06 10:00:00', 'Đam mê công việc', 'WITHDRAWN', 6, 6, 6),
                                                                                                                    (7, '2025-05-07 10:00:00', 'Kinh nghiệm thực tiễn', 'PENDING', 7, 7, 7),
                                                                                                                    (8, '2025-05-08 10:00:00', 'Tôi phù hợp với vị trí', 'UNDER_REVIEW', 8, 8, 8),
                                                                                                                    (9, '2025-05-09 10:00:00', 'Có kỹ năng chuyên môn', 'INTERVIEWING', 9, 9, 9);

-- Insert data for interview
INSERT INTO interview (id, duration_minutes, interview_type, location_or_link, notes, scheduled_time, status, application_id) VALUES
                                                                                                                                  (1, 30, 'VIDEO', 'https://zoom.us/j/123', 'Phỏng vấn kỹ năng Java', '2025-05-01 11:00:00', 'SCHEDULED', 1),
                                                                                                                                  (2, 45, 'IN_PERSON', '123 Đường Láng, Hà Nội', 'Phỏng vấn tài chính', '2025-05-02 11:00:00', 'COMPLETED', 2),
                                                                                                                                  (3, 60, 'PHONE', '0901234561', 'Phỏng vấn marketing', '2025-05-03 11:00:00', 'CANCELED', 3),
                                                                                                                                  (4, 30, 'VIDEO', 'https://zoom.us/j/456', 'Phỏng vấn kế toán', '2025-05-04 11:00:00', 'RESCHEDULED', 4),
                                                                                                                                  (5, 45, 'IN_PERSON', '123 Đường Láng, Hà Nội', 'Phỏng vấn nhân sự', '2025-05-05 11:00:00', 'SCHEDULED', 5),
                                                                                                                                  (6, 60, 'PHONE', '0901234562', 'Phỏng vấn thiết kế', '2025-05-06 11:00:00', 'COMPLETED', 6),
                                                                                                                                  (7, 30, 'VIDEO', 'https://zoom.us/j/789', 'Phỏng vấn kỹ thuật', '2025-05-07 11:00:00', 'CANCELED', 7),
                                                                                                                                  (8, 45, 'IN_PERSON', '123 Đường Láng, Hà Nội', 'Phỏng vấn y tế', '2025-05-08 11:00:00', 'RESCHEDULED', 8),
                                                                                                                                  (9, 60, 'PHONE', '0901234563', 'Phỏng vấn giảng dạy', '2025-05-09 11:00:00', 'SCHEDULED', 9);

-- Insert data for review
INSERT INTO review (id, comment, created_at, rating, type_review, employer_id, job_seeker_id) VALUES
                                                                                                  (1, 'Môi trường làm việc tốt', '2025-05-01 10:00:00', 5, 'JOB_SEEKER_REVIEW', 1, 1),
                                                                                                  (2, 'Nhà tuyển dụng thân thiện', '2025-05-02 10:00:00', 4, 'JOB_SEEKER_REVIEW', 1, 2),
                                                                                                  (3, 'Ứng viên có kỹ năng tốt', '2025-05-03 10:00:00', 4, 'EMPLOYER_REVIEW', 1, 3),
                                                                                                  (4, 'Quy trình tuyển dụng chuyên nghiệp', '2025-05-04 10:00:00', 5, 'JOB_SEEKER_REVIEW', 1, 4),
                                                                                                  (5, 'Ứng viên năng động', '2025-05-05 10:00:00', 3, 'EMPLOYER_REVIEW', 1, 5),
                                                                                                  (6, 'Công ty hỗ trợ tốt', '2025-05-06 10:00:00', 4, 'JOB_SEEKER_REVIEW', 1, 6),
                                                                                                  (7, 'Ứng viên có kinh nghiệm', '2025-05-07 10:00:00', 5, 'EMPLOYER_REVIEW', 1, 7),
                                                                                                  (8, 'Môi trường chuyên nghiệp', '2025-05-08 10:00:00', 5, 'JOB_SEEKER_REVIEW', 1, 8),
                                                                                                  (9, 'Ứng viên sáng tạo', '2025-05-09 10:00:00', 4, 'EMPLOYER_REVIEW', 1, 9);
