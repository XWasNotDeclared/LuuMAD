import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import NotificationReceiver from './notification-receiver';
import NotificationReceiverDetail from './notification-receiver-detail';
import NotificationReceiverUpdate from './notification-receiver-update';
import NotificationReceiverDeleteDialog from './notification-receiver-delete-dialog';

const NotificationReceiverRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<NotificationReceiver />} />
    <Route path="new" element={<NotificationReceiverUpdate />} />
    <Route path=":id">
      <Route index element={<NotificationReceiverDetail />} />
      <Route path="edit" element={<NotificationReceiverUpdate />} />
      <Route path="delete" element={<NotificationReceiverDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default NotificationReceiverRoutes;
