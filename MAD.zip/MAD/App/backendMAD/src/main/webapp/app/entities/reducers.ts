import appUser from 'app/entities/app-user/app-user.reducer';
import jobSeeker from 'app/entities/job-seeker/job-seeker.reducer';
import employer from 'app/entities/employer/employer.reducer';
import post from 'app/entities/post/post.reducer';
import position from 'app/entities/position/position.reducer';
import category from 'app/entities/category/category.reducer';
import application from 'app/entities/application/application.reducer';
import applicationSchedule from 'app/entities/application-schedule/application-schedule.reducer';
import interview from 'app/entities/interview/interview.reducer';
import message from 'app/entities/message/message.reducer';
import messageReceiver from 'app/entities/message-receiver/message-receiver.reducer';
import notification from 'app/entities/notification/notification.reducer';
import review from 'app/entities/review/review.reducer';
import experience from 'app/entities/experience/experience.reducer';
import contract from 'app/entities/contract/contract.reducer';
/* jhipster-needle-add-reducer-import - JHipster will add reducer here */

const entitiesReducers = {
  appUser,
  jobSeeker,
  employer,
  post,
  position,
  category,
  application,
  applicationSchedule,
  interview,
  message,
  messageReceiver,
  notification,
  review,
  experience,
  contract,
  /* jhipster-needle-add-reducer-combine - JHipster will add reducer here */
};

export default entitiesReducers;
