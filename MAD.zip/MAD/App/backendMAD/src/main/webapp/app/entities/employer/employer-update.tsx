import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getAppUsers } from 'app/entities/app-user/app-user.reducer';
import { createEntity, getEntity, reset, updateEntity } from './employer.reducer';

export const EmployerUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const appUsers = useAppSelector(state => state.appUser.entities);
  const employerEntity = useAppSelector(state => state.employer.entity);
  const loading = useAppSelector(state => state.employer.loading);
  const updating = useAppSelector(state => state.employer.updating);
  const updateSuccess = useAppSelector(state => state.employer.updateSuccess);

  const handleClose = () => {
    navigate(`/employer${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getAppUsers({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    if (values.workforceSize !== undefined && typeof values.workforceSize !== 'number') {
      values.workforceSize = Number(values.workforceSize);
    }
    if (values.yearEstablished !== undefined && typeof values.yearEstablished !== 'number') {
      values.yearEstablished = Number(values.yearEstablished);
    }

    const entity = {
      ...employerEntity,
      ...values,
      appUser: appUsers.find(it => it.id.toString() === values.appUser?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          ...employerEntity,
          appUser: employerEntity?.appUser?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.employer.home.createOrEditLabel" data-cy="EmployerCreateUpdateHeading">
            Create or edit a Employer
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="employer-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Company Name"
                id="employer-companyName"
                name="companyName"
                data-cy="companyName"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Company Code"
                id="employer-companyCode"
                name="companyCode"
                data-cy="companyCode"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Company Description"
                id="employer-companyDescription"
                name="companyDescription"
                data-cy="companyDescription"
                type="textarea"
              />
              <ValidatedField
                label="Company Website"
                id="employer-companyWebsite"
                name="companyWebsite"
                data-cy="companyWebsite"
                type="text"
              />
              <ValidatedField label="Workforce Size" id="employer-workforceSize" name="workforceSize" data-cy="workforceSize" type="text" />
              <ValidatedField label="Business Type" id="employer-businessType" name="businessType" data-cy="businessType" type="text" />
              <ValidatedField
                label="Year Established"
                id="employer-yearEstablished"
                name="yearEstablished"
                data-cy="yearEstablished"
                type="text"
              />
              <ValidatedField
                label="Specialization"
                id="employer-specialization"
                name="specialization"
                data-cy="specialization"
                type="text"
              />
              <ValidatedField id="employer-appUser" name="appUser" data-cy="appUser" label="App User" type="select">
                <option value="" key="0" />
                {appUsers
                  ? appUsers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/employer" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default EmployerUpdate;
