import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './app-user.reducer';

export const AppUserDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const appUserEntity = useAppSelector(state => state.appUser.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="appUserDetailsHeading">App User</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{appUserEntity.id}</dd>
          <dt>
            <span id="email">Email</span>
          </dt>
          <dd>{appUserEntity.email}</dd>
          <dt>
            <span id="password">Password</span>
          </dt>
          <dd>{appUserEntity.password}</dd>
          <dt>
            <span id="role">Role</span>
          </dt>
          <dd>{appUserEntity.role}</dd>
          <dt>
            <span id="createdAt">Created At</span>
          </dt>
          <dd>{appUserEntity.createdAt ? <TextFormat value={appUserEntity.createdAt} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="updatedAt">Updated At</span>
          </dt>
          <dd>{appUserEntity.updatedAt ? <TextFormat value={appUserEntity.updatedAt} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="fullName">Full Name</span>
          </dt>
          <dd>{appUserEntity.fullName}</dd>
          <dt>
            <span id="phone">Phone</span>
          </dt>
          <dd>{appUserEntity.phone}</dd>
          <dt>
            <span id="avatarUrl">Avatar Url</span>
          </dt>
          <dd>{appUserEntity.avatarUrl}</dd>
          <dt>
            <span id="address">Address</span>
          </dt>
          <dd>{appUserEntity.address}</dd>
          <dt>
            <span id="status">Status</span>
          </dt>
          <dd>{appUserEntity.status ? 'true' : 'false'}</dd>
        </dl>
        <Button tag={Link} to="/app-user" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/app-user/${appUserEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default AppUserDetail;
