import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getJobSeekers } from 'app/entities/job-seeker/job-seeker.reducer';
import { createEntity, getEntity, reset, updateEntity } from './experience.reducer';

export const ExperienceUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const jobSeekers = useAppSelector(state => state.jobSeeker.entities);
  const experienceEntity = useAppSelector(state => state.experience.entity);
  const loading = useAppSelector(state => state.experience.loading);
  const updating = useAppSelector(state => state.experience.updating);
  const updateSuccess = useAppSelector(state => state.experience.updateSuccess);

  const handleClose = () => {
    navigate(`/experience${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getJobSeekers({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.createdAt = convertDateTimeToServer(values.createdAt);

    const entity = {
      ...experienceEntity,
      ...values,
      jobSeeker: jobSeekers.find(it => it.id.toString() === values.jobSeeker?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          createdAt: displayDefaultDateTime(),
        }
      : {
          ...experienceEntity,
          createdAt: convertDateTimeFromServer(experienceEntity.createdAt),
          jobSeeker: experienceEntity?.jobSeeker?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.experience.home.createOrEditLabel" data-cy="ExperienceCreateUpdateHeading">
            Create or edit a Experience
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="experience-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Company Name"
                id="experience-companyName"
                name="companyName"
                data-cy="companyName"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Job Title"
                id="experience-jobTitle"
                name="jobTitle"
                data-cy="jobTitle"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Job Description"
                id="experience-jobDescription"
                name="jobDescription"
                data-cy="jobDescription"
                type="textarea"
              />
              <ValidatedField
                label="Start Date"
                id="experience-startDate"
                name="startDate"
                data-cy="startDate"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="End Date" id="experience-endDate" name="endDate" data-cy="endDate" type="date" />
              <ValidatedField label="Is Current" id="experience-isCurrent" name="isCurrent" data-cy="isCurrent" check type="checkbox" />
              <ValidatedField
                label="Created At"
                id="experience-createdAt"
                name="createdAt"
                data-cy="createdAt"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField id="experience-jobSeeker" name="jobSeeker" data-cy="jobSeeker" label="Job Seeker" type="select">
                <option value="" key="0" />
                {jobSeekers
                  ? jobSeekers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/experience" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default ExperienceUpdate;
