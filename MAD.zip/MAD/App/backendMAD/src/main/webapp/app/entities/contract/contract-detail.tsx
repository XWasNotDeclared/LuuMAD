import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './contract.reducer';

export const ContractDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const contractEntity = useAppSelector(state => state.contract.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="contractDetailsHeading">Contract</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{contractEntity.id}</dd>
          <dt>
            <span id="contractTerm">Contract Term</span>
          </dt>
          <dd>{contractEntity.contractTerm}</dd>
          <dt>
            <span id="createdDate">Created Date</span>
          </dt>
          <dd>
            {contractEntity.createdDate ? <TextFormat value={contractEntity.createdDate} type="date" format={APP_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="endDate">End Date</span>
          </dt>
          <dd>{contractEntity.endDate ? <TextFormat value={contractEntity.endDate} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="salary">Salary</span>
          </dt>
          <dd>{contractEntity.salary}</dd>
          <dt>
            <span id="startDate">Start Date</span>
          </dt>
          <dd>{contractEntity.startDate ? <TextFormat value={contractEntity.startDate} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="status">Status</span>
          </dt>
          <dd>{contractEntity.status}</dd>
          <dt>Job Seeker</dt>
          <dd>{contractEntity.jobSeeker ? contractEntity.jobSeeker.id : ''}</dd>
          <dt>Employer</dt>
          <dd>{contractEntity.employer ? contractEntity.employer.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/contract" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/contract/${contractEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default ContractDetail;
