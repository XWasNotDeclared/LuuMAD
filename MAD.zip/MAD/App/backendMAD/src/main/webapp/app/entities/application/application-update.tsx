import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getApplicationSchedules } from 'app/entities/application-schedule/application-schedule.reducer';
import { getEntities as getJobSeekers } from 'app/entities/job-seeker/job-seeker.reducer';
import { getEntities as getPosts } from 'app/entities/post/post.reducer';
import { ApplicationStatus } from 'app/shared/model/enumerations/application-status.model';
import { createEntity, getEntity, reset, updateEntity } from './application.reducer';

export const ApplicationUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const applicationSchedules = useAppSelector(state => state.applicationSchedule.entities);
  const jobSeekers = useAppSelector(state => state.jobSeeker.entities);
  const posts = useAppSelector(state => state.post.entities);
  const applicationEntity = useAppSelector(state => state.application.entity);
  const loading = useAppSelector(state => state.application.loading);
  const updating = useAppSelector(state => state.application.updating);
  const updateSuccess = useAppSelector(state => state.application.updateSuccess);
  const applicationStatusValues = Object.keys(ApplicationStatus);

  const handleClose = () => {
    navigate(`/application${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getApplicationSchedules({}));
    dispatch(getJobSeekers({}));
    dispatch(getPosts({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.appliedAt = convertDateTimeToServer(values.appliedAt);

    const entity = {
      ...applicationEntity,
      ...values,
      applicationSchedule: applicationSchedules.find(it => it.id.toString() === values.applicationSchedule?.toString()),
      jobSeeker: jobSeekers.find(it => it.id.toString() === values.jobSeeker?.toString()),
      post: posts.find(it => it.id.toString() === values.post?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          appliedAt: displayDefaultDateTime(),
        }
      : {
          status: 'PENDING',
          ...applicationEntity,
          appliedAt: convertDateTimeFromServer(applicationEntity.appliedAt),
          applicationSchedule: applicationEntity?.applicationSchedule?.id,
          jobSeeker: applicationEntity?.jobSeeker?.id,
          post: applicationEntity?.post?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.application.home.createOrEditLabel" data-cy="ApplicationCreateUpdateHeading">
            Create or edit a Application
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="application-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Status" id="application-status" name="status" data-cy="status" type="select">
                {applicationStatusValues.map(applicationStatus => (
                  <option value={applicationStatus} key={applicationStatus}>
                    {applicationStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Applied At"
                id="application-appliedAt"
                name="appliedAt"
                data-cy="appliedAt"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField label="Cover Letter" id="application-coverLetter" name="coverLetter" data-cy="coverLetter" type="textarea" />
              <ValidatedField
                id="application-applicationSchedule"
                name="applicationSchedule"
                data-cy="applicationSchedule"
                label="Application Schedule"
                type="select"
              >
                <option value="" key="0" />
                {applicationSchedules
                  ? applicationSchedules.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="application-jobSeeker" name="jobSeeker" data-cy="jobSeeker" label="Job Seeker" type="select">
                <option value="" key="0" />
                {jobSeekers
                  ? jobSeekers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="application-post" name="post" data-cy="post" label="Post" type="select">
                <option value="" key="0" />
                {posts
                  ? posts.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/application" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default ApplicationUpdate;
