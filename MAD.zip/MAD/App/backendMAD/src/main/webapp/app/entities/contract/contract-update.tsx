import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getJobSeekers } from 'app/entities/job-seeker/job-seeker.reducer';
import { getEntities as getEmployers } from 'app/entities/employer/employer.reducer';
import { ContractStatus } from 'app/shared/model/enumerations/contract-status.model';
import { createEntity, getEntity, reset, updateEntity } from './contract.reducer';

export const ContractUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const jobSeekers = useAppSelector(state => state.jobSeeker.entities);
  const employers = useAppSelector(state => state.employer.entities);
  const contractEntity = useAppSelector(state => state.contract.entity);
  const loading = useAppSelector(state => state.contract.loading);
  const updating = useAppSelector(state => state.contract.updating);
  const updateSuccess = useAppSelector(state => state.contract.updateSuccess);
  const contractStatusValues = Object.keys(ContractStatus);

  const handleClose = () => {
    navigate(`/contract${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getJobSeekers({}));
    dispatch(getEmployers({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.createdDate = convertDateTimeToServer(values.createdDate);
    values.endDate = convertDateTimeToServer(values.endDate);
    if (values.salary !== undefined && typeof values.salary !== 'number') {
      values.salary = Number(values.salary);
    }
    values.startDate = convertDateTimeToServer(values.startDate);

    const entity = {
      ...contractEntity,
      ...values,
      jobSeeker: jobSeekers.find(it => it.id.toString() === values.jobSeeker?.toString()),
      employer: employers.find(it => it.id.toString() === values.employer?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          createdDate: displayDefaultDateTime(),
          endDate: displayDefaultDateTime(),
          startDate: displayDefaultDateTime(),
        }
      : {
          status: 'ACTIVE',
          ...contractEntity,
          createdDate: convertDateTimeFromServer(contractEntity.createdDate),
          endDate: convertDateTimeFromServer(contractEntity.endDate),
          startDate: convertDateTimeFromServer(contractEntity.startDate),
          jobSeeker: contractEntity?.jobSeeker?.id,
          employer: contractEntity?.employer?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.contract.home.createOrEditLabel" data-cy="ContractCreateUpdateHeading">
            Create or edit a Contract
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="contract-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Contract Term" id="contract-contractTerm" name="contractTerm" data-cy="contractTerm" type="text" />
              <ValidatedField
                label="Created Date"
                id="contract-createdDate"
                name="createdDate"
                data-cy="createdDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField
                label="End Date"
                id="contract-endDate"
                name="endDate"
                data-cy="endDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField label="Salary" id="contract-salary" name="salary" data-cy="salary" type="text" />
              <ValidatedField
                label="Start Date"
                id="contract-startDate"
                name="startDate"
                data-cy="startDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField label="Status" id="contract-status" name="status" data-cy="status" type="select">
                {contractStatusValues.map(contractStatus => (
                  <option value={contractStatus} key={contractStatus}>
                    {contractStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField id="contract-jobSeeker" name="jobSeeker" data-cy="jobSeeker" label="Job Seeker" type="select">
                <option value="" key="0" />
                {jobSeekers
                  ? jobSeekers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="contract-employer" name="employer" data-cy="employer" label="Employer" type="select">
                <option value="" key="0" />
                {employers
                  ? employers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/contract" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default ContractUpdate;
