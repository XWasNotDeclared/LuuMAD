import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPositions } from 'app/entities/position/position.reducer';
import { getEntities as getEmployers } from 'app/entities/employer/employer.reducer';
import { JobType } from 'app/shared/model/enumerations/job-type.model';
import { PostStatus } from 'app/shared/model/enumerations/post-status.model';
import { createEntity, getEntity, reset, updateEntity } from './post.reducer';

export const PostUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const positions = useAppSelector(state => state.position.entities);
  const employers = useAppSelector(state => state.employer.entities);
  const postEntity = useAppSelector(state => state.post.entity);
  const loading = useAppSelector(state => state.post.loading);
  const updating = useAppSelector(state => state.post.updating);
  const updateSuccess = useAppSelector(state => state.post.updateSuccess);
  const jobTypeValues = Object.keys(JobType);
  const postStatusValues = Object.keys(PostStatus);

  const handleClose = () => {
    navigate(`/post${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPositions({}));
    dispatch(getEmployers({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.createdAt = convertDateTimeToServer(values.createdAt);
    values.updatedAt = convertDateTimeToServer(values.updatedAt);
    values.expirationDate = convertDateTimeToServer(values.expirationDate);
    if (values.experienceYearsRequired !== undefined && typeof values.experienceYearsRequired !== 'number') {
      values.experienceYearsRequired = Number(values.experienceYearsRequired);
    }

    const entity = {
      ...postEntity,
      ...values,
      position: positions.find(it => it.id.toString() === values.position?.toString()),
      employer: employers.find(it => it.id.toString() === values.employer?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          createdAt: displayDefaultDateTime(),
          updatedAt: displayDefaultDateTime(),
          expirationDate: displayDefaultDateTime(),
        }
      : {
          jobType: 'FULL_TIME',
          status: 'DRAFT',
          ...postEntity,
          createdAt: convertDateTimeFromServer(postEntity.createdAt),
          updatedAt: convertDateTimeFromServer(postEntity.updatedAt),
          expirationDate: convertDateTimeFromServer(postEntity.expirationDate),
          position: postEntity?.position?.id,
          employer: postEntity?.employer?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.post.home.createOrEditLabel" data-cy="PostCreateUpdateHeading">
            Create or edit a Post
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="post-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Description"
                id="post-description"
                name="description"
                data-cy="description"
                type="textarea"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Benefit"
                id="post-benefit"
                name="benefit"
                data-cy="benefit"
                type="textarea"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Job Type" id="post-jobType" name="jobType" data-cy="jobType" type="select">
                {jobTypeValues.map(jobType => (
                  <option value={jobType} key={jobType}>
                    {jobType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField label="Salary Range" id="post-salaryRange" name="salaryRange" data-cy="salaryRange" type="text" />
              <ValidatedField
                label="Location"
                id="post-location"
                name="location"
                data-cy="location"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Address" id="post-address" name="address" data-cy="address" type="text" />
              <ValidatedField label="Status" id="post-status" name="status" data-cy="status" type="select">
                {postStatusValues.map(postStatus => (
                  <option value={postStatus} key={postStatus}>
                    {postStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Created At"
                id="post-createdAt"
                name="createdAt"
                data-cy="createdAt"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField
                label="Updated At"
                id="post-updatedAt"
                name="updatedAt"
                data-cy="updatedAt"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField
                label="Expiration Date"
                id="post-expirationDate"
                name="expirationDate"
                data-cy="expirationDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField
                label="Experience Years Required"
                id="post-experienceYearsRequired"
                name="experienceYearsRequired"
                data-cy="experienceYearsRequired"
                type="text"
              />
              <ValidatedField
                label="Requirements"
                id="post-requirements"
                name="requirements"
                data-cy="requirements"
                type="textarea"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField id="post-position" name="position" data-cy="position" label="Position" type="select">
                <option value="" key="0" />
                {positions
                  ? positions.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="post-employer" name="employer" data-cy="employer" label="Employer" type="select">
                <option value="" key="0" />
                {employers
                  ? employers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/post" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default PostUpdate;
