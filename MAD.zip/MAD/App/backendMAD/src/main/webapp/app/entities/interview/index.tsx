import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Interview from './interview';
import InterviewDetail from './interview-detail';
import InterviewUpdate from './interview-update';
import InterviewDeleteDialog from './interview-delete-dialog';

const InterviewRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<Interview />} />
    <Route path="new" element={<InterviewUpdate />} />
    <Route path=":id">
      <Route index element={<InterviewDetail />} />
      <Route path="edit" element={<InterviewUpdate />} />
      <Route path="delete" element={<InterviewDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default InterviewRoutes;
