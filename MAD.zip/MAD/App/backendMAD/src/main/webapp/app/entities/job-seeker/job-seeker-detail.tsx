import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './job-seeker.reducer';

export const JobSeekerDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const jobSeekerEntity = useAppSelector(state => state.jobSeeker.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="jobSeekerDetailsHeading">Job Seeker</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{jobSeekerEntity.id}</dd>
          <dt>
            <span id="resumeUrl">Resume Url</span>
          </dt>
          <dd>{jobSeekerEntity.resumeUrl}</dd>
          <dt>
            <span id="expectedSalary">Expected Salary</span>
          </dt>
          <dd>{jobSeekerEntity.expectedSalary}</dd>
          <dt>
            <span id="description">Description</span>
          </dt>
          <dd>{jobSeekerEntity.description}</dd>
          <dt>
            <span id="birthDate">Birth Date</span>
          </dt>
          <dd>
            {jobSeekerEntity.birthDate ? <TextFormat value={jobSeekerEntity.birthDate} type="date" format={APP_DATE_FORMAT} /> : null}
          </dd>
          <dt>App User</dt>
          <dd>{jobSeekerEntity.appUser ? jobSeekerEntity.appUser.id : ''}</dd>
          <dt>Positions</dt>
          <dd>
            {jobSeekerEntity.positions
              ? jobSeekerEntity.positions.map((val, i) => (
                  <span key={val.id}>
                    <a>{val.id}</a>
                    {jobSeekerEntity.positions && i === jobSeekerEntity.positions.length - 1 ? '' : ', '}
                  </span>
                ))
              : null}
          </dd>
        </dl>
        <Button tag={Link} to="/job-seeker" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/job-seeker/${jobSeekerEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default JobSeekerDetail;
