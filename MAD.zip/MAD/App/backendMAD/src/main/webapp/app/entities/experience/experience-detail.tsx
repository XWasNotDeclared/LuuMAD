import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './experience.reducer';

export const ExperienceDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const experienceEntity = useAppSelector(state => state.experience.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="experienceDetailsHeading">Experience</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{experienceEntity.id}</dd>
          <dt>
            <span id="companyName">Company Name</span>
          </dt>
          <dd>{experienceEntity.companyName}</dd>
          <dt>
            <span id="jobTitle">Job Title</span>
          </dt>
          <dd>{experienceEntity.jobTitle}</dd>
          <dt>
            <span id="jobDescription">Job Description</span>
          </dt>
          <dd>{experienceEntity.jobDescription}</dd>
          <dt>
            <span id="startDate">Start Date</span>
          </dt>
          <dd>
            {experienceEntity.startDate ? (
              <TextFormat value={experienceEntity.startDate} type="date" format={APP_LOCAL_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="endDate">End Date</span>
          </dt>
          <dd>
            {experienceEntity.endDate ? <TextFormat value={experienceEntity.endDate} type="date" format={APP_LOCAL_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="isCurrent">Is Current</span>
          </dt>
          <dd>{experienceEntity.isCurrent ? 'true' : 'false'}</dd>
          <dt>
            <span id="createdAt">Created At</span>
          </dt>
          <dd>
            {experienceEntity.createdAt ? <TextFormat value={experienceEntity.createdAt} type="date" format={APP_DATE_FORMAT} /> : null}
          </dd>
          <dt>Job Seeker</dt>
          <dd>{experienceEntity.jobSeeker ? experienceEntity.jobSeeker.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/experience" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/experience/${experienceEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default ExperienceDetail;
