import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Employer from './employer';
import EmployerDetail from './employer-detail';
import EmployerUpdate from './employer-update';
import EmployerDeleteDialog from './employer-delete-dialog';

const EmployerRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<Employer />} />
    <Route path="new" element={<EmployerUpdate />} />
    <Route path=":id">
      <Route index element={<EmployerDetail />} />
      <Route path="edit" element={<EmployerUpdate />} />
      <Route path="delete" element={<EmployerDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default EmployerRoutes;
