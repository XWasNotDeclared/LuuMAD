import React from 'react';
import { Route } from 'react-router-dom';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import MessageReceiver from './message-receiver';
import MessageReceiverDetail from './message-receiver-detail';
import MessageReceiverUpdate from './message-receiver-update';
import MessageReceiverDeleteDialog from './message-receiver-delete-dialog';

const MessageReceiverRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<MessageReceiver />} />
    <Route path="new" element={<MessageReceiverUpdate />} />
    <Route path=":id">
      <Route index element={<MessageReceiverDetail />} />
      <Route path="edit" element={<MessageReceiverUpdate />} />
      <Route path="delete" element={<MessageReceiverDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default MessageReceiverRoutes;
