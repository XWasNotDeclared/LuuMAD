import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './employer.reducer';

export const EmployerDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const employerEntity = useAppSelector(state => state.employer.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="employerDetailsHeading">Employer</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{employerEntity.id}</dd>
          <dt>
            <span id="companyName">Company Name</span>
          </dt>
          <dd>{employerEntity.companyName}</dd>
          <dt>
            <span id="companyCode">Company Code</span>
          </dt>
          <dd>{employerEntity.companyCode}</dd>
          <dt>
            <span id="companyDescription">Company Description</span>
          </dt>
          <dd>{employerEntity.companyDescription}</dd>
          <dt>
            <span id="companyWebsite">Company Website</span>
          </dt>
          <dd>{employerEntity.companyWebsite}</dd>
          <dt>
            <span id="workforceSize">Workforce Size</span>
          </dt>
          <dd>{employerEntity.workforceSize}</dd>
          <dt>
            <span id="businessType">Business Type</span>
          </dt>
          <dd>{employerEntity.businessType}</dd>
          <dt>
            <span id="yearEstablished">Year Established</span>
          </dt>
          <dd>{employerEntity.yearEstablished}</dd>
          <dt>
            <span id="specialization">Specialization</span>
          </dt>
          <dd>{employerEntity.specialization}</dd>
          <dt>App User</dt>
          <dd>{employerEntity.appUser ? employerEntity.appUser.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/employer" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/employer/${employerEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default EmployerDetail;
