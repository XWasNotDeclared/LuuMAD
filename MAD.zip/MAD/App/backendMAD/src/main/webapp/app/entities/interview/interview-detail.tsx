import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './interview.reducer';

export const InterviewDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const interviewEntity = useAppSelector(state => state.interview.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="interviewDetailsHeading">Interview</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{interviewEntity.id}</dd>
          <dt>
            <span id="scheduledTime">Scheduled Time</span>
          </dt>
          <dd>
            {interviewEntity.scheduledTime ? (
              <TextFormat value={interviewEntity.scheduledTime} type="date" format={APP_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="durationMinutes">Duration Minutes</span>
          </dt>
          <dd>{interviewEntity.durationMinutes}</dd>
          <dt>
            <span id="interviewType">Interview Type</span>
          </dt>
          <dd>{interviewEntity.interviewType}</dd>
          <dt>
            <span id="locationOrLink">Location Or Link</span>
          </dt>
          <dd>{interviewEntity.locationOrLink}</dd>
          <dt>
            <span id="status">Status</span>
          </dt>
          <dd>{interviewEntity.status}</dd>
          <dt>
            <span id="notes">Notes</span>
          </dt>
          <dd>{interviewEntity.notes}</dd>
          <dt>Application</dt>
          <dd>{interviewEntity.application ? interviewEntity.application.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/interview" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/interview/${interviewEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default InterviewDetail;
