import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import JobSeeker from './job-seeker';
import JobSeekerDetail from './job-seeker-detail';
import JobSeekerUpdate from './job-seeker-update';
import JobSeekerDeleteDialog from './job-seeker-delete-dialog';

const JobSeekerRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<JobSeeker />} />
    <Route path="new" element={<JobSeekerUpdate />} />
    <Route path=":id">
      <Route index element={<JobSeekerDetail />} />
      <Route path="edit" element={<JobSeekerUpdate />} />
      <Route path="delete" element={<JobSeekerDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default JobSeekerRoutes;
