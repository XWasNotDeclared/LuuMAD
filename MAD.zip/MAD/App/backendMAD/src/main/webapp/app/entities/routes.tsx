import React from 'react';
import { Route } from 'react-router-dom';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import AppUser from './app-user';
import JobSeeker from './job-seeker';
import Employer from './employer';
import Post from './post';
import Position from './position';
import Category from './category';
import Application from './application';
import ApplicationSchedule from './application-schedule';
import Interview from './interview';
import Message from './message';
import MessageReceiver from './message-receiver';
import Notification from './notification';
import Review from './review';
import Experience from './experience';
import Contract from './contract';
/* jhipster-needle-add-route-import - JHipster will add routes here */

export default () => {
  return (
    <div>
      <ErrorBoundaryRoutes>
        {/* prettier-ignore */}
        <Route path="app-user/*" element={<AppUser />} />
        <Route path="job-seeker/*" element={<JobSeeker />} />
        <Route path="employer/*" element={<Employer />} />
        <Route path="post/*" element={<Post />} />
        <Route path="position/*" element={<Position />} />
        <Route path="category/*" element={<Category />} />
        <Route path="application/*" element={<Application />} />
        <Route path="application-schedule/*" element={<ApplicationSchedule />} />
        <Route path="interview/*" element={<Interview />} />
        <Route path="message/*" element={<Message />} />
        <Route path="message-receiver/*" element={<MessageReceiver />} />
        <Route path="notification/*" element={<Notification />} />
        <Route path="review/*" element={<Review />} />
        <Route path="experience/*" element={<Experience />} />
        <Route path="contract/*" element={<Contract />} />
        {/* jhipster-needle-add-route-path - JHipster will add routes here */}
      </ErrorBoundaryRoutes>
    </div>
  );
};
