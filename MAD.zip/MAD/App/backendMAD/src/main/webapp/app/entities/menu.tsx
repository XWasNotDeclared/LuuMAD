import React from 'react';

import MenuItem from 'app/shared/layout/menus/menu-item';

const EntitiesMenu = () => {
  return (
    <>
      {/* prettier-ignore */}
      <MenuItem icon="asterisk" to="/app-user">
        App User
      </MenuItem>
      <MenuItem icon="asterisk" to="/job-seeker">
        Job Seeker
      </MenuItem>
      <MenuItem icon="asterisk" to="/employer">
        Employer
      </MenuItem>
      <MenuItem icon="asterisk" to="/post">
        Post
      </MenuItem>
      <MenuItem icon="asterisk" to="/position">
        Position
      </MenuItem>
      <MenuItem icon="asterisk" to="/category">
        Category
      </MenuItem>
      <MenuItem icon="asterisk" to="/application">
        Application
      </MenuItem>
      <MenuItem icon="asterisk" to="/application-schedule">
        Application Schedule
      </MenuItem>
      <MenuItem icon="asterisk" to="/interview">
        Interview
      </MenuItem>
      <MenuItem icon="asterisk" to="/message">
        Message
      </MenuItem>
      <MenuItem icon="asterisk" to="/message-receiver">
        Message Receiver
      </MenuItem>
      <MenuItem icon="asterisk" to="/notification">
        Notification
      </MenuItem>
      <MenuItem icon="asterisk" to="/review">
        Review
      </MenuItem>
      <MenuItem icon="asterisk" to="/experience">
        Experience
      </MenuItem>
      <MenuItem icon="asterisk" to="/contract">
        Contract
      </MenuItem>
      {/* jhipster-needle-add-entity-to-menu - JHipster will add entities to the menu here */}
    </>
  );
};

export default EntitiesMenu;
