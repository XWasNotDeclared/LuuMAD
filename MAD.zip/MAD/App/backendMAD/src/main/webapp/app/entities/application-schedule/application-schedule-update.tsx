import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { DayOfWeek } from 'app/shared/model/enumerations/day-of-week.model';
import { createEntity, getEntity, reset, updateEntity } from './application-schedule.reducer';

export const ApplicationScheduleUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const applicationScheduleEntity = useAppSelector(state => state.applicationSchedule.entity);
  const loading = useAppSelector(state => state.applicationSchedule.loading);
  const updating = useAppSelector(state => state.applicationSchedule.updating);
  const updateSuccess = useAppSelector(state => state.applicationSchedule.updateSuccess);
  const dayOfWeekValues = Object.keys(DayOfWeek);

  const handleClose = () => {
    navigate(`/application-schedule${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...applicationScheduleEntity,
      ...values,
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          dayOfWeek: 'MONDAY',
          ...applicationScheduleEntity,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.applicationSchedule.home.createOrEditLabel" data-cy="ApplicationScheduleCreateUpdateHeading">
            Create or edit a Application Schedule
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="application-schedule-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField label="Day Of Week" id="application-schedule-dayOfWeek" name="dayOfWeek" data-cy="dayOfWeek" type="select">
                {dayOfWeekValues.map(dayOfWeek => (
                  <option value={dayOfWeek} key={dayOfWeek}>
                    {dayOfWeek}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Start Time"
                id="application-schedule-startTime"
                name="startTime"
                data-cy="startTime"
                type="time"
                placeholder="HH:mm"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="End Time"
                id="application-schedule-endTime"
                name="endTime"
                data-cy="endTime"
                type="time"
                placeholder="HH:mm"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/application-schedule" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default ApplicationScheduleUpdate;
