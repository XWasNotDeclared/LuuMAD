import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './post.reducer';

export const PostDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const postEntity = useAppSelector(state => state.post.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="postDetailsHeading">Post</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{postEntity.id}</dd>
          <dt>
            <span id="description">Description</span>
          </dt>
          <dd>{postEntity.description}</dd>
          <dt>
            <span id="benefit">Benefit</span>
          </dt>
          <dd>{postEntity.benefit}</dd>
          <dt>
            <span id="jobType">Job Type</span>
          </dt>
          <dd>{postEntity.jobType}</dd>
          <dt>
            <span id="salaryRange">Salary Range</span>
          </dt>
          <dd>{postEntity.salaryRange}</dd>
          <dt>
            <span id="location">Location</span>
          </dt>
          <dd>{postEntity.location}</dd>
          <dt>
            <span id="address">Address</span>
          </dt>
          <dd>{postEntity.address}</dd>
          <dt>
            <span id="status">Status</span>
          </dt>
          <dd>{postEntity.status}</dd>
          <dt>
            <span id="createdAt">Created At</span>
          </dt>
          <dd>{postEntity.createdAt ? <TextFormat value={postEntity.createdAt} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="updatedAt">Updated At</span>
          </dt>
          <dd>{postEntity.updatedAt ? <TextFormat value={postEntity.updatedAt} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="expirationDate">Expiration Date</span>
          </dt>
          <dd>
            {postEntity.expirationDate ? <TextFormat value={postEntity.expirationDate} type="date" format={APP_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="experienceYearsRequired">Experience Years Required</span>
          </dt>
          <dd>{postEntity.experienceYearsRequired}</dd>
          <dt>
            <span id="requirements">Requirements</span>
          </dt>
          <dd>{postEntity.requirements}</dd>
          <dt>Position</dt>
          <dd>{postEntity.position ? postEntity.position.id : ''}</dd>
          <dt>Employer</dt>
          <dd>{postEntity.employer ? postEntity.employer.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/post" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/post/${postEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default PostDetail;
