import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getAppUsers } from 'app/entities/app-user/app-user.reducer';
import { getEntities as getPositions } from 'app/entities/position/position.reducer';
import { createEntity, getEntity, reset, updateEntity } from './job-seeker.reducer';

export const JobSeekerUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const appUsers = useAppSelector(state => state.appUser.entities);
  const positions = useAppSelector(state => state.position.entities);
  const jobSeekerEntity = useAppSelector(state => state.jobSeeker.entity);
  const loading = useAppSelector(state => state.jobSeeker.loading);
  const updating = useAppSelector(state => state.jobSeeker.updating);
  const updateSuccess = useAppSelector(state => state.jobSeeker.updateSuccess);

  const handleClose = () => {
    navigate(`/job-seeker${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getAppUsers({}));
    dispatch(getPositions({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    if (values.expectedSalary !== undefined && typeof values.expectedSalary !== 'number') {
      values.expectedSalary = Number(values.expectedSalary);
    }
    values.birthDate = convertDateTimeToServer(values.birthDate);

    const entity = {
      ...jobSeekerEntity,
      ...values,
      appUser: appUsers.find(it => it.id.toString() === values.appUser?.toString()),
      positions: mapIdList(values.positions),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          birthDate: displayDefaultDateTime(),
        }
      : {
          ...jobSeekerEntity,
          birthDate: convertDateTimeFromServer(jobSeekerEntity.birthDate),
          appUser: jobSeekerEntity?.appUser?.id,
          positions: jobSeekerEntity?.positions?.map(e => e.id.toString()),
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.jobSeeker.home.createOrEditLabel" data-cy="JobSeekerCreateUpdateHeading">
            Create or edit a Job Seeker
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="job-seeker-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Resume Url" id="job-seeker-resumeUrl" name="resumeUrl" data-cy="resumeUrl" type="text" />
              <ValidatedField
                label="Expected Salary"
                id="job-seeker-expectedSalary"
                name="expectedSalary"
                data-cy="expectedSalary"
                type="text"
              />
              <ValidatedField label="Description" id="job-seeker-description" name="description" data-cy="description" type="text" />
              <ValidatedField
                label="Birth Date"
                id="job-seeker-birthDate"
                name="birthDate"
                data-cy="birthDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
              />
              <ValidatedField id="job-seeker-appUser" name="appUser" data-cy="appUser" label="App User" type="select">
                <option value="" key="0" />
                {appUsers
                  ? appUsers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField label="Positions" id="job-seeker-positions" data-cy="positions" type="select" multiple name="positions">
                <option value="" key="0" />
                {positions
                  ? positions.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/job-seeker" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default JobSeekerUpdate;
