import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getNotifications } from 'app/entities/notification/notification.reducer';
import { getEntities as getAppUsers } from 'app/entities/app-user/app-user.reducer';
import { createEntity, getEntity, reset, updateEntity } from './notification-receiver.reducer';

export const NotificationReceiverUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const notifications = useAppSelector(state => state.notification.entities);
  const appUsers = useAppSelector(state => state.appUser.entities);
  const notificationReceiverEntity = useAppSelector(state => state.notificationReceiver.entity);
  const loading = useAppSelector(state => state.notificationReceiver.loading);
  const updating = useAppSelector(state => state.notificationReceiver.updating);
  const updateSuccess = useAppSelector(state => state.notificationReceiver.updateSuccess);

  const handleClose = () => {
    navigate(`/notification-receiver${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getNotifications({}));
    dispatch(getAppUsers({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...notificationReceiverEntity,
      ...values,
      notification: notifications.find(it => it.id.toString() === values.notification?.toString()),
      receiver: appUsers.find(it => it.id.toString() === values.receiver?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          ...notificationReceiverEntity,
          notification: notificationReceiverEntity?.notification?.id,
          receiver: notificationReceiverEntity?.receiver?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="madBackendApp.notificationReceiver.home.createOrEditLabel" data-cy="NotificationReceiverCreateUpdateHeading">
            Create or edit a Notification Receiver
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="notification-receiver-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField label="Is Read" id="notification-receiver-isRead" name="isRead" data-cy="isRead" check type="checkbox" />
              <ValidatedField
                id="notification-receiver-notification"
                name="notification"
                data-cy="notification"
                label="Notification"
                type="select"
              >
                <option value="" key="0" />
                {notifications
                  ? notifications.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="notification-receiver-receiver" name="receiver" data-cy="receiver" label="Receiver" type="select">
                <option value="" key="0" />
                {appUsers
                  ? appUsers.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.id}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/notification-receiver" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default NotificationReceiverUpdate;
