import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import ApplicationSchedule from './application-schedule';
import ApplicationScheduleDetail from './application-schedule-detail';
import ApplicationScheduleUpdate from './application-schedule-update';
import ApplicationScheduleDeleteDialog from './application-schedule-delete-dialog';

const ApplicationScheduleRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<ApplicationSchedule />} />
    <Route path="new" element={<ApplicationScheduleUpdate />} />
    <Route path=":id">
      <Route index element={<ApplicationScheduleDetail />} />
      <Route path="edit" element={<ApplicationScheduleUpdate />} />
      <Route path="delete" element={<ApplicationScheduleDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default ApplicationScheduleRoutes;
